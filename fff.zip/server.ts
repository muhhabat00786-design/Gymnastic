import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Gemini client lazily
function getGenAI() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// API Routes
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', club: 'VORTEX Ultra-Luxury Fitness' });
});

// AI Fitness Assistant Chat Endpoint
app.post('/api/ai-chat', async (req, res) => {
  try {
    const { message, conversationHistory } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const ai = getGenAI();
    if (!ai) {
      // Fallback structured intelligence response if key isn't present
      return res.json({
        response: `[VORTEX AI Performance Coach]: To reach optimal hypertrophy and peak metabolic conditioning, maintain progressive overload with 1.8g to 2.2g of protein per kg of body weight daily. Focus on 7-9 hours of deep recovery sleep and track your heart rate variability. How else can I tailor your regime today?`,
      });
    }

    const systemPrompt = `You are VORTEX AI, the elite Master Performance & Nutrition Coach at VORTEX Ultra-Luxury Fitness Club.
You speak with high intelligence, scientific accuracy, inspiring authority, and luxury polish.
Provide actionable, precise advice on workouts, exercise execution, nutrition macros, recovery protocol (cryotherapy, sauna, sleep), supplement stacking, and athletic mindset. Keep responses concise, well-structured with bullet points where appropriate, and highly motivating.`;

    // Construct contents
    const contents = [];
    if (Array.isArray(conversationHistory)) {
      for (const msg of conversationHistory) {
        contents.push({
          role: msg.role === 'user' ? 'user' : 'model',
          parts: [{ text: msg.text }],
        });
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: contents,
      config: {
        systemInstruction: systemPrompt,
        temperature: 0.7,
      },
    });

    res.json({ response: response.text || 'I am ready to optimize your performance.' });
  } catch (error: any) {
    console.error('Gemini AI Chat Error:', error);
    res.status(500).json({
      error: 'Failed to process AI chat request',
      details: error.message,
    });
  }
});

// AI Personal Workout Plan Generator
app.post('/api/ai-workout-gen', async (req, res) => {
  try {
    const { goal, experience, daysPerWeek, focusAreas } = req.body;
    const ai = getGenAI();

    if (!ai) {
      return res.json({
        planName: `${goal || 'Hypertrophy'} Peak Protocol`,
        summary: `Customized 4-day high-intensity program optimized for ${experience || 'intermediate'} level focus on ${focusAreas || 'Full Body'}.`,
        days: [
          { day: 'Day 1', focus: 'Chest & Triceps - Heavy Compound', exercises: ['Incline Barbell Bench Press (4x8)', 'Cable Chest Flyes (3x12)', 'Weighted Dips (3x10)', 'Overhead Cable Tricep Ext (4x12)'] },
          { day: 'Day 2', focus: 'Back & Biceps - Posterior Chain', exercises: ['Deadlifts (4x5)', 'Lat Pulldowns (4x10)', 'Seated Cable Rows (3x12)', 'Hammer Curls (4x12)'] },
          { day: 'Day 3', focus: 'Active Recovery & Cryotherapy', exercises: ['20 mins Infrared Sauna', 'Dynamic Mobility Flow', 'Low-intensity Zone 2 Cardio (30 mins)'] },
          { day: 'Day 4', focus: 'Legs & Core - Quads/Hams Explosive', exercises: ['Barbell Back Squats (4x6)', 'Romanian Deadlifts (4x10)', 'Walking Dumbbell Lunges (3x12/leg)', 'Hanging Leg Raises (4x15)'] },
        ]
      });
    }

    const prompt = `Generate a customized elite 4-day workout plan for a VORTEX member.
Details:
- Goal: ${goal || 'Muscle Growth'}
- Experience Level: ${experience || 'Intermediate'}
- Days Per Week: ${daysPerWeek || 4}
- Focus Areas: ${focusAreas || 'Full Body'}

Return JSON strictly matching this structure:
{
  "planName": "Name of plan",
  "summary": "Brief high level protocol overview",
  "days": [
    {
      "day": "Day 1",
      "focus": "Focus title",
      "exercises": ["Exercise 1 (Sets x Reps)", "Exercise 2 (Sets x Reps)", "Exercise 3 (Sets x Reps)"]
    }
  ]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.6-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    res.json(parsed);
  } catch (error: any) {
    console.error('AI Workout Gen Error:', error);
    res.status(500).json({ error: 'Failed to generate workout plan' });
  }
});

// Contact & Booking endpoint
app.post('/api/contact', (req, res) => {
  const { name, email, phone, subject, message, type } = req.body;
  res.json({
    success: true,
    message: `Thank you ${name || 'Member'}, your ${type || 'inquiry'} has been received by VORTEX Concierge. A performance advisor will contact you within 2 hours.`,
    referenceId: 'VTX-' + Math.floor(100000 + Math.random() * 900000),
  });
});

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`VORTEX Gym Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
