import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole, Booking, CartItem, Order, Product } from '../types';

interface AuthContextType {
  user: User | null;
  role: UserRole;
  switchRole: (role: UserRole) => void;
  login: (email: string, pass: string) => Promise<boolean>;
  register: (name: string, email: string, pass: string) => Promise<boolean>;
  logout: () => void;
  updateProfile: (data: Partial<User>) => void;
  
  bookings: Booking[];
  addBooking: (booking: Omit<Booking, 'id' | 'userId' | 'userName' | 'status'>) => void;
  cancelBooking: (id: string) => void;
  
  cart: CartItem[];
  addToCart: (product: Product, quantity?: number, selectedSize?: string) => void;
  removeFromCart: (productId: string) => void;
  updateCartQty: (productId: string, quantity: number) => void;
  clearCart: () => void;
  
  orders: Order[];
  addOrder: (paymentMethod: string) => Order;
  
  savedItems: string[];
  toggleSaveItem: (id: string) => void;
  
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  
  isBookingOpen: boolean;
  setIsBookingOpen: (open: boolean) => void;
  bookingTarget: any;
  openBookingModal: (target?: any) => void;
  closeBookingModal: () => void;

  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;

  isAiChatOpen: boolean;
  setIsAiChatOpen: (open: boolean) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

const DEFAULT_MEMBER_USER: User = {
  id: 'usr-member-101',
  name: 'David Sterling',
  email: 'david.sterling@vortex.com',
  role: 'member',
  avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
  phone: '+1 (555) 234-5678',
  bio: 'Dedicated executive committed to daily progressive overload and metabolic health.',
  goals: ['Hypertrophy', 'Fat Loss', '100kg Bench Press'],
  heightCm: 184,
  weightKg: 82,
  bmi: 24.2,
  membershipPlan: 'PRO ATHLETE VIP',
  subscriptionStatus: 'Active',
  qrCodeToken: 'VTX-QR-8829102-MEM',
  joinedDate: 'January 2025',
  twoFactorEnabled: true,
};

const DEFAULT_TRAINER_USER: User = {
  id: 'usr-trainer-202',
  name: 'Marcus Vance',
  email: 'marcus.vance@vortex.com',
  role: 'trainer',
  avatar: 'https://images.unsplash.com/photo-1567013127542-490d757e51fc?auto=format&fit=crop&w=300&q=80',
  phone: '+1 (555) 987-6543',
  bio: 'Head of Aesthetic Conditioning at VORTEX. 12+ years experience in biomechanics.',
  goals: ['Coach 50+ IFBB Athletes', 'Expand AI Hypertrophy Module'],
  heightCm: 188,
  weightKg: 95,
  bmi: 26.8,
  membershipPlan: 'STAFF MASTER COACH',
  subscriptionStatus: 'Active',
  qrCodeToken: 'VTX-QR-1102938-TRN',
  joinedDate: 'March 2022',
  twoFactorEnabled: true,
};

const DEFAULT_ADMIN_USER: User = {
  id: 'usr-admin-303',
  name: 'Alexander Sterling (HQ Admin)',
  email: 'admin@vortexfitness.club',
  role: 'admin',
  avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
  phone: '+1 (800) 555-VTX',
  bio: 'Global Operations Director & System Administrator for VORTEX Clubs.',
  goals: ['Global Club Expansion', 'System Uptime 99.99%'],
  heightCm: 180,
  weightKg: 78,
  bmi: 24.1,
  membershipPlan: 'ENTERPRISE SYSTEM ADMIN',
  subscriptionStatus: 'Active',
  qrCodeToken: 'VTX-QR-0000001-ADM',
  joinedDate: 'January 2020',
  twoFactorEnabled: true,
};

const INITIAL_BOOKINGS: Booking[] = [
  {
    id: 'bk-101',
    userId: 'usr-member-101',
    userName: 'David Sterling',
    type: 'Class',
    title: 'VORTEX Heavy Shred HIIT',
    date: '2026-07-29',
    time: '07:00 AM',
    trainerOrRoom: 'Elena Rostova (Studio A)',
    status: 'Confirmed',
    price: 0,
  },
  {
    id: 'bk-102',
    userId: 'usr-member-101',
    userName: 'David Sterling',
    type: 'Personal Training',
    title: '1-on-1 Hypertrophy & Biomechanics Session',
    date: '2026-07-30',
    time: '10:00 AM',
    trainerOrRoom: 'Marcus Vance (Iron Suite)',
    status: 'Confirmed',
    price: 120,
  },
  {
    id: 'bk-103',
    userId: 'usr-member-101',
    userName: 'David Sterling',
    type: 'Assessment',
    title: 'Biometric DEXA & VO2 Max Scan',
    date: '2026-07-20',
    time: '02:00 PM',
    trainerOrRoom: 'Diagnostic Lab 2',
    status: 'Completed',
    price: 0,
  }
];

const INITIAL_ORDERS: Order[] = [
  {
    id: 'ORD-88412',
    userId: 'usr-member-101',
    items: [],
    totalAmount: 189.98,
    status: 'Delivered',
    paymentMethod: 'Visa ending 8812',
    createdAt: '2026-07-15',
    trackingNumber: 'VTX-TRK-9901823'
  }
];

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRole] = useState<UserRole>('member');
  const [user, setUser] = useState<User | null>(DEFAULT_MEMBER_USER);
  const [bookings, setBookings] = useState<Booking[]>(INITIAL_BOOKINGS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>(INITIAL_ORDERS);
  const [savedItems, setSavedItems] = useState<string[]>(['prog-1', 'tr-1', 'blog-1']);
  
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isBookingOpen, setIsBookingOpen] = useState(false);
  const [bookingTarget, setBookingTarget] = useState<any>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [isAiChatOpen, setIsAiChatOpen] = useState(false);

  // Sync role switch
  const switchRole = (newRole: UserRole) => {
    setRole(newRole);
    if (newRole === 'guest') {
      setUser(null);
    } else if (newRole === 'member') {
      setUser(DEFAULT_MEMBER_USER);
    } else if (newRole === 'trainer') {
      setUser(DEFAULT_TRAINER_USER);
    } else if (newRole === 'admin') {
      setUser(DEFAULT_ADMIN_USER);
    }
  };

  const login = async (email: string, pass: string): Promise<boolean> => {
    if (email.includes('admin')) {
      switchRole('admin');
    } else if (email.includes('trainer')) {
      switchRole('trainer');
    } else {
      switchRole('member');
      if (user) {
        setUser({ ...DEFAULT_MEMBER_USER, email, name: email.split('@')[0] });
      }
    }
    return true;
  };

  const register = async (name: string, email: string, pass: string): Promise<boolean> => {
    const newUser: User = {
      ...DEFAULT_MEMBER_USER,
      id: 'usr-' + Date.now(),
      name,
      email,
      role: 'member',
      joinedDate: 'Just now'
    };
    setUser(newUser);
    setRole('member');
    return true;
  };

  const logout = () => {
    switchRole('guest');
  };

  const updateProfile = (data: Partial<User>) => {
    if (user) {
      setUser(prev => prev ? { ...prev, ...data } : null);
    }
  };

  const addBooking = (bookingData: Omit<Booking, 'id' | 'userId' | 'userName' | 'status'>) => {
    const newBk: Booking = {
      ...bookingData,
      id: 'bk-' + Date.now(),
      userId: user?.id || 'guest',
      userName: user?.name || 'Guest User',
      status: 'Confirmed'
    };
    setBookings(prev => [newBk, ...prev]);
  };

  const cancelBooking = (id: string) => {
    setBookings(prev => prev.map(b => b.id === id ? { ...b, status: 'Cancelled' as const } : b));
  };

  const addToCart = (product: Product, quantity = 1, selectedSize = 'Standard') => {
    setCart(prev => {
      const existing = prev.find(item => item.product.id === product.id);
      if (existing) {
        return prev.map(item => item.product.id === product.id ? { ...item, quantity: item.quantity + quantity } : item);
      }
      return [...prev, { product, quantity, selectedSize }];
    });
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.product.id !== productId));
  };

  const updateCartQty = (productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev => prev.map(item => item.product.id === productId ? { ...item, quantity } : item));
  };

  const clearCart = () => {
    setCart([]);
  };

  const addOrder = (paymentMethod: string): Order => {
    const totalAmount = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
    const newOrder: Order = {
      id: 'ORD-' + Math.floor(10000 + Math.random() * 90000),
      userId: user?.id || 'guest',
      items: [...cart],
      totalAmount: Math.round(totalAmount * 100) / 100,
      status: 'Processing',
      paymentMethod,
      createdAt: new Date().toISOString().split('T')[0],
      trackingNumber: 'VTX-TRK-' + Math.floor(1000000 + Math.random() * 9000000)
    };
    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    return newOrder;
  };

  const toggleSaveItem = (id: string) => {
    setSavedItems(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const openBookingModal = (target?: any) => {
    setBookingTarget(target || null);
    setIsBookingOpen(true);
  };

  const closeBookingModal = () => {
    setIsBookingOpen(false);
    setBookingTarget(null);
  };

  return (
    <AuthContext.Provider value={{
      user,
      role,
      switchRole,
      login,
      register,
      logout,
      updateProfile,
      bookings,
      addBooking,
      cancelBooking,
      cart,
      addToCart,
      removeFromCart,
      updateCartQty,
      clearCart,
      orders,
      addOrder,
      savedItems,
      toggleSaveItem,
      isSearchOpen,
      setIsSearchOpen,
      isBookingOpen,
      setIsBookingOpen,
      bookingTarget,
      openBookingModal,
      closeBookingModal,
      isCheckoutOpen,
      setIsCheckoutOpen,
      isAiChatOpen,
      setIsAiChatOpen,
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
