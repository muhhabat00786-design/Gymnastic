export interface Program {
  id: string;
  title: string;
  category: string;
  image: string;
  description: string;
  duration: string;
  trainer: string;
  intensity: 'Beginner' | 'Intermediate' | 'Advanced' | 'Elite';
  caloriesBurned: string;
  price: string;
}

export interface Trainer {
  id: string;
  name: string;
  role: string;
  photo: string;
  specialization: string[];
  experience: string;
  rating: number;
  reviewsCount: number;
  bio: string;
  instagram: string;
  linkedin: string;
  availableDays: string[];
}

export interface PricingPlan {
  id: string;
  name: string;
  priceMonthly: number;
  priceYearly: number;
  popular?: boolean;
  vip?: boolean;
  description: string;
  features: string[];
}

export interface ClassSession {
  id: string;
  className: string;
  category: 'Cardio' | 'Strength' | 'HIIT' | 'Yoga' | 'Boxing' | 'Recovery';
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';
  time: string;
  trainer: string;
  duration: string;
  room: string;
  spotsLeft: number;
  totalSpots: number;
}

export interface TransformationStory {
  id: string;
  name: string;
  age: number;
  timeframe: string;
  weightLost: string;
  muscleGained: string;
  program: string;
  quote: string;
  beforeImage: string;
  afterImage: string;
  story: string;
}

export interface BlogPost {
  id: string;
  title: string;
  category: string;
  readTime: string;
  date: string;
  author: string;
  image: string;
  summary: string;
  content: string;
}

export interface Product {
  id: string;
  name: string;
  category: 'Supplements' | 'Apparel' | 'Gear';
  price: number;
  rating: number;
  image: string;
  description: string;
  inStock: boolean;
}

export interface MealPlan {
  id: string;
  title: string;
  goal: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  image: string;
  meals: { time: string; name: string; desc: string }[];
}

export type UserRole = 'guest' | 'member' | 'trainer' | 'admin';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatar: string;
  phone?: string;
  bio?: string;
  goals?: string[];
  heightCm?: number;
  weightKg?: number;
  bmi?: number;
  membershipPlan?: string;
  subscriptionStatus?: 'Active' | 'Pending' | 'Expired';
  qrCodeToken?: string;
  joinedDate?: string;
  twoFactorEnabled?: boolean;
}

export interface Booking {
  id: string;
  userId: string;
  userName: string;
  type: 'Class' | 'Personal Training' | 'Consultation' | 'Assessment' | 'Trial Pass';
  title: string;
  date: string;
  time: string;
  trainerOrRoom: string;
  status: 'Confirmed' | 'Completed' | 'Cancelled';
  price: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedSize?: string;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  totalAmount: number;
  status: 'Processing' | 'Shipped' | 'Delivered';
  paymentMethod: string;
  createdAt: string;
  trackingNumber: string;
}

export interface Recipe {
  id: string;
  title: string;
  category: 'High Protein' | 'Low Carb' | 'Keto' | 'Vegan' | 'Post-Workout';
  prepTime: string;
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
  image: string;
  ingredients: string[];
  instructions: string[];
}

export interface EventItem {
  id: string;
  title: string;
  category: string;
  date: string;
  time: string;
  location: string;
  image: string;
  description: string;
  spotsLeft: number;
  price: string;
}

export interface ChallengeItem {
  id: string;
  title: string;
  prize: string;
  duration: string;
  participantsCount: number;
  category: string;
  description: string;
  image: string;
  rules: string[];
}

export interface BranchLocation {
  id: string;
  city: string;
  country: string;
  name: string;
  address: string;
  phone: string;
  email: string;
  hours: string;
  image: string;
  amenities: string[];
  isFlagship?: boolean;
}

export interface CareerJob {
  id: string;
  title: string;
  department: string;
  location: string;
  type: 'Full-time' | 'Part-time' | 'Contract';
  experience: string;
  description: string;
  requirements: string[];
}

export interface SupportTicket {
  id: string;
  userName: string;
  email: string;
  subject: string;
  status: 'Open' | 'In Progress' | 'Resolved';
  priority: 'Low' | 'Medium' | 'High';
  date: string;
  message: string;
}

export interface AuditLog {
  id: string;
  action: string;
  user: string;
  role: string;
  ip: string;
  timestamp: string;
}
