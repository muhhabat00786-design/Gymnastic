import React, { useState } from 'react';
import { Target, Compass, Award, CheckCircle2, ShieldCheck, Zap, HeartPulse, Sparkles } from 'lucide-react';

export const AboutSection: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'mission' | 'vision' | 'history'>('mission');

  const timelineEvents = [
    { year: '2001', title: 'Founding Flagship', desc: 'VORTEX opened its inaugural 30,000 sq.ft luxury sanctuary in London.' },
    { year: '2010', title: 'Global Expansion', desc: 'Expanded to Tokyo, Dubai, New York, and Paris with state-of-the-art biometrics.' },
    { year: '2018', title: 'Infrared & Bio-Recovery Suites', desc: 'Pioneered custom cold-plunge contrast therapy and cryotherapy chambers.' },
    { year: '2026', title: 'AI Performance Integration', desc: 'Launched real-time biometric tracking and generative AI coaching platform.' }
  ];

  return (
    <section id="about" className="py-24 bg-[#0A0A0A] relative overflow-hidden">
      
      {/* Background Subtle Red Glow */}
      <div className="absolute top-1/2 right-0 w-96 h-96 bg-red-600/10 rounded-full blur-[150px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>The VORTEX Standard</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            ENGINEERED FOR <span className="text-gradient-red">HUMAN PEAK.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            We transcend traditional gym concepts. VORTEX is an international architectural sanctuary merging scientific athletic engineering, custom biomechanics, and luxury biohacking.
          </p>
        </div>

        {/* Main Grid: Image Showcase & Mission/Vision Tabs */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center mb-20">
          
          {/* Left Column: High Res Facility Showcase with Floating Badges */}
          <div className="lg:col-span-6 relative">
            <div className="relative rounded-3xl overflow-hidden border border-white/10 shadow-2xl group">
              <img
                src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1200&q=80"
                alt="VORTEX Luxury Gym Interior"
                className="w-full h-[480px] object-cover group-hover:scale-105 transition-transform duration-700 filter contrast-110 brightness-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-transparent" />

              {/* Floating Badge 1 */}
              <div className="absolute bottom-6 left-6 glass-card p-4 border-red-500/30 max-w-xs shadow-xl backdrop-blur-xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#FF3B30] to-[#FF0000] flex items-center justify-center text-white">
                    <Award className="w-5 h-5" />
                  </div>
                  <div>
                    <span className="block text-sm font-extrabold text-white font-mono">#1 Luxury Club</span>
                    <span className="text-[11px] text-[#B8B8B8]">World Fitness Excellence 2025</span>
                  </div>
                </div>
              </div>

              {/* Floating Badge 2 */}
              <div className="absolute top-6 right-6 glass-card px-4 py-2 border-white/10 shadow-xl backdrop-blur-xl flex items-center gap-2">
                <span className="w-2.5 h-2.5 rounded-full bg-[#00E676] animate-pulse" />
                <span className="text-xs font-bold text-white uppercase font-mono">100% Bio-Validated</span>
              </div>
            </div>
          </div>

          {/* Right Column: Interactive Mission / Vision / History Tabs */}
          <div className="lg:col-span-6 flex flex-col justify-center">
            
            {/* Tab Navigation */}
            <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#111111] border border-white/10 mb-8 max-w-md">
              <button
                onClick={() => setActiveTab('mission')}
                className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-extrabold uppercase tracking-wider transition-all ${
                  activeTab === 'mission' ? 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg shadow-red-600/30' : 'text-[#B8B8B8] hover:text-white'
                }`}
              >
                Our Mission
              </button>
              <button
                onClick={() => setActiveTab('vision')}
                className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-extrabold uppercase tracking-wider transition-all ${
                  activeTab === 'vision' ? 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg shadow-red-600/30' : 'text-[#B8B8B8] hover:text-white'
                }`}
              >
                Our Vision
              </button>
              <button
                onClick={() => setActiveTab('history')}
                className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-extrabold uppercase tracking-wider transition-all ${
                  activeTab === 'history' ? 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg shadow-red-600/30' : 'text-[#B8B8B8] hover:text-white'
                }`}
              >
                Our Legacy
              </button>
            </div>

            {/* Tab Content Display */}
            {activeTab === 'mission' && (
              <div className="space-y-6 animate-fade-in">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-2xl bg-red-950/40 border border-red-500/30 text-[#FF3B30]">
                    <Target className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2 font-mono">Uncompromising Athletic Mastery</h3>
                    <p className="text-sm text-[#B8B8B8] leading-relaxed">
                      To empower global executives, elite athletes, and fitness enthusiasts with custom biomechanical apparatus, world-leading coaching, and evidence-based biohacking facilities.
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-4">
                  <div className="glass-card p-4 border-white/10">
                    <CheckCircle2 className="w-5 h-5 text-[#FF3B30] mb-2" />
                    <span className="block font-bold text-sm text-white font-mono">100% Custom Rigging</span>
                    <span className="text-xs text-[#B8B8B8]">Custom Technogym & Eleiko plates</span>
                  </div>
                  <div className="glass-card p-4 border-white/10">
                    <ShieldCheck className="w-5 h-5 text-[#FF3B30] mb-2" />
                    <span className="block font-bold text-sm text-white font-mono">Biometric Diagnostics</span>
                    <span className="text-xs text-[#B8B8B8]">InBody 770 DEXA Scans</span>
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'vision' && (
              <div className="space-y-6 animate-fade-in">
                <div className="flex items-start gap-4">
                  <div className="p-3 rounded-2xl bg-red-950/40 border border-red-500/30 text-[#FF3B30]">
                    <Compass className="w-6 h-6" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2 font-mono">Redefining Longevity & Athletic Power</h3>
                    <p className="text-sm text-[#B8B8B8] leading-relaxed">
                      We envision a future where human lifespan is extended through optimized resistance training, cryo recovery, and targeted macro nutrition.
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-[#111111] border border-red-500/20 text-xs text-[#B8B8B8]">
                  <p className="italic text-white">"At VORTEX, fitness is not an occasional habit—it is a continuous state of athletic luxury."</p>
                </div>
              </div>
            )}

            {activeTab === 'history' && (
              <div className="space-y-4 animate-fade-in">
                <h3 className="text-lg font-bold text-white font-mono mb-3">Milestones of Excellence</h3>
                <div className="space-y-3">
                  {timelineEvents.map((evt, idx) => (
                    <div key={idx} className="flex items-start gap-3 p-3 rounded-xl bg-[#111111] border border-white/5">
                      <span className="px-2.5 py-1 rounded-md bg-red-600/20 text-[#FF3B30] font-mono text-xs font-extrabold">
                        {evt.year}
                      </span>
                      <div>
                        <span className="block font-bold text-xs text-white">{evt.title}</span>
                        <span className="text-[11px] text-[#B8B8B8]">{evt.desc}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>

        </div>

      </div>
    </section>
  );
};
