import React, { useState } from 'react';
import { TRANSFORMATION_STORIES } from '../data/gymData';
import { Award, Flame, Quote, ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';

export const TransformationStories: React.FC = () => {
  const [activeIdx, setActiveIdx] = useState<number>(0);
  const [sliderPos, setSliderPos] = useState<number>(50); // percentage

  const current = TRANSFORMATION_STORIES[activeIdx];

  const handleNext = () => {
    setActiveIdx((prev) => (prev + 1) % TRANSFORMATION_STORIES.length);
  };

  const handlePrev = () => {
    setActiveIdx((prev) => (prev - 1 + TRANSFORMATION_STORIES.length) % TRANSFORMATION_STORIES.length);
  };

  return (
    <section className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Award className="w-3.5 h-3.5" />
            <span>Proven Athletic Results</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            TRANSFORMATION <span className="text-gradient-red">STORIES.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Real members. Unfiltered physical metamorphoses driven by scientific progressive overload and bio-nutrition.
          </p>
        </div>

        {/* Main Interactive Transformation Box */}
        {current && (
          <div className="glass-card p-6 sm:p-10 border-white/10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            
            {/* Interactive Before/After Comparison Image Slider */}
            <div className="lg:col-span-6 relative h-96 rounded-2xl overflow-hidden border border-white/15 select-none shadow-2xl">
              
              {/* After Image (Background) */}
              <img
                src={current.afterImage}
                alt="After Transformation"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <span className="absolute top-4 right-4 px-3 py-1 rounded-full bg-green-500/80 backdrop-blur-md text-[10px] font-mono font-bold uppercase text-white shadow-lg">
                AFTER ({current.timeframe})
              </span>

              {/* Before Image (Clipped overlay) */}
              <div
                className="absolute inset-0 overflow-hidden"
                style={{ width: `${sliderPos}%` }}
              >
                <img
                  src={current.beforeImage}
                  alt="Before Transformation"
                  className="absolute inset-0 w-full h-full object-cover max-w-none"
                  style={{ width: '100%', height: '100%' }}
                />
                <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-red-950/80 backdrop-blur-md text-[10px] font-mono font-bold uppercase text-white border border-red-500/40 shadow-lg">
                  BEFORE
                </span>
              </div>

              {/* Slider Control Line & Handle */}
              <div
                className="absolute top-0 bottom-0 w-1 bg-white cursor-ew-resize flex items-center justify-center shadow-2xl"
                style={{ left: `${sliderPos}%` }}
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-[#FF3B30] to-[#FF0000] border-2 border-white shadow-xl flex items-center justify-center text-white text-xs">
                  ↔
                </div>
              </div>

              {/* Interactive Range Input overlay for easy touch/mouse dragging */}
              <input
                type="range"
                min="0"
                max="100"
                value={sliderPos}
                onChange={(e) => setSliderPos(Number(e.target.value))}
                className="absolute inset-0 opacity-0 cursor-ew-resize w-full h-full"
              />
            </div>

            {/* Member Details & Testimonial */}
            <div className="lg:col-span-6 space-y-6">
              
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-2xl font-extrabold text-white font-mono">{current.name}, {current.age}</h3>
                  <span className="text-xs font-semibold text-[#FF3B30] uppercase font-mono">{current.program}</span>
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handlePrev}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>
                  <button
                    onClick={handleNext}
                    className="p-2 rounded-xl bg-white/5 hover:bg-white/10 border border-white/10 text-white"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Results Badges */}
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 rounded-xl bg-[#0A0A0A] border border-white/10 text-center">
                  <span className="block text-xs text-[#B8B8B8] font-mono uppercase">Fat Mass Lost</span>
                  <span className="block text-2xl font-extrabold text-[#FF3B30] font-mono mt-1">{current.weightLost}</span>
                </div>

                <div className="p-4 rounded-xl bg-[#0A0A0A] border border-white/10 text-center">
                  <span className="block text-xs text-[#B8B8B8] font-mono uppercase">Lean Muscle Gained</span>
                  <span className="block text-2xl font-extrabold text-[#00E676] font-mono mt-1">{current.muscleGained}</span>
                </div>
              </div>

              {/* Member Story Quote */}
              <div className="p-5 rounded-2xl bg-white/5 border border-white/10 relative">
                <Quote className="w-8 h-8 text-red-500/30 absolute -top-3 -left-3" />
                <p className="text-sm text-white italic leading-relaxed relative z-10">
                  "{current.story}"
                </p>
              </div>

            </div>

          </div>
        )}

      </div>
    </section>
  );
};
