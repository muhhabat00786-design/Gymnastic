import React from 'react';
import { useAuth } from '../context/AuthContext';
import { UserCheck, Shield, Award, User, LayoutDashboard, Search, Sparkles } from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';

export const RoleSwitcherBar: React.FC = () => {
  const { role, switchRole, user, setIsSearchOpen, setIsAiChatOpen } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  return (
    <div className="bg-[#050505] border-b border-red-950/40 px-4 py-1.5 text-xs text-neutral-300 flex flex-wrap items-center justify-between gap-2 z-40 sticky top-0">
      <div className="flex items-center gap-2">
        <span className="flex items-center gap-1.5 text-[11px] font-bold tracking-wider uppercase text-neutral-400">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          Preview Mode:
        </span>
        
        <div className="flex items-center bg-black/60 rounded-lg p-0.5 border border-white/10">
          {(['guest', 'member', 'trainer', 'admin'] as const).map(r => (
            <button
              key={r}
              onClick={() => {
                switchRole(r);
                if (r === 'member') navigate('/dashboard/member');
                else if (r === 'trainer') navigate('/dashboard/trainer');
                else if (r === 'admin') navigate('/dashboard/admin');
              }}
              className={`px-2.5 py-1 rounded-md text-[11px] font-semibold capitalize transition-all ${
                role === r
                  ? 'bg-[#FF3B30] text-white shadow-sm font-bold'
                  : 'text-neutral-400 hover:text-white'
              }`}
            >
              {r}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center gap-3">
        {/* Quick Nav to Active Dashboard */}
        {role !== 'guest' && (
          <button
            onClick={() => {
              if (role === 'member') navigate('/dashboard/member');
              else if (role === 'trainer') navigate('/dashboard/trainer');
              else if (role === 'admin') navigate('/dashboard/admin');
            }}
            className="flex items-center gap-1.5 text-[11px] font-semibold text-[#FF3B30] hover:underline"
          >
            <LayoutDashboard className="w-3.5 h-3.5" />
            Go to {role.toUpperCase()} Dashboard
          </button>
        )}

        <button
          onClick={() => setIsSearchOpen(true)}
          className="flex items-center gap-1 text-[11px] text-neutral-400 hover:text-white px-2 py-0.5 rounded bg-white/5 border border-white/10"
        >
          <Search className="w-3 h-3 text-[#FF3B30]" /> Search (Ctrl+K)
        </button>

        <button
          onClick={() => setIsAiChatOpen(true)}
          className="flex items-center gap-1 text-[11px] text-amber-300 font-semibold px-2 py-0.5 rounded bg-amber-950/40 border border-amber-500/30 hover:border-amber-400"
        >
          <Sparkles className="w-3 h-3 text-amber-400" /> AI Coach
        </button>
      </div>
    </div>
  );
};
