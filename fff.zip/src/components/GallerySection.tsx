import React, { useState } from 'react';
import { Camera, X, ZoomIn } from 'lucide-react';

export const GallerySection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [lightboxImg, setLightboxImg] = useState<{ url: string; title: string } | null>(null);

  const galleryItems = [
    { title: 'Olympic Powerlifting Platforms', cat: 'Equipment', url: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1000&q=80' },
    { title: 'Custom Technogym Biomotion Suite', cat: 'Facilities', url: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=1000&q=80' },
    { title: 'Rogue Functional Rig Box', cat: 'Equipment', url: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=1000&q=80' },
    { title: 'Infrared Heated Reformer Sanctuary', cat: 'Facilities', url: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&w=1000&q=80' },
    { title: '25m Saltwater Olympic Lap Pool', cat: 'Facilities', url: 'https://images.unsplash.com/photo-1576013551627-0cc20b96c2a7?auto=format&fit=crop&w=1000&q=80' },
    { title: 'High-Octane Metabolic Shred Class', cat: 'Classes', url: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=1000&q=80' },
    { title: 'Sub-Zero Cryotherapy Chamber', cat: 'VIP Lounge', url: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1000&q=80' },
    { title: 'Championship Ring Boxing Room', cat: 'Classes', url: 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&w=1000&q=80' }
  ];

  const categories = ['All', 'Facilities', 'Equipment', 'Classes', 'VIP Lounge'];

  const filteredItems = selectedCategory === 'All'
    ? galleryItems
    : galleryItems.filter(item => item.cat === selectedCategory);

  return (
    <section id="gallery" className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Camera className="w-3.5 h-3.5" />
            <span>Visual Architecture</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            EXPLORE THE <span className="text-gradient-red">GALLERY.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Architectural precision meets elite physical conditioning. Immerse yourself in the VORTEX flagship sanctuaries.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex justify-center items-center gap-2 overflow-x-auto pb-4 mb-10 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-5 py-2 rounded-xl text-xs font-mono font-extrabold uppercase tracking-wider transition-all ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg shadow-red-600/30'
                  : 'bg-[#111111] border border-white/10 text-[#B8B8B8] hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Masonry Image Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {filteredItems.map((item, idx) => (
            <div
              key={idx}
              className="relative h-72 rounded-2xl overflow-hidden border border-white/10 group cursor-pointer shadow-xl"
              onClick={() => setLightboxImg({ url: item.url, title: item.title })}
            >
              <img
                src={item.url}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 filter contrast-110 brightness-90"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-transparent to-black/30 opacity-60 group-hover:opacity-90 transition-opacity" />

              {/* Hover Overlay */}
              <div className="absolute inset-0 p-6 flex flex-col justify-between opacity-0 group-hover:opacity-100 transition-all duration-300">
                <div className="self-end p-2 rounded-xl bg-red-600 text-white shadow-lg">
                  <ZoomIn className="w-4 h-4" />
                </div>

                <div>
                  <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-[#FF3B30]">
                    {item.cat}
                  </span>
                  <h3 className="text-sm font-bold text-white font-mono mt-0.5">{item.title}</h3>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Modal */}
      {lightboxImg && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative max-w-4xl w-full bg-[#111111] border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
            <button
              onClick={() => setLightboxImg(null)}
              className="absolute top-4 right-4 z-10 p-2 rounded-full bg-black/70 hover:bg-black text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <img
              src={lightboxImg.url}
              alt={lightboxImg.title}
              className="w-full h-[550px] object-cover"
            />

            <div className="p-4 bg-[#0A0A0A] text-center border-t border-white/10">
              <span className="text-sm font-bold text-white font-mono">{lightboxImg.title}</span>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
