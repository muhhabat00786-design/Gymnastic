import React, { useState } from 'react';
import { Calendar, Sparkles, Check, Download, RefreshCw, Dumbbell, Zap, Flame, Clock } from 'lucide-react';

export const WorkoutPlanner: React.FC = () => {
  const [goal, setGoal] = useState<string>('Muscle Hypertrophy');
  const [experience, setExperience] = useState<string>('Intermediate');
  const [daysCount, setDaysCount] = useState<number>(4);
  const [generating, setGenerating] = useState<boolean>(false);

  const [activeDay, setActiveDay] = useState<number>(0);

  const [schedule, setSchedule] = useState([
    {
      day: 'Day 1 (Monday)',
      title: 'Chest & Triceps Hypertrophy',
      focus: 'Upper Body Push Mechanics',
      duration: '60 Mins',
      exercises: [
        { name: 'Incline Barbell Bench Press', sets: '4 Sets', reps: '8-10 Reps', rest: '90s' },
        { name: 'Weighted Parallel Bar Dips', sets: '3 Sets', reps: '10 Reps', rest: '90s' },
        { name: 'Cable Chest Flyes (Low-to-High)', sets: '4 Sets', reps: '12-15 Reps', rest: '60s' },
        { name: 'Overhead Rope Tricep Extensions', sets: '4 Sets', reps: '12 Reps', rest: '60s' }
      ]
    },
    {
      day: 'Day 2 (Tuesday)',
      title: 'Back & Biceps Thickness',
      focus: 'Posterior Chain Pull Mechanics',
      duration: '65 Mins',
      exercises: [
        { name: 'Conventional Deadlifts', sets: '4 Sets', reps: '5 Reps', rest: '180s' },
        { name: 'Wide Grip Lat Pulldowns', sets: '4 Sets', reps: '10 Reps', rest: '90s' },
        { name: 'Seated Cable Rows (Neutral Grip)', sets: '3 Sets', reps: '12 Reps', rest: '60s' },
        { name: 'Incline Dumbbell Bicep Curls', sets: '4 Sets', reps: '12 Reps', rest: '60s' }
      ]
    },
    {
      day: 'Day 3 (Wednesday)',
      title: 'Active Recovery & Cryotherapy',
      focus: 'Mobility & Infrared Sauna',
      duration: '45 Mins',
      exercises: [
        { name: '38°C Infrared Yoga Flow', sets: '1 Session', reps: '30 Mins', rest: '-' },
        { name: 'Infrared Salt Sauna Therapy', sets: '1 Session', reps: '20 Mins', rest: '-' },
        { name: 'Cold Plunge Immersion (8°C)', sets: '3 Rounds', reps: '3 Mins Each', rest: '5 Mins' }
      ]
    },
    {
      day: 'Day 4 (Thursday)',
      title: 'Legs & Abs Explosive Power',
      focus: 'Lower Body Compound Biomechanics',
      duration: '70 Mins',
      exercises: [
        { name: 'Barbell Back Squats', sets: '4 Sets', reps: '6-8 Reps', rest: '120s' },
        { name: 'Romanian Deadlifts (RDL)', sets: '4 Sets', reps: '10 Reps', rest: '90s' },
        { name: 'Walking Dumbbell Lunges', sets: '3 Sets', reps: '12 Reps/leg', rest: '60s' },
        { name: 'Hanging Captain Chair Leg Raises', sets: '4 Sets', reps: '15 Reps', rest: '45s' }
      ]
    },
    {
      day: 'Day 5 (Friday)',
      title: 'Shoulders & Arms Aesthetics',
      focus: 'Deltoid Isolation & Arm Volume',
      duration: '55 Mins',
      exercises: [
        { name: 'Seated Dumbbell Overhead Press', sets: '4 Sets', reps: '8-10 Reps', rest: '90s' },
        { name: 'Cable Lateral Raises', sets: '5 Sets', reps: '15 Reps', rest: '45s' },
        { name: 'Barbell Preacher Curls', sets: '4 Sets', reps: '10-12 Reps', rest: '60s' },
        { name: 'Tricep Cable Pushdowns', sets: '4 Sets', reps: '12 Reps', rest: '60s' }
      ]
    }
  ]);

  const handleGeneratePlan = async () => {
    setGenerating(true);
    try {
      const res = await fetch('/api/ai-workout-gen', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          goal,
          experience,
          daysPerWeek: daysCount
        })
      });
      const data = await res.json();
      if (data.days && Array.isArray(data.days)) {
        const formattedDays = data.days.map((d: any, idx: number) => ({
          day: d.day || `Day ${idx + 1}`,
          title: d.focus || 'Custom VORTEX Protocol',
          focus: goal,
          duration: '60 Mins',
          exercises: (d.exercises || []).map((exStr: string) => ({
            name: exStr,
            sets: '4 Sets',
            reps: '10-12 Reps',
            rest: '60s'
          }))
        }));
        setSchedule(formattedDays);
      }
    } catch (err) {
      console.error('Plan generation failed', err);
    } finally {
      setGenerating(false);
    }
  };

  const handleDownloadPlan = () => {
    const textContent = `VORTEX ULTRA-LUXURY WORKOUT PLAN
Goal: ${goal} | Level: ${experience}
==========================================
` + schedule.map(s => `
[${s.day}] - ${s.title}
Focus: ${s.focus} (${s.duration})
Exercises:
` + s.exercises.map(e => `  - ${e.name} | ${e.sets} | ${e.reps} | Rest: ${e.rest}`).join('\n')).join('\n');

    const blob = new Blob([textContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `vortex-workout-plan.txt`;
    a.click();
  };

  return (
    <section id="planner" className="py-24 bg-[#0A0A0A] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Calendar className="w-3.5 h-3.5" />
            <span>AI Interactive Schedule</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            INTELLIGENT <span className="text-gradient-red">WORKOUT PLANNER.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Customize your athletic split or generate a hyper-personalized protocol powered by VORTEX AI biometrics.
          </p>
        </div>

        {/* Form Controls Bar */}
        <div className="glass-card p-6 border-white/10 mb-12">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 items-end">
            
            <div>
              <label className="block text-xs font-bold text-[#B8B8B8] uppercase tracking-wider mb-2">Primary Goal</label>
              <select
                value={goal}
                onChange={(e) => setGoal(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs font-semibold focus:outline-none focus:border-red-500"
              >
                <option value="Muscle Hypertrophy">Muscle Hypertrophy</option>
                <option value="Fat Shred HIIT">Fat Shred HIIT</option>
                <option value="Powerlifting Heavy">Powerlifting Heavy</option>
                <option value="Athletic VO2 Max">Athletic VO2 Max</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#B8B8B8] uppercase tracking-wider mb-2">Experience Level</label>
              <select
                value={experience}
                onChange={(e) => setExperience(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs font-semibold focus:outline-none focus:border-red-500"
              >
                <option value="Beginner">Beginner</option>
                <option value="Intermediate">Intermediate</option>
                <option value="Elite Pro">Elite Pro</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-[#B8B8B8] uppercase tracking-wider mb-2">Days / Week</label>
              <div className="flex gap-2">
                {[3, 4, 5, 6].map((num) => (
                  <button
                    key={num}
                    type="button"
                    onClick={() => setDaysCount(num)}
                    className={`flex-1 py-2.5 rounded-xl text-xs font-mono font-bold transition-all ${
                      daysCount === num ? 'bg-[#FF3B30] text-white' : 'bg-[#0A0A0A] border border-white/10 text-[#B8B8B8]'
                    }`}
                  >
                    {num}D
                  </button>
                ))}
              </div>
            </div>

            <div>
              <button
                onClick={handleGeneratePlan}
                disabled={generating}
                className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-[#FF3B30] to-[#FF0000] hover:from-[#FF0000] hover:to-[#CC0000] text-xs font-extrabold text-white uppercase tracking-wider shadow-lg shadow-red-600/30 flex items-center justify-center gap-2 transition-all"
              >
                {generating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                <span>{generating ? 'Engine Processing...' : 'Generate Plan'}</span>
              </button>
            </div>

          </div>
        </div>

        {/* Schedule Display */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Day Tabs */}
          <div className="lg:col-span-4 flex flex-col gap-2">
            {schedule.map((item, idx) => (
              <button
                key={idx}
                onClick={() => setActiveDay(idx)}
                className={`p-4 rounded-2xl text-left border transition-all duration-300 flex items-center justify-between ${
                  activeDay === idx
                    ? 'bg-gradient-to-r from-red-950/80 to-[#111111] border-red-500 text-white shadow-xl'
                    : 'glass-card border-white/5 text-[#B8B8B8] hover:text-white hover:border-white/15'
                }`}
              >
                <div>
                  <span className="block text-[10px] font-mono font-bold uppercase text-[#FF3B30]">{item.day}</span>
                  <span className="block text-sm font-bold text-white font-mono mt-0.5">{item.title}</span>
                </div>
                <Clock className="w-4 h-4 text-[#B8B8B8]" />
              </button>
            ))}

            <button
              onClick={handleDownloadPlan}
              className="mt-4 p-3 rounded-xl bg-[#111111] border border-white/10 hover:border-red-500/40 text-xs font-bold text-white uppercase tracking-wider flex items-center justify-center gap-2 transition-all"
            >
              <Download className="w-4 h-4 text-[#FF3B30]" />
              <span>Export Schedule (.TXT)</span>
            </button>
          </div>

          {/* Active Day Exercises Detail */}
          <div className="lg:col-span-8 glass-card p-6 sm:p-8 border-white/10">
            {schedule[activeDay] && (
              <div className="space-y-6">
                <div className="flex items-center justify-between pb-4 border-b border-white/10">
                  <div>
                    <span className="text-xs font-bold text-[#FF3B30] uppercase tracking-widest font-mono">
                      {schedule[activeDay].day} Focus
                    </span>
                    <h3 className="text-2xl font-extrabold text-white font-mono mt-1">
                      {schedule[activeDay].title}
                    </h3>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30 text-xs font-mono text-white">
                    {schedule[activeDay].duration}
                  </span>
                </div>

                <div className="space-y-3">
                  {schedule[activeDay].exercises.map((ex, exIdx) => (
                    <div
                      key={exIdx}
                      className="p-4 rounded-xl bg-[#0A0A0A] border border-white/5 hover:border-red-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-3 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg bg-red-950/60 border border-red-500/30 flex items-center justify-center text-[#FF3B30] font-mono text-xs font-bold">
                          0{exIdx + 1}
                        </div>
                        <span className="text-sm font-bold text-white font-mono">{ex.name}</span>
                      </div>

                      <div className="flex items-center gap-4 text-xs font-mono text-[#B8B8B8]">
                        <span className="px-2.5 py-1 rounded-md bg-white/5 font-semibold text-white">{ex.sets}</span>
                        <span className="px-2.5 py-1 rounded-md bg-white/5 font-semibold text-white">{ex.reps}</span>
                        <span className="text-red-400">Rest: {ex.rest}</span>
                      </div>
                    </div>
                  ))}
                </div>

              </div>
            )}
          </div>

        </div>

      </div>
    </section>
  );
};
