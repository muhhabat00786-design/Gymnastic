import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronRight, Home } from 'lucide-react';

export const Breadcrumbs: React.FC = () => {
  const location = useLocation();
  const pathnames = location.pathname.split('/').filter((x) => x);

  if (pathnames.length === 0) return null;

  return (
    <nav className="bg-[#080808] border-b border-white/5 py-3 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto flex items-center gap-2 text-xs font-medium text-neutral-400">
        <Link to="/" className="hover:text-white transition-colors flex items-center gap-1">
          <Home className="w-3.5 h-3.5 text-[#FF3B30]" /> Home
        </Link>
        
        {pathnames.map((name, index) => {
          const routeTo = `/${pathnames.slice(0, index + 1).join('/')}`;
          const isLast = index === pathnames.length - 1;
          const formattedName = name.replace(/-/g, ' ').replace(/\b\w/g, l => l.toUpperCase());

          return (
            <React.Fragment key={name}>
              <ChevronRight className="w-3.5 h-3.5 text-neutral-600" />
              {isLast ? (
                <span className="text-white font-semibold capitalize">{formattedName}</span>
              ) : (
                <Link to={routeTo} className="hover:text-white transition-colors capitalize">
                  {formattedName}
                </Link>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </nav>
  );
};
