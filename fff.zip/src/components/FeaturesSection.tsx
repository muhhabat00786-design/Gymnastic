import React from 'react';
import { 
  Clock, 
  Dumbbell, 
  UserCheck, 
  Utensils, 
  ShieldAlert, 
  Flame, 
  Droplets, 
  Waves, 
  Activity, 
  Zap, 
  Target, 
  Heart, 
  Sparkles, 
  Snowflake, 
  Car, 
  Wifi, 
  Lock, 
  Coffee 
} from 'lucide-react';

export const FeaturesSection: React.FC = () => {
  const features = [
    { icon: Clock, title: '24/7 Global Access', desc: 'Seamless biometric keycard entry anytime day or night across all worldwide locations.' },
    { icon: Dumbbell, title: 'Technogym Custom Equipment', desc: 'Biomotion biomechanics, OLED touch telemetry, and plate-loaded hammer strength.' },
    { icon: UserCheck, title: 'Olympic Master Trainers', desc: '1-on-1 coaching with world-champion bodybuilders, powerlifters, and VO2 experts.' },
    { icon: Utensils, title: 'Custom AI Nutrition Plans', desc: 'Macros tailored specifically to your metabolic rate, lean muscle target, and lifestyle.' },
    { icon: ShieldAlert, title: 'Executive Locker Suites', desc: 'Private heated marble rain showers, Dyson hair care, and plush plush towel service.' },
    { icon: Flame, title: 'Eucalyptus Steam Room', desc: 'Purify respiratory channels and release muscular tension at 45°C humid steam.' },
    { icon: Droplets, title: 'Himalayan Salt Sauna', desc: 'Pink salt ionizer sauna engineered to accelerate cell detox and joint recovery.' },
    { icon: Waves, title: 'Olympic Lap Pool', desc: '25-meter temperature-controlled UV purified saltwater pool with dedicated speed lanes.' },
    { icon: Activity, title: 'Cardio Theater Suite', desc: 'OLED screens with Apple Watch sync, Woodway treadmills, and Wattbike Pros.' },
    { icon: Zap, title: 'Heavy Iron Zone', desc: 'Calibrated Eleiko competition bumper plates, Texas power bars, and dumbbell racks up to 100kg.' },
    { icon: Target, title: 'Rogue CrossFit Box', desc: 'Full Rogue Monster rigs, Concept2 Rowers, SkiErgs, and assault air bikes.' },
    { icon: Heart, title: "Women's Private Suite", desc: 'Exclusive secluded sanctuary with dedicated glute machines, dumbbells, and vanity.' },
    { icon: Sparkles, title: 'Infrared Yoga & Pilates', desc: '38°C infrared heating panels that warm body tissue deeply for enhanced flexibility.' },
    { icon: Snowflake, title: 'Cryotherapy & Cold Plunge', desc: '-110°C full body cryo chamber and 8°C chilled ice baths for instant inflammation reduction.' },
    { icon: Car, title: 'Free Valet Parking', desc: 'Complimentary white-glove valet parking for all Pro and VIP members.' },
    { icon: Wifi, title: 'Ultra High-Speed WiFi 7', desc: '1Gbps symmetrical connectivity throughout the entire club and lounge areas.' },
    { icon: Lock, title: 'Smart Biometric Lockers', desc: 'RFID wristband lockers with built-in USB-C fast wireless device chargers.' },
    { icon: Coffee, title: 'Artisanal Protein Lounge', desc: 'Freshly shaken organic grass-fed whey smoothies, cold brew, and bcaa elixirs.' }
  ];

  return (
    <section className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      
      {/* Background Red Glow Accent */}
      <div className="absolute top-0 left-1/4 w-96 h-96 bg-red-600/10 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Title */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Zap className="w-3.5 h-3.5" />
            <span>World-Class Amenities</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            UNRIVALED <span className="text-gradient-red">LUXURY AMENITIES.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Every square inch of VORTEX is curated with high-performance engineering, medical-grade recovery tools, and five-star hospitality.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feat, idx) => {
            const Icon = feat.icon;
            return (
              <div
                key={idx}
                className="glass-card p-6 glass-card-hover border-white/10 hover:border-red-500/40 relative group overflow-hidden"
              >
                {/* Glowing Corner Accent */}
                <div className="absolute -top-10 -right-10 w-20 h-20 bg-red-600/0 group-hover:bg-red-600/20 rounded-full blur-xl transition-all duration-500 pointer-events-none" />

                <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-red-950/80 to-[#111111] border border-red-500/30 flex items-center justify-center text-[#FF3B30] mb-5 group-hover:scale-110 group-hover:bg-gradient-to-tr group-hover:from-[#FF3B30] group-hover:to-[#FF0000] group-hover:text-white transition-all duration-300 shadow-lg shadow-red-950/40">
                  <Icon className="w-6 h-6" />
                </div>

                <h3 className="text-lg font-bold text-white mb-2 font-mono group-hover:text-[#FF3B30] transition-colors">
                  {feat.title}
                </h3>
                
                <p className="text-xs text-[#B8B8B8] leading-relaxed">
                  {feat.desc}
                </p>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
