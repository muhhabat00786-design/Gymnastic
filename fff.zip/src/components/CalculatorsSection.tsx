import React, { useState } from 'react';
import { Calculator, Activity, Heart, ArrowRight, Check, Scale, Flame, RefreshCw, Copy } from 'lucide-react';

export const CalculatorsSection: React.FC = () => {
  const [activeTool, setActiveTool] = useState<'bmi' | 'calories'>('bmi');

  // BMI State
  const [height, setHeight] = useState<number>(178);
  const [weight, setWeight] = useState<number>(76);
  const [age, setAge] = useState<number>(28);
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [copied, setCopied] = useState<boolean>(false);

  // Calorie & Macro State
  const [activity, setActivity] = useState<number>(1.55); // Moderate
  const [goal, setGoal] = useState<'lose' | 'maintain' | 'gain'>('gain');

  // Calculations
  const heightM = height / 100;
  const bmi = Number((weight / (heightM * heightM)).toFixed(1));

  let bmiCategory = 'Normal Weight';
  let bmiColor = '#00E676'; // Success green
  let suggestion = 'Your BMI is in an ideal athletic range. Maintain progressive overload and high protein distribution.';

  if (bmi < 18.5) {
    bmiCategory = 'Underweight';
    bmiColor = '#FFC107'; // Warning yellow
    suggestion = 'Focus on hyper-caloric surplus (+400 kcal) with high complex carbs and heavy compound lifting.';
  } else if (bmi >= 25 && bmi < 29.9) {
    bmiCategory = 'Overweight';
    bmiColor = '#FFC107';
    suggestion = 'Incorporate Metabolic Shred HIIT twice weekly alongside a slight 300 kcal deficit.';
  } else if (bmi >= 30) {
    bmiCategory = 'Obese';
    bmiColor = '#FF3B30';
    suggestion = 'Recommend VORTEX Fat Loss protocol combined with active zone 2 cardio and metabolic consulting.';
  }

  // Ideal weight range calculation (BMI 18.5 - 24.9)
  const minIdealW = Math.round(18.5 * heightM * heightM);
  const maxIdealW = Math.round(24.9 * heightM * heightM);

  // BMR Calculation (Mifflin-St Jeor)
  const bmr = gender === 'male'
    ? Math.round(10 * weight + 6.25 * height - 5 * age + 5)
    : Math.round(10 * weight + 6.25 * height - 5 * age - 161);

  const tdee = Math.round(bmr * activity);

  let targetCalories = tdee;
  if (goal === 'lose') targetCalories = Math.round(tdee - 500);
  if (goal === 'gain') targetCalories = Math.round(tdee + 400);

  // Macro Splits (40% Protein / 40% Carbs / 20% Fat for gain, etc.)
  const proteinGrams = Math.round((targetCalories * 0.35) / 4);
  const carbsGrams = Math.round((targetCalories * 0.40) / 4);
  const fatGrams = Math.round((targetCalories * 0.25) / 9);

  const handleCopyReport = () => {
    const report = `VORTEX HEALTH REPORT:
- BMI: ${bmi} (${bmiCategory})
- Height: ${height}cm | Weight: ${weight}kg | Age: ${age}
- Ideal Weight Range: ${minIdealW}kg - ${maxIdealW}kg
- Daily Target Calories: ${targetCalories} kcal
- Recommended Macros: ${proteinGrams}g Protein | ${carbsGrams}g Carbs | ${fatGrams}g Fat`;

    navigator.clipboard.writeText(report);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section id="calculators" className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Calculator className="w-3.5 h-3.5" />
            <span>Biometric Analytics</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            PRECISION <span className="text-gradient-red">BIOMETRIC CALCULATORS.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Calculate your exact BMI composition, Basal Metabolic Rate (BMR), Total Daily Energy Expenditure (TDEE), and daily macro breakdown.
          </p>
        </div>

        {/* Tool Switcher Tabs */}
        <div className="flex justify-center mb-12">
          <div className="flex items-center gap-2 p-1.5 rounded-2xl bg-[#111111] border border-white/10 max-w-md w-full">
            <button
              onClick={() => setActiveTool('bmi')}
              className={`flex-1 py-3 px-6 rounded-xl text-xs font-extrabold uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                activeTool === 'bmi'
                  ? 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg shadow-red-600/30'
                  : 'text-[#B8B8B8] hover:text-white'
              }`}
            >
              <Scale className="w-4 h-4" />
              <span>BMI Calculator</span>
            </button>

            <button
              onClick={() => setActiveTool('calories')}
              className={`flex-1 py-3 px-6 rounded-xl text-xs font-extrabold uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                activeTool === 'calories'
                  ? 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg shadow-red-600/30'
                  : 'text-[#B8B8B8] hover:text-white'
              }`}
            >
              <Flame className="w-4 h-4" />
              <span>Calories & Macros</span>
            </button>
          </div>
        </div>

        {/* Main Tool Container */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Left Column: Form Inputs */}
          <div className="lg:col-span-6 glass-card p-6 sm:p-8 border-white/10">
            <h3 className="text-xl font-bold text-white mb-6 font-mono flex items-center gap-2">
              <Activity className="w-5 h-5 text-[#FF3B30]" />
              <span>Enter Your Parameters</span>
            </h3>

            <div className="space-y-6">
              
              {/* Gender Switch */}
              <div>
                <label className="block text-xs font-bold text-[#B8B8B8] uppercase tracking-wider mb-2">Gender</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    onClick={() => setGender('male')}
                    className={`py-2.5 rounded-xl text-xs font-bold uppercase transition-all ${
                      gender === 'male' ? 'bg-red-950/80 border border-red-500 text-white' : 'bg-black/50 border border-white/10 text-[#B8B8B8]'
                    }`}
                  >
                    Male
                  </button>
                  <button
                    type="button"
                    onClick={() => setGender('female')}
                    className={`py-2.5 rounded-xl text-xs font-bold uppercase transition-all ${
                      gender === 'female' ? 'bg-red-950/80 border border-red-500 text-white' : 'bg-black/50 border border-white/10 text-[#B8B8B8]'
                    }`}
                  >
                    Female
                  </button>
                </div>
              </div>

              {/* Height Slider */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-2">
                  <span className="text-[#B8B8B8] uppercase">Height</span>
                  <span className="text-white font-mono text-sm">{height} cm</span>
                </div>
                <input
                  type="range"
                  min="130"
                  max="220"
                  value={height}
                  onChange={(e) => setHeight(Number(e.target.value))}
                  className="w-full accent-[#FF3B30] bg-black/50 rounded-lg h-2 cursor-pointer"
                />
              </div>

              {/* Weight Slider */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-2">
                  <span className="text-[#B8B8B8] uppercase">Weight</span>
                  <span className="text-white font-mono text-sm">{weight} kg</span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="160"
                  value={weight}
                  onChange={(e) => setWeight(Number(e.target.value))}
                  className="w-full accent-[#FF3B30] bg-black/50 rounded-lg h-2 cursor-pointer"
                />
              </div>

              {/* Age Input */}
              <div>
                <div className="flex justify-between text-xs font-bold mb-2">
                  <span className="text-[#B8B8B8] uppercase">Age</span>
                  <span className="text-white font-mono text-sm">{age} Years</span>
                </div>
                <input
                  type="range"
                  min="16"
                  max="80"
                  value={age}
                  onChange={(e) => setAge(Number(e.target.value))}
                  className="w-full accent-[#FF3B30] bg-black/50 rounded-lg h-2 cursor-pointer"
                />
              </div>

              {/* Additional Inputs for Calorie Tool */}
              {activeTool === 'calories' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-[#B8B8B8] uppercase tracking-wider mb-2">Activity Level</label>
                    <select
                      value={activity}
                      onChange={(e) => setActivity(Number(e.target.value))}
                      className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs font-semibold focus:outline-none focus:border-red-500"
                    >
                      <option value={1.2}>Sedentary (Little or no exercise)</option>
                      <option value={1.375}>Light Active (1-3 days/week)</option>
                      <option value={1.55}>Moderate Active (3-5 days/week)</option>
                      <option value={1.725}>Very Active (6-7 days heavy lifting)</option>
                      <option value={1.9}>Elite Athlete (2x physical training daily)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-[#B8B8B8] uppercase tracking-wider mb-2">Primary Fitness Goal</label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        type="button"
                        onClick={() => setGoal('lose')}
                        className={`py-2 px-3 rounded-xl text-[11px] font-bold uppercase transition-all ${
                          goal === 'lose' ? 'bg-red-950/80 border border-red-500 text-white' : 'bg-black/50 border border-white/10 text-[#B8B8B8]'
                        }`}
                      >
                        Fat Loss
                      </button>
                      <button
                        type="button"
                        onClick={() => setGoal('maintain')}
                        className={`py-2 px-3 rounded-xl text-[11px] font-bold uppercase transition-all ${
                          goal === 'maintain' ? 'bg-red-950/80 border border-red-500 text-white' : 'bg-black/50 border border-white/10 text-[#B8B8B8]'
                        }`}
                      >
                        Maintain
                      </button>
                      <button
                        type="button"
                        onClick={() => setGoal('gain')}
                        className={`py-2 px-3 rounded-xl text-[11px] font-bold uppercase transition-all ${
                          goal === 'gain' ? 'bg-red-950/80 border border-red-500 text-white' : 'bg-black/50 border border-white/10 text-[#B8B8B8]'
                        }`}
                      >
                        Build Muscle
                      </button>
                    </div>
                  </div>
                </>
              )}

            </div>
          </div>

          {/* Right Column: Visual Gauge & Results */}
          <div className="lg:col-span-6 glass-card p-6 sm:p-8 border-white/10 flex flex-col justify-between">
            
            {activeTool === 'bmi' ? (
              <div className="space-y-6">
                <div className="text-center">
                  <span className="text-xs font-bold text-[#B8B8B8] uppercase tracking-widest font-mono">Calculated BMI Index</span>
                  <div className="text-5xl sm:text-6xl font-extrabold font-mono text-white mt-2" style={{ color: bmiColor }}>
                    {bmi}
                  </div>
                  <span className="inline-block mt-2 px-4 py-1 rounded-full text-xs font-extrabold uppercase font-mono border" style={{ color: bmiColor, borderColor: `${bmiColor}50`, backgroundColor: `${bmiColor}15` }}>
                    {bmiCategory}
                  </span>
                </div>

                {/* Animated Gauge Bar */}
                <div>
                  <div className="flex justify-between text-[10px] text-[#B8B8B8] font-mono mb-1">
                    <span>15 (Under)</span>
                    <span>18.5</span>
                    <span>25.0</span>
                    <span>30.0 (Obese)</span>
                  </div>
                  <div className="w-full h-3 rounded-full bg-black/60 relative overflow-hidden border border-white/10">
                    <div className="absolute inset-0 bg-gradient-to-r from-yellow-500 via-green-500 to-red-500" />
                    {/* Marker Pin */}
                    <div
                      className="absolute top-0 bottom-0 w-2 bg-white shadow-xl transform -translate-x-1/2 transition-all duration-500"
                      style={{ left: `${Math.min(100, Math.max(0, ((bmi - 15) / 20) * 100))}%` }}
                    />
                  </div>
                </div>

                {/* Biometric Breakdown Grid */}
                <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/10">
                  <div className="p-3 rounded-xl bg-white/5">
                    <span className="block text-[11px] text-[#B8B8B8]">Ideal Weight Range</span>
                    <span className="block font-bold text-sm text-white font-mono">{minIdealW} - {maxIdealW} kg</span>
                  </div>
                  <div className="p-3 rounded-xl bg-white/5">
                    <span className="block text-[11px] text-[#B8B8B8]">Estimated BMR</span>
                    <span className="block font-bold text-sm text-white font-mono">{bmr} kcal/day</span>
                  </div>
                </div>

                {/* Recommendation Box */}
                <div className="p-4 rounded-xl bg-red-950/30 border border-red-500/30 text-xs text-[#B8B8B8]">
                  <span className="block font-bold text-white font-mono mb-1">Coach Recommendation:</span>
                  <p>{suggestion}</p>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="text-center">
                  <span className="text-xs font-bold text-[#B8B8B8] uppercase tracking-widest font-mono">Daily Calorie Target</span>
                  <div className="text-5xl font-extrabold font-mono text-[#FF3B30] mt-2">
                    {targetCalories} <span className="text-lg text-white font-normal">kcal/day</span>
                  </div>
                  <span className="text-xs text-[#B8B8B8] mt-1 block">
                    Maintenance TDEE: <span className="text-white font-mono font-bold">{tdee} kcal</span>
                  </span>
                </div>

                {/* Macro Distribution Bars */}
                <div className="space-y-3 pt-2">
                  <div>
                    <div className="flex justify-between text-xs font-mono font-bold mb-1">
                      <span className="text-white">Protein (35%)</span>
                      <span className="text-[#FF3B30]">{proteinGrams}g</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-black/60 overflow-hidden">
                      <div className="h-full bg-[#FF3B30] rounded-full w-[35%]" />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-mono font-bold mb-1">
                      <span className="text-white">Carbohydrates (40%)</span>
                      <span className="text-[#00E676]">{carbsGrams}g</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-black/60 overflow-hidden">
                      <div className="h-full bg-[#00E676] rounded-full w-[40%]" />
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-xs font-mono font-bold mb-1">
                      <span className="text-white">Healthy Fats (25%)</span>
                      <span className="text-[#FFC107]">{fatGrams}g</span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-black/60 overflow-hidden">
                      <div className="h-full bg-[#FFC107] rounded-full w-[25%]" />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Action Bar */}
            <div className="pt-6 border-t border-white/10 mt-6 flex gap-3">
              <button
                onClick={handleCopyReport}
                className="w-full py-3 rounded-xl bg-[#111111] border border-white/15 hover:border-red-500/40 text-xs font-bold text-white uppercase tracking-wider flex items-center justify-center gap-2 transition-all"
              >
                {copied ? <Check className="w-4 h-4 text-[#00E676]" /> : <Copy className="w-4 h-4 text-[#FF3B30]" />}
                <span>{copied ? 'Report Copied!' : 'Copy Biometric Summary'}</span>
              </button>
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
