import React from 'react';
import { Smartphone, QrCode, Shield, Activity, Watch, Apple, Play } from 'lucide-react';

export const AppDownloadSection: React.FC = () => {
  return (
    <section className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      
      {/* Red Glow */}
      <div className="absolute top-1/2 left-0 w-96 h-96 bg-red-600/15 rounded-full blur-[160px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-card p-8 sm:p-12 border-white/10 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center bg-gradient-to-r from-red-950/30 via-[#111111] to-black">
          
          {/* Left Column: App Info & Badges */}
          <div className="lg:col-span-7 space-y-6">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-red-950/80 border border-red-500/40 text-xs font-bold uppercase tracking-widest text-[#FF3B30]">
              <Smartphone className="w-3.5 h-3.5" />
              <span>VORTEX Mobile OS</span>
            </div>

            <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white">
              CONTROL YOUR PERFORMANCE <span className="text-gradient-red">FROM ANYWHERE.</span>
            </h2>

            <p className="text-sm text-[#B8B8B8] leading-relaxed">
              Touchless biometric QR entry, real-time live club occupancy heatmaps, mobile locker reservation, and direct sync with Apple Health & Garmin.
            </p>

            {/* App Features List */}
            <div className="grid grid-cols-2 gap-4 pt-2">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-black/40 border border-white/5">
                <QrCode className="w-5 h-5 text-[#FF3B30]" />
                <div>
                  <span className="block text-xs font-bold text-white font-mono">Biometric Keycard</span>
                  <span className="text-[10px] text-[#B8B8B8]">Instant QR Entry</span>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-xl bg-black/40 border border-white/5">
                <Activity className="w-5 h-5 text-[#FF3B30]" />
                <div>
                  <span className="block text-xs font-bold text-white font-mono">Live Occupancy</span>
                  <span className="text-[10px] text-[#B8B8B8]">Heatmap Tracking</span>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-xl bg-black/40 border border-white/5">
                <Watch className="w-5 h-5 text-[#FF3B30]" />
                <div>
                  <span className="block text-xs font-bold text-white font-mono">Apple Watch Sync</span>
                  <span className="text-[10px] text-[#B8B8B8]">Heart Rate Telemetry</span>
                </div>
              </div>

              <div className="flex items-center gap-3 p-3 rounded-xl bg-black/40 border border-white/5">
                <Shield className="w-5 h-5 text-[#FF3B30]" />
                <div>
                  <span className="block text-xs font-bold text-white font-mono">Smart Lockers</span>
                  <span className="text-[10px] text-[#B8B8B8]">Keyless RFID Unlock</span>
                </div>
              </div>
            </div>

            {/* Download Buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-4 pt-4">
              <a
                href="#app"
                className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-white text-black font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-3 shadow-xl hover:bg-gray-200 transition-all"
              >
                <Apple className="w-5 h-5 fill-current" />
                <div className="text-left">
                  <span className="block text-[9px] uppercase font-bold text-gray-600">Download on</span>
                  <span className="block text-xs font-mono font-bold leading-none">App Store</span>
                </div>
              </a>

              <a
                href="#app"
                className="w-full sm:w-auto px-6 py-3.5 rounded-2xl bg-white/10 hover:bg-white/20 border border-white/20 text-white font-extrabold text-xs uppercase tracking-wider flex items-center justify-center gap-3 transition-all"
              >
                <Play className="w-5 h-5 fill-current text-green-400" />
                <div className="text-left">
                  <span className="block text-[9px] uppercase font-bold text-gray-400">Get it on</span>
                  <span className="block text-xs font-mono font-bold leading-none">Google Play</span>
                </div>
              </a>
            </div>

          </div>

          {/* Right Column: Phone Mockup */}
          <div className="lg:col-span-5 flex justify-center">
            <div className="relative w-64 h-[500px] bg-black border-4 border-gray-800 rounded-[40px] shadow-2xl p-4 overflow-hidden flex flex-col justify-between">
              
              {/* Phone Notch */}
              <div className="w-24 h-4 bg-gray-900 rounded-b-xl mx-auto mb-4" />

              {/* Simulated App Screen */}
              <div className="space-y-4">
                <div className="flex items-center justify-between pb-2 border-b border-white/10">
                  <span className="text-xs font-extrabold text-white font-mono">VORTEX OS</span>
                  <span className="w-2 h-2 rounded-full bg-[#00E676] animate-pulse" />
                </div>

                <div className="p-3 rounded-2xl bg-red-950/60 border border-red-500/40 text-center">
                  <QrCode className="w-24 h-24 mx-auto text-white p-2 bg-black rounded-xl border border-white/10 mb-2" />
                  <span className="text-[10px] text-white font-mono font-bold uppercase">MEMBER QR KEYCARD</span>
                </div>

                <div className="p-2.5 rounded-xl bg-white/5 text-xs text-[#B8B8B8] space-y-1">
                  <div className="flex justify-between text-white font-mono">
                    <span>Live Occupancy</span>
                    <span className="text-[#00E676]">28% Optimal</span>
                  </div>
                  <div className="w-full h-1.5 rounded-full bg-black overflow-hidden">
                    <div className="w-[28%] h-full bg-[#00E676]" />
                  </div>
                </div>
              </div>

              {/* Bottom Home Indicator */}
              <div className="w-20 h-1 bg-white/30 rounded-full mx-auto mt-4" />

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
