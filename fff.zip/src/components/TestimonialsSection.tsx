import React, { useState } from 'react';
import { Star, Quote, Play, CheckCircle2, X } from 'lucide-react';

export const TestimonialsSection: React.FC = () => {
  const [videoModalOpen, setVideoModalOpen] = useState(false);

  const reviews = [
    {
      name: 'Baroness Caroline von Steyn',
      role: 'VIP Elite Member since 2021',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=300&q=80',
      comment: 'The level of privacy, eucalyptus steam rooms, and biometrics at VORTEX is unmatched anywhere in Mayfair or Beverly Hills.'
    },
    {
      name: 'Alexander Croft',
      role: 'Pro Athlete Member',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      comment: 'As a competitive powerlifter, having competition Eleiko plates and sub-zero cryo recovery under one roof is revolutionary.'
    },
    {
      name: 'Dr. Evelyn Vance',
      role: 'Executive Member',
      rating: 5,
      avatar: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=300&q=80',
      comment: 'VORTEX AI nutrition plans transformed my blood lipid markers and metabolic energy within 12 weeks.'
    }
  ];

  return (
    <section className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
            <span>5-Star Global Ratings</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            WHAT OUR <span className="text-gradient-red">MEMBERS SAY.</span>
          </h2>
        </div>

        {/* Reviews Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {reviews.map((rev, idx) => (
            <div
              key={idx}
              className="glass-card p-6 border-white/10 glass-card-hover flex flex-col justify-between"
            >
              <div>
                {/* Stars */}
                <div className="flex gap-1 text-amber-400 mb-4">
                  {[...Array(rev.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>

                <p className="text-xs text-white leading-relaxed italic mb-6">
                  "{rev.comment}"
                </p>
              </div>

              <div className="flex items-center gap-3 pt-4 border-t border-white/10">
                <img
                  src={rev.avatar}
                  alt={rev.name}
                  className="w-10 h-10 rounded-full object-cover border border-red-500/40"
                />
                <div>
                  <div className="flex items-center gap-1">
                    <span className="font-bold text-xs text-white font-mono">{rev.name}</span>
                    <CheckCircle2 className="w-3.5 h-3.5 text-[#00E676]" />
                  </div>
                  <span className="text-[10px] text-[#B8B8B8]">{rev.role}</span>
                </div>
              </div>

            </div>
          ))}
        </div>

        {/* Video Testimonial Banner CTA */}
        <div className="mt-16 glass-card p-8 border-red-500/30 bg-gradient-to-r from-red-950/40 to-[#111111] flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#FF3B30] to-[#FF0000] flex items-center justify-center text-white shrink-0">
              <Play className="w-6 h-6 fill-current ml-1" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white font-mono">Watch Video Testimonials</h3>
              <p className="text-xs text-[#B8B8B8]">Hear directly from our global executives & athletic champions.</p>
            </div>
          </div>

          <button
            onClick={() => setVideoModalOpen(true)}
            className="px-6 py-3 rounded-xl bg-white/10 hover:bg-white/20 border border-white/20 text-xs font-bold text-white uppercase tracking-wider transition-all whitespace-nowrap"
          >
            Play Video Stories
          </button>
        </div>

      </div>

      {/* Video Modal */}
      {videoModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative w-full max-w-3xl bg-[#111111] border border-white/10 rounded-2xl overflow-hidden shadow-2xl">
            <button
              onClick={() => setVideoModalOpen(false)}
              className="absolute top-4 right-4 z-10 p-1.5 rounded-lg bg-black/80 text-white"
            >
              <X className="w-5 h-5" />
            </button>
            <div className="aspect-video w-full">
              <iframe
                className="w-full h-full"
                src="https://www.youtube.com/embed/dQw4w9WgXcQ?autoplay=1"
                title="Member Testimonials"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
