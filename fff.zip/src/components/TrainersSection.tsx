import React, { useState } from 'react';
import { TRAINERS } from '../data/gymData';
import { Trainer } from '../types';
import { Star, Award, Calendar, Instagram, Linkedin, Check, X, ShieldCheck, ChevronRight } from 'lucide-react';

export const TrainersSection: React.FC = () => {
  const [selectedTrainer, setSelectedTrainer] = useState<Trainer | null>(null);
  const [bookingDay, setBookingDay] = useState<string>('Mon');
  const [bookingSuccess, setBookingSuccess] = useState<boolean>(false);

  const handleBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingSuccess(true);
    setTimeout(() => {
      setBookingSuccess(false);
      setSelectedTrainer(null);
    }, 2500);
  };

  return (
    <section id="trainers" className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Award className="w-3.5 h-3.5" />
            <span>Master Performance Directors</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            MEET OUR <span className="text-gradient-red">WORLD-CLASS COACHES.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Former Olympians, IFBB Pro bodybuilders, and biomechanics researchers dedicated to sculpting your highest potential.
          </p>
        </div>

        {/* Trainers Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {TRAINERS.map((trainer) => (
            <div
              key={trainer.id}
              className="glass-card overflow-hidden border-white/10 glass-card-hover flex flex-col justify-between group"
            >
              <div>
                <div className="relative h-80 overflow-hidden">
                  <img
                    src={trainer.photo}
                    alt={trainer.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 filter contrast-110 brightness-95"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-transparent to-transparent" />

                  {/* Rating Badge */}
                  <div className="absolute top-4 right-4 px-3 py-1 rounded-full bg-black/80 backdrop-blur-md border border-white/15 flex items-center gap-1.5 text-xs font-bold font-mono text-white">
                    <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                    <span>{trainer.rating}</span>
                    <span className="text-[#B8B8B8] text-[10px]">({trainer.reviewsCount})</span>
                  </div>
                </div>

                <div className="p-6">
                  <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#FF3B30] font-mono">
                    {trainer.role}
                  </span>

                  <h3 className="text-xl font-bold text-white mt-1 mb-2 font-mono group-hover:text-[#FF3B30] transition-colors">
                    {trainer.name}
                  </h3>

                  <p className="text-xs text-[#B8B8B8] leading-relaxed mb-4 line-clamp-2">
                    {trainer.bio}
                  </p>

                  {/* Specializations Tags */}
                  <div className="flex flex-wrap gap-1.5 mb-6">
                    {trainer.specialization.map((spec, sIdx) => (
                      <span key={sIdx} className="px-2.5 py-1 rounded-md bg-white/5 border border-white/5 text-[10px] font-semibold text-[#B8B8B8]">
                        {spec}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0 space-y-3">
                <button
                  onClick={() => {
                    setSelectedTrainer(trainer);
                    setBookingDay(trainer.availableDays[0] || 'Mon');
                    setBookingSuccess(false);
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-red-950/60 to-[#111111] border border-red-500/40 hover:border-red-500 text-xs font-bold text-white uppercase tracking-wider flex items-center justify-center gap-2 group-hover:bg-gradient-to-r group-hover:from-[#FF3B30] group-hover:to-[#FF0000] transition-all duration-300 shadow-md"
                >
                  <Calendar className="w-4 h-4 text-[#FF3B30] group-hover:text-white" />
                  <span>Book 1-on-1 Session</span>
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Appointment Modal */}
      {selectedTrainer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-[#111111] border border-white/10 rounded-2xl p-6 shadow-2xl">
            <button
              onClick={() => setSelectedTrainer(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {bookingSuccess ? (
              <div className="text-center py-8 space-y-4">
                <div className="w-16 h-16 rounded-full bg-green-500/20 text-[#00E676] flex items-center justify-center mx-auto border border-green-500/40">
                  <Check className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-white font-mono">Private Session Reserved!</h3>
                <p className="text-xs text-[#B8B8B8]">
                  Your appointment with <span className="text-white font-bold">{selectedTrainer.name}</span> on <span className="text-white font-bold">{bookingDay}</span> has been locked into the club calendar.
                </p>
              </div>
            ) : (
              <form onSubmit={handleBookSubmit} className="space-y-4">
                <div className="text-center mb-6">
                  <span className="text-xs font-bold text-[#FF3B30] uppercase tracking-widest font-mono">Private Coaching</span>
                  <h3 className="text-2xl font-extrabold text-white font-mono mt-1">Book {selectedTrainer.name}</h3>
                  <p className="text-xs text-[#B8B8B8] mt-1">{selectedTrainer.role} ({selectedTrainer.experience})</p>
                </div>

                {/* Day Selection */}
                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-2">Available Slots</label>
                  <div className="flex gap-2 overflow-x-auto pb-2">
                    {selectedTrainer.availableDays.map((day) => (
                      <button
                        key={day}
                        type="button"
                        onClick={() => setBookingDay(day)}
                        className={`py-2 px-4 rounded-xl text-xs font-mono font-bold uppercase transition-all ${
                          bookingDay === day ? 'bg-[#FF3B30] text-white' : 'bg-[#0A0A0A] border border-white/10 text-[#B8B8B8]'
                        }`}
                      >
                        {day}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Your Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Jordan Belfort"
                    className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    placeholder="+1 (555) 333-2222"
                    className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#FF3B30] to-[#FF0000] font-extrabold text-xs text-white uppercase tracking-wider shadow-lg shadow-red-600/40 hover:scale-[1.02] transition-all"
                >
                  Confirm Appointment
                </button>
              </form>
            )}

          </div>
        </div>
      )}

    </section>
  );
};
