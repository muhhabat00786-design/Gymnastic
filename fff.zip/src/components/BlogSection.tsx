import React, { useState } from 'react';
import { BLOG_POSTS } from '../data/gymData';
import { BlogPost } from '../types';
import { BookOpen, Clock, User, ChevronRight, X, Search } from 'lucide-react';

export const BlogSection: React.FC = () => {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const filteredPosts = BLOG_POSTS.filter(post =>
    post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    post.summary.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section id="blog" className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <BookOpen className="w-3.5 h-3.5" />
            <span>Sports Science & Biohacking</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            THE VORTEX <span className="text-gradient-red">JOURNAL.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Evidence-based research on hypertrophy biomechanics, contrast therapy, and metabolic optimization.
          </p>
        </div>

        {/* Search Bar */}
        <div className="max-w-md mx-auto mb-12">
          <div className="relative">
            <input
              type="text"
              placeholder="Search research topics (e.g. Hypertrophy, Sauna)..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-3 rounded-2xl bg-[#111111] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
            />
            <Search className="w-4 h-4 text-[#B8B8B8] absolute left-3.5 top-3.5" />
          </div>
        </div>

        {/* Blog Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {filteredPosts.map((post) => (
            <div
              key={post.id}
              className="glass-card overflow-hidden border-white/10 glass-card-hover flex flex-col justify-between group cursor-pointer"
              onClick={() => setSelectedPost(post)}
            >
              <div>
                <div className="relative h-52 overflow-hidden">
                  <img
                    src={post.image}
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter contrast-105"
                  />
                  <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-red-950/80 border border-red-500/40 text-[10px] font-mono font-bold uppercase text-white">
                    {post.category}
                  </span>
                </div>

                <div className="p-6">
                  <div className="flex items-center gap-3 text-[11px] text-[#B8B8B8] font-mono mb-3">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3 text-[#FF3B30]" />
                      {post.readTime}
                    </span>
                    <span>•</span>
                    <span>{post.date}</span>
                  </div>

                  <h3 className="text-lg font-bold text-white font-mono mb-2 group-hover:text-[#FF3B30] transition-colors leading-snug">
                    {post.title}
                  </h3>

                  <p className="text-xs text-[#B8B8B8] leading-relaxed line-clamp-3">
                    {post.summary}
                  </p>
                </div>
              </div>

              <div className="p-6 pt-0 flex items-center justify-between border-t border-white/10 pt-4">
                <span className="text-xs font-semibold text-[#B8B8B8] flex items-center gap-1">
                  <User className="w-3.5 h-3.5 text-[#FF3B30]" />
                  {post.author}
                </span>

                <span className="text-xs font-extrabold uppercase font-mono text-[#FF3B30] flex items-center gap-1 group-hover:translate-x-1 transition-transform">
                  <span>Read Article</span>
                  <ChevronRight className="w-3.5 h-3.5" />
                </span>
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Article Detail Modal */}
      {selectedPost && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-3xl bg-[#111111] border border-white/10 rounded-2xl p-6 sm:p-8 shadow-2xl max-h-[85vh] overflow-y-auto">
            <button
              onClick={() => setSelectedPost(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-xs font-mono font-bold uppercase text-[#FF3B30]">
              {selectedPost.category} • {selectedPost.readTime}
            </span>

            <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-mono mt-2 mb-4">
              {selectedPost.title}
            </h2>

            <div className="flex items-center gap-2 text-xs text-[#B8B8B8] mb-6">
              <span>Authored by <strong className="text-white">{selectedPost.author}</strong></span>
              <span>•</span>
              <span>Published {selectedPost.date}</span>
            </div>

            <img
              src={selectedPost.image}
              alt={selectedPost.title}
              className="w-full h-64 object-cover rounded-xl mb-6 border border-white/10"
            />

            <p className="text-sm text-[#B8B8B8] leading-relaxed mb-6 font-mono">
              {selectedPost.summary}
            </p>

            <div className="text-sm text-white leading-relaxed space-y-4">
              <p>
                Mechanical tension, muscle damage, and metabolic stress represent the three core pillars governing muscular adaptation. When a load is applied across muscle fibers, mechanosensors trigger the mTORC1 signaling pathway, accelerating protein synthesis over a 24-48 hour hyper-anabolic window.
              </p>
              <p>
                To maximize these adaptations at VORTEX, we recommend pairing heavy compound multi-joint movements with precise caloric and leucine thresholds immediately post-workout.
              </p>
            </div>

            <button
              onClick={() => setSelectedPost(null)}
              className="mt-8 w-full py-3 rounded-xl bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-xs font-extrabold text-white uppercase tracking-wider shadow-lg"
            >
              Close Article
            </button>
          </div>
        </div>
      )}

    </section>
  );
};
