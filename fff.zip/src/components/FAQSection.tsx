import React, { useState } from 'react';
import { HelpCircle, ChevronDown, Search } from 'lucide-react';

export const FAQSection: React.FC = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  const [searchQuery, setSearchQuery] = useState<string>('');

  const faqs = [
    {
      q: 'What makes VORTEX different from standard gyms?',
      a: 'VORTEX combines custom Technogym & Eleiko biomechanical apparatus with medical-grade recovery suites (cryotherapy, infrared salt saunas, eucalyptus steam, cold plunge), AI biometrics, and 5-star concierge hospitality.'
    },
    {
      q: 'Can I access all global VORTEX locations with my membership?',
      a: 'Yes. Pro Athlete, Elite VIP, and Corporate Legacy members enjoy unlimited touchless 24/7 keycard entry across all international club sanctuaries.'
    },
    {
      q: 'Are personal training sessions included in membership plans?',
      a: 'Pro Athlete plans include 2 complimentary sessions per month, while Elite VIP includes 4 monthly 1-on-1 sessions with our Master Performance Directors.'
    },
    {
      q: 'What is the guest policy for Elite VIP members?',
      a: 'Elite VIP members receive 4 complimentary VIP guest passes every calendar month. Guests enjoy full access to facilities and recovery suites.'
    },
    {
      q: 'How does the AI Fitness Assistant & Biometric QR Code work?',
      a: 'The VORTEX app automatically generates your encrypted touchless QR keycard. You can also chat 24/7 with VORTEX AI to generate custom workout splits, macro targets, and form advice.'
    },
    {
      q: 'What are the club operating hours?',
      a: 'Club floor, cardio theater, and recovery suites are open 24 Hours a Day, 7 Days a Week, 365 Days a Year.'
    }
  ];

  const filteredFaqs = faqs.filter(f =>
    f.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
    f.a.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <section className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Concierge Assistance</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            FREQUENTLY ASKED <span className="text-gradient-red">QUESTIONS.</span>
          </h2>
        </div>

        {/* Search Bar */}
        <div className="relative mb-8">
          <input
            type="text"
            placeholder="Search questions (e.g., Guest policy, 24/7 access)..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-2xl bg-[#111111] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
          />
          <Search className="w-4 h-4 text-[#B8B8B8] absolute left-3.5 top-3.5" />
        </div>

        {/* Accordion List */}
        <div className="space-y-4">
          {filteredFaqs.map((faq, idx) => {
            const isOpen = openIdx === idx;

            return (
              <div
                key={idx}
                className="glass-card border-white/10 overflow-hidden transition-all duration-300"
              >
                <button
                  onClick={() => setOpenIdx(isOpen ? null : idx)}
                  className="w-full p-6 text-left flex items-center justify-between gap-4 focus:outline-none"
                >
                  <span className="font-bold text-sm text-white font-mono">{faq.q}</span>
                  <ChevronDown
                    className={`w-5 h-5 text-[#FF3B30] shrink-0 transition-transform duration-300 ${
                      isOpen ? 'rotate-180' : ''
                    }`}
                  />
                </button>

                {isOpen && (
                  <div className="px-6 pb-6 pt-0 text-xs text-[#B8B8B8] leading-relaxed border-t border-white/5 font-mono">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
