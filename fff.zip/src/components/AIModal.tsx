import React, { useState } from 'react';
import { X, Sparkles, Send, Bot, User, RefreshCw } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const AIModal: React.FC = () => {
  const { isAiChatOpen, setIsAiChatOpen } = useAuth();
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([
    {
      role: 'assistant',
      text: "Greetings. I am VORTEX AI, your Master Performance & Nutrition Coach. How may I optimize your physical conditioning or macro strategy today?"
    }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  if (!isAiChatOpen) return null;

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim() || loading) return;

    const newMsgs = [...messages, { role: 'user' as const, text: query }];
    setMessages(newMsgs);
    if (!textToSend) setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/ai-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          conversationHistory: newMsgs.map(m => ({ role: m.role, text: m.text }))
        })
      });
      const data = await res.json();
      setMessages([...newMsgs, { role: 'assistant', text: data.response || 'System updated.' }]);
    } catch (err) {
      setMessages([...newMsgs, { role: 'assistant', text: 'VORTEX AI is syncing. Focus on progressive overload, consume 2g/kg protein, and rest well.' }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-2xl bg-[#0d0d0d] border border-red-500/30 rounded-2xl shadow-2xl overflow-hidden flex flex-col h-[600px] max-h-[85vh]">
        
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-red-950 via-black to-black border-b border-red-500/30 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-red-600/20 border border-red-500/40 text-[#FF3B30] flex items-center justify-center shadow-lg shadow-red-900/30">
              <Sparkles className="w-5 h-5 animate-spin" style={{ animationDuration: '6s' }} />
            </div>
            <div>
              <h3 className="text-base font-extrabold text-white flex items-center gap-2">
                VORTEX AI Coach <span className="text-[10px] px-2 py-0.5 rounded-full bg-red-950 text-red-400 font-mono font-bold uppercase border border-red-800/40">Gemini 3.6</span>
              </h3>
              <p className="text-xs text-neutral-400">Biomechanics • Macro Nutrition • Cryo Recovery</p>
            </div>
          </div>
          <button
            onClick={() => setIsAiChatOpen(false)}
            className="p-1.5 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Suggestion Chips */}
        <div className="p-3 bg-black/40 border-b border-white/5 flex gap-2 overflow-x-auto no-scrollbar text-xs">
          {[
            "Create 4-Day Hypertrophy Routine",
            "Optimal Post-Workout Macros",
            "Infrared Sauna vs Cold Plunge",
            "Fix My Bench Press Form"
          ].map((prompt, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(prompt)}
              className="px-3 py-1.5 rounded-full bg-white/5 hover:bg-red-950/40 border border-white/10 hover:border-red-500/30 text-neutral-300 hover:text-white transition-all whitespace-nowrap"
            >
              ⚡ {prompt}
            </button>
          ))}
        </div>

        {/* Chat Messages Body */}
        <div className="flex-1 p-4 overflow-y-auto space-y-4">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex gap-3 ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              {m.role === 'assistant' && (
                <div className="w-8 h-8 rounded-xl bg-red-950 border border-red-500/40 text-[#FF3B30] flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4" />
                </div>
              )}
              <div className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed max-w-[80%] ${
                m.role === 'user'
                  ? 'bg-[#FF3B30] text-white font-medium rounded-br-none shadow-md shadow-red-900/30'
                  : 'bg-[#141414] border border-white/10 text-neutral-200 rounded-bl-none whitespace-pre-wrap'
              }`}>
                {m.text}
              </div>
              {m.role === 'user' && (
                <div className="w-8 h-8 rounded-xl bg-white/10 text-white flex items-center justify-center flex-shrink-0 font-bold text-xs">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}
          {loading && (
            <div className="flex gap-3 items-center text-xs text-neutral-400 font-mono">
              <RefreshCw className="w-4 h-4 text-[#FF3B30] animate-spin" />
              <span>Analyzing biomechanical parameters & generating guidance...</span>
            </div>
          )}
        </div>

        {/* Input Bar */}
        <div className="p-3 bg-black border-t border-white/10 flex items-center gap-2">
          <input
            type="text"
            placeholder="Ask VORTEX AI about exercises, nutrition, recovery..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="flex-1 px-4 py-3 rounded-xl bg-[#111111] border border-white/10 text-white text-xs sm:text-sm focus:border-red-500 focus:outline-none placeholder-neutral-500"
          />
          <button
            onClick={() => handleSend()}
            disabled={loading || !input.trim()}
            className="p-3 rounded-xl bg-[#FF3B30] hover:bg-red-600 disabled:opacity-50 text-white font-bold transition-all"
          >
            <Send className="w-4 h-4" />
          </button>
        </div>

      </div>
    </div>
  );
};
