import React, { useState } from 'react';
import { Program } from '../types';
import { PROGRAMS } from '../data/gymData';
import { Flame, Clock, User, Zap, ChevronRight, Check, X } from 'lucide-react';

export const ProgramsSection: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [bookingModalProgram, setBookingModalProgram] = useState<Program | null>(null);
  const [bookingSuccess, setBookingSuccess] = useState(false);

  const categories = ['All', 'Bodybuilding', 'Weight Loss', 'CrossFit', 'Powerlifting', 'Yoga & Pilates', 'Combat Arts'];

  const filteredPrograms = selectedCategory === 'All'
    ? PROGRAMS
    : PROGRAMS.filter(p => p.category.toLowerCase().includes(selectedCategory.toLowerCase()));

  const handleBookSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setBookingSuccess(true);
    setTimeout(() => {
      setBookingSuccess(false);
      setBookingModalProgram(null);
    }, 2500);
  };

  return (
    <section id="programs" className="py-24 bg-[#0A0A0A] relative overflow-hidden">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between mb-12">
          <div>
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
              <Zap className="w-3.5 h-3.5" />
              <span>Olympic Curated Protocols</span>
            </div>
            <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white">
              EXPLORE OUR <span className="text-gradient-red">PROGRAMS.</span>
            </h2>
          </div>

          <p className="text-sm text-[#B8B8B8] max-w-md mt-4 md:mt-0">
            Scientifically structured athletic paths tailored for high performers seeking muscular density, cardiovascular stamina, or combat precision.
          </p>
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-2 overflow-x-auto pb-4 mb-10 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-5 py-2.5 rounded-xl text-xs font-extrabold uppercase tracking-wider whitespace-nowrap transition-all duration-300 ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg shadow-red-600/30'
                  : 'bg-[#111111] border border-white/10 text-[#B8B8B8] hover:text-white hover:border-white/20'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Programs Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPrograms.map((program) => (
            <div
              key={program.id}
              className="glass-card overflow-hidden border-white/10 glass-card-hover flex flex-col justify-between group"
            >
              <div>
                {/* Program Image & Badges */}
                <div className="relative h-56 overflow-hidden">
                  <img
                    src={program.image}
                    alt={program.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700 filter contrast-110 brightness-90"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-transparent to-black/40" />

                  {/* Category Pill */}
                  <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-black/70 backdrop-blur-md border border-white/15 text-[10px] font-extrabold uppercase tracking-widest text-white">
                    {program.category}
                  </span>

                  {/* Intensity Pill */}
                  <span className="absolute top-4 right-4 px-3 py-1 rounded-full bg-red-950/80 backdrop-blur-md border border-red-500/40 text-[10px] font-extrabold uppercase tracking-widest text-[#FF3B30]">
                    {program.intensity}
                  </span>

                  {/* Price Tag */}
                  <div className="absolute bottom-4 left-4 font-mono font-extrabold text-lg text-white">
                    {program.price}
                  </div>
                </div>

                {/* Content */}
                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-2 font-mono group-hover:text-[#FF3B30] transition-colors">
                    {program.title}
                  </h3>
                  
                  <p className="text-xs text-[#B8B8B8] leading-relaxed mb-6 line-clamp-2">
                    {program.description}
                  </p>

                  {/* Program Meta Details */}
                  <div className="grid grid-cols-3 gap-2 pt-4 border-t border-white/10 text-center">
                    <div className="p-2 rounded-xl bg-white/5">
                      <Clock className="w-3.5 h-3.5 text-[#FF3B30] mx-auto mb-1" />
                      <span className="block text-[10px] text-[#B8B8B8] font-semibold">Duration</span>
                      <span className="block text-xs font-bold text-white font-mono">{program.duration}</span>
                    </div>

                    <div className="p-2 rounded-xl bg-white/5">
                      <Flame className="w-3.5 h-3.5 text-[#FF3B30] mx-auto mb-1" />
                      <span className="block text-[10px] text-[#B8B8B8] font-semibold">Burn</span>
                      <span className="block text-xs font-bold text-white font-mono">{program.caloriesBurned}</span>
                    </div>

                    <div className="p-2 rounded-xl bg-white/5">
                      <User className="w-3.5 h-3.5 text-[#FF3B30] mx-auto mb-1" />
                      <span className="block text-[10px] text-[#B8B8B8] font-semibold">Coach</span>
                      <span className="block text-xs font-bold text-white truncate font-mono">{program.trainer.split(' ')[0]}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Button */}
              <div className="p-6 pt-0">
                <button
                  onClick={() => setBookingModalProgram(program)}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-red-950/60 to-[#111111] border border-red-500/40 hover:border-red-500 text-xs font-bold text-white uppercase tracking-wider flex items-center justify-center gap-2 group-hover:bg-gradient-to-r group-hover:from-[#FF3B30] group-hover:to-[#FF0000] transition-all duration-300 shadow-md"
                >
                  <span>Book Free Trial</span>
                  <ChevronRight className="w-4 h-4 text-[#FF3B30] group-hover:text-white" />
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Program Booking Modal */}
      {bookingModalProgram && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-[#111111] border border-white/10 rounded-2xl p-6 shadow-2xl">
            <button
              onClick={() => setBookingModalProgram(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {bookingSuccess ? (
              <div className="text-center py-8 space-y-4">
                <div className="w-16 h-16 rounded-full bg-green-500/20 text-[#00E676] flex items-center justify-center mx-auto border border-green-500/40">
                  <Check className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-white font-mono">Trial Reservation Confirmed!</h3>
                <p className="text-xs text-[#B8B8B8] max-w-xs mx-auto">
                  You are registered for <span className="text-white font-bold">{bookingModalProgram.title}</span>. Our concierge team has sent details to your inbox.
                </p>
              </div>
            ) : (
              <form onSubmit={handleBookSubmit} className="space-y-4">
                <div className="text-center mb-6">
                  <span className="text-xs font-bold text-[#FF3B30] uppercase tracking-widest font-mono">
                    VIP Trial Pass
                  </span>
                  <h3 className="text-2xl font-extrabold text-white font-mono mt-1">
                    Book {bookingModalProgram.title}
                  </h3>
                  <p className="text-xs text-[#B8B8B8] mt-1">
                    Led by Master Trainer {bookingModalProgram.trainer} ({bookingModalProgram.duration})
                  </p>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Marcus Aurelius"
                    className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-sm focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Email Address</label>
                  <input
                    type="email"
                    required
                    placeholder="marcus@vortex.club"
                    className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-sm focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Phone Number</label>
                  <input
                    type="tel"
                    required
                    placeholder="+1 (555) 000-8888"
                    className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-sm focus:outline-none focus:border-red-500"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#FF3B30] to-[#FF0000] font-extrabold text-sm text-white uppercase tracking-wider shadow-lg shadow-red-600/40 hover:scale-[1.02] transition-all"
                >
                  Confirm Free VIP Session
                </button>
              </form>
            )}

          </div>
        </div>
      )}

    </section>
  );
};
