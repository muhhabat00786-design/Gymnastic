import React, { useState } from 'react';
import { Search, X, Dumbbell, User, ShoppingBag, BookOpen, Calendar, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { PROGRAMS, TRAINERS, PRODUCTS, BLOG_POSTS, CLASS_SESSIONS } from '../data/gymData';

export const SearchModal: React.FC = () => {
  const { isSearchOpen, setIsSearchOpen } = useAuth();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState<'all' | 'programs' | 'trainers' | 'store' | 'blog' | 'classes'>('all');
  const navigate = useNavigate();

  if (!isSearchOpen) return null;

  const filteredPrograms = (category === 'all' || category === 'programs') ? PROGRAMS.filter(p => p.title.toLowerCase().includes(query.toLowerCase()) || p.category.toLowerCase().includes(query.toLowerCase())) : [];
  const filteredTrainers = (category === 'all' || category === 'trainers') ? TRAINERS.filter(t => t.name.toLowerCase().includes(query.toLowerCase()) || t.role.toLowerCase().includes(query.toLowerCase())) : [];
  const filteredProducts = (category === 'all' || category === 'store') ? PRODUCTS.filter(p => p.name.toLowerCase().includes(query.toLowerCase()) || p.category.toLowerCase().includes(query.toLowerCase())) : [];
  const filteredBlogs = (category === 'all' || category === 'blog') ? BLOG_POSTS.filter(b => b.title.toLowerCase().includes(query.toLowerCase()) || b.category.toLowerCase().includes(query.toLowerCase())) : [];
  const filteredClasses = (category === 'all' || category === 'classes') ? CLASS_SESSIONS.filter(c => c.className.toLowerCase().includes(query.toLowerCase()) || c.category.toLowerCase().includes(query.toLowerCase())) : [];

  const totalResults = filteredPrograms.length + filteredTrainers.length + filteredProducts.length + filteredBlogs.length + filteredClasses.length;

  const handleSelect = (path: string) => {
    setIsSearchOpen(false);
    navigate(path);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-16 px-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-3xl bg-[#0e0e0e] border border-white/10 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        
        {/* Search Bar Input */}
        <div className="p-4 border-b border-white/10 flex items-center gap-3">
          <Search className="w-5 h-5 text-[#FF3B30]" />
          <input
            type="text"
            placeholder="Search programs, trainers, products, articles, or classes..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="w-full bg-transparent text-white text-base focus:outline-none placeholder-neutral-500 font-medium"
            autoFocus
          />
          <button
            onClick={() => setIsSearchOpen(false)}
            className="p-1.5 rounded-lg text-neutral-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Chips */}
        <div className="px-4 py-2 border-b border-white/10 bg-[#0a0a0a] flex items-center gap-2 overflow-x-auto text-xs font-medium no-scrollbar">
          {(['all', 'programs', 'trainers', 'store', 'blog', 'classes'] as const).map(cat => (
            <button
              key={cat}
              onClick={() => setCategory(cat)}
              className={`px-3 py-1.5 rounded-full capitalize whitespace-nowrap transition-all ${
                category === cat
                  ? 'bg-[#FF3B30] text-white font-semibold shadow-md shadow-red-900/30'
                  : 'bg-white/5 text-neutral-400 hover:text-white hover:bg-white/10'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Search Results List */}
        <div className="p-4 overflow-y-auto space-y-6 divide-y divide-white/5">
          {query.trim() === '' ? (
            <div className="py-12 text-center text-neutral-500 text-sm">
              Type keywords like <span className="text-white font-medium">"Hypertrophy"</span>, <span className="text-white font-medium">"Marcus Vance"</span>, or <span className="text-white font-medium">"Pre-workout"</span>...
            </div>
          ) : totalResults === 0 ? (
            <div className="py-12 text-center text-neutral-400 text-sm">
              No matching search results found for "<span className="text-white font-semibold">{query}</span>".
            </div>
          ) : (
            <>
              {/* Programs */}
              {filteredPrograms.length > 0 && (
                <div>
                  <h4 className="text-xs uppercase tracking-wider text-[#FF3B30] font-bold mb-3 flex items-center gap-2">
                    <Dumbbell className="w-3.5 h-3.5" /> Programs ({filteredPrograms.length})
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {filteredPrograms.map(p => (
                      <div
                        key={p.id}
                        onClick={() => handleSelect(`/programs/${p.id}`)}
                        className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-red-500/30 transition-all cursor-pointer flex items-center gap-3 group"
                      >
                        <img src={p.image} alt={p.title} className="w-12 h-12 rounded-lg object-cover" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-white truncate group-hover:text-[#FF3B30] transition-colors">{p.title}</p>
                          <p className="text-xs text-neutral-400 truncate">{p.category} • {p.duration}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Trainers */}
              {filteredTrainers.length > 0 && (
                <div className="pt-4">
                  <h4 className="text-xs uppercase tracking-wider text-[#FF3B30] font-bold mb-3 flex items-center gap-2">
                    <User className="w-3.5 h-3.5" /> Elite Trainers ({filteredTrainers.length})
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {filteredTrainers.map(t => (
                      <div
                        key={t.id}
                        onClick={() => handleSelect(`/trainers/${t.id}`)}
                        className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-red-500/30 transition-all cursor-pointer flex items-center gap-3 group"
                      >
                        <img src={t.photo} alt={t.name} className="w-12 h-12 rounded-full object-cover" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-white truncate group-hover:text-[#FF3B30] transition-colors">{t.name}</p>
                          <p className="text-xs text-neutral-400 truncate">{t.role}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Products */}
              {filteredProducts.length > 0 && (
                <div className="pt-4">
                  <h4 className="text-xs uppercase tracking-wider text-[#FF3B30] font-bold mb-3 flex items-center gap-2">
                    <ShoppingBag className="w-3.5 h-3.5" /> Online Store ({filteredProducts.length})
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {filteredProducts.map(prod => (
                      <div
                        key={prod.id}
                        onClick={() => handleSelect('/store')}
                        className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-red-500/30 transition-all cursor-pointer flex items-center gap-3 group"
                      >
                        <img src={prod.image} alt={prod.name} className="w-12 h-12 rounded-lg object-cover" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-white truncate group-hover:text-[#FF3B30] transition-colors">{prod.name}</p>
                          <p className="text-xs text-[#FF3B30] font-semibold">${prod.price.toFixed(2)}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Blog */}
              {filteredBlogs.length > 0 && (
                <div className="pt-4">
                  <h4 className="text-xs uppercase tracking-wider text-[#FF3B30] font-bold mb-3 flex items-center gap-2">
                    <BookOpen className="w-3.5 h-3.5" /> Articles ({filteredBlogs.length})
                  </h4>
                  <div className="grid grid-cols-1 gap-2">
                    {filteredBlogs.map(b => (
                      <div
                        key={b.id}
                        onClick={() => handleSelect(`/blog/${b.id}`)}
                        className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-red-500/30 transition-all cursor-pointer flex items-center gap-3 group"
                      >
                        <img src={b.image} alt={b.title} className="w-12 h-12 rounded-lg object-cover" />
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-white truncate group-hover:text-[#FF3B30] transition-colors">{b.title}</p>
                          <p className="text-xs text-neutral-400 truncate">{b.category} • {b.readTime}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Classes */}
              {filteredClasses.length > 0 && (
                <div className="pt-4">
                  <h4 className="text-xs uppercase tracking-wider text-[#FF3B30] font-bold mb-3 flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5" /> Class Schedule ({filteredClasses.length})
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {filteredClasses.map(c => (
                      <div
                        key={c.id}
                        onClick={() => handleSelect('/schedule')}
                        className="p-2.5 rounded-xl bg-white/5 hover:bg-white/10 border border-white/5 hover:border-red-500/30 transition-all cursor-pointer flex items-center gap-3 group"
                      >
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-bold text-white truncate group-hover:text-[#FF3B30] transition-colors">{c.className}</p>
                          <p className="text-xs text-neutral-400 truncate">{c.day} @ {c.time} • {c.trainer}</p>
                        </div>
                        <ArrowRight className="w-4 h-4 text-neutral-500 group-hover:text-white transition-colors" />
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer info */}
        <div className="p-3 bg-black/60 border-t border-white/10 text-center text-[11px] text-neutral-500 flex justify-between px-6">
          <span>Search VORTEX Global Database</span>
          <span>Press ESC to close</span>
        </div>

      </div>
    </div>
  );
};
