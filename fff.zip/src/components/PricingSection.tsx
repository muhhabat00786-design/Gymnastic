import React, { useState } from 'react';
import { PRICING_PLANS } from '../data/gymData';
import { PricingPlan } from '../types';
import { Check, ShieldCheck, Zap, Sparkles, CreditCard, Download, X, Gift } from 'lucide-react';

export const PricingSection: React.FC = () => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('yearly');
  const [selectedPlan, setSelectedPlan] = useState<PricingPlan | null>(null);
  const [checkoutModalOpen, setCheckoutModalOpen] = useState<boolean>(false);
  const [promoCode, setPromoCode] = useState<string>('');
  const [discountApplied, setDiscountApplied] = useState<boolean>(false);
  const [paymentSuccess, setPaymentSuccess] = useState<boolean>(false);

  const handleApplyPromo = () => {
    if (promoCode.trim().toUpperCase() === 'VORTEX20') {
      setDiscountApplied(true);
    }
  };

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    setPaymentSuccess(true);
  };

  const handleDownloadInvoice = () => {
    if (!selectedPlan) return;
    const price = billingCycle === 'yearly' ? selectedPlan.priceYearly : selectedPlan.priceMonthly;
    const finalPrice = discountApplied ? Math.round(price * 0.8) : price;

    const receipt = `===========================================
VORTEX ULTRA-LUXURY FITNESS CLUB - RECEIPT
===========================================
Membership Tier: ${selectedPlan.name}
Billing Cycle: ${billingCycle.toUpperCase()}
Amount Paid: $${finalPrice} USD
Date: ${new Date().toLocaleDateString()}
Status: COMPLETED / VIP PASS ACTIVE
Ref ID: VTX-PAY-${Math.floor(100000 + Math.random() * 900000)}
===========================================
Thank you for joining VORTEX. Show your digital
QR keycard at club concierge for onboarding.`;

    const blob = new Blob([receipt], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `VORTEX-Receipt-${selectedPlan.name}.txt`;
    a.click();
  };

  return (
    <section id="pricing" className="py-24 bg-[#0A0A0A] relative overflow-hidden">
      
      {/* Background Red Glow */}
      <div className="absolute top-1/3 left-1/2 transform -translate-x-1/2 w-full max-w-4xl h-96 bg-red-600/10 rounded-full blur-[180px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Zap className="w-3.5 h-3.5" />
            <span>Membership Tiers</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            INVEST IN YOUR <span className="text-gradient-red">ULTRA PHYSICAL LEGACY.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Transparent pricing with zero hidden initiation fees. Select your tier to unlock world-class facilities and bio-coaching.
          </p>

          {/* Monthly / Yearly Toggle */}
          <div className="mt-8 inline-flex items-center gap-3 p-1.5 rounded-2xl bg-[#111111] border border-white/10 relative">
            <button
              onClick={() => setBillingCycle('monthly')}
              className={`py-2.5 px-6 rounded-xl text-xs font-extrabold uppercase tracking-wider transition-all ${
                billingCycle === 'monthly' ? 'bg-[#FF3B30] text-white shadow-lg' : 'text-[#B8B8B8] hover:text-white'
              }`}
            >
              Monthly Billing
            </button>

            <button
              onClick={() => setBillingCycle('yearly')}
              className={`py-2.5 px-6 rounded-xl text-xs font-extrabold uppercase tracking-wider transition-all flex items-center gap-2 ${
                billingCycle === 'yearly' ? 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg shadow-red-600/30' : 'text-[#B8B8B8] hover:text-white'
              }`}
            >
              <span>Annual Billing</span>
              <span className="px-2 py-0.5 rounded-full bg-green-500/20 text-[#00E676] text-[10px] font-mono font-bold">
                20% OFF
              </span>
            </button>
          </div>
        </div>

        {/* Pricing Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-20">
          {PRICING_PLANS.map((plan) => {
            const price = billingCycle === 'yearly' ? plan.priceYearly : plan.priceMonthly;

            return (
              <div
                key={plan.id}
                className={`glass-card p-6 sm:p-8 flex flex-col justify-between border-white/10 relative group transition-all duration-300 ${
                  plan.popular ? 'border-red-500/60 shadow-2xl shadow-red-950/50 scale-105 bg-gradient-to-b from-[#161616] to-[#0D0D0D]' : ''
                }`}
              >
                {/* Popular Ribbon */}
                {plan.popular && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white text-[10px] font-extrabold uppercase tracking-widest shadow-lg shadow-red-600/40">
                    Most Popular Choice
                  </div>
                )}

                {/* VIP Ribbon */}
                {plan.vip && (
                  <div className="absolute -top-4 left-1/2 transform -translate-x-1/2 px-4 py-1 rounded-full bg-gradient-to-r from-amber-500 to-yellow-600 text-black text-[10px] font-extrabold uppercase tracking-widest shadow-lg">
                    VIP Executive Status
                  </div>
                )}

                <div>
                  <div className="mb-6">
                    <span className="text-xs font-extrabold font-mono tracking-widest text-[#FF3B30] uppercase">
                      {plan.name}
                    </span>
                    <div className="flex items-baseline gap-1 mt-2">
                      <span className="text-4xl sm:text-5xl font-extrabold text-white font-mono">${price}</span>
                      <span className="text-xs text-[#B8B8B8] font-mono">/ mo</span>
                    </div>
                    <p className="text-xs text-[#B8B8B8] mt-3 leading-relaxed">
                      {plan.description}
                    </p>
                  </div>

                  {/* Features List */}
                  <div className="space-y-3 pt-6 border-t border-white/10">
                    {plan.features.map((feat, fIdx) => (
                      <div key={fIdx} className="flex items-start gap-2 text-xs text-white font-medium">
                        <Check className="w-4 h-4 text-[#FF3B30] shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="pt-8">
                  <button
                    onClick={() => {
                      setSelectedPlan(plan);
                      setCheckoutModalOpen(true);
                      setPaymentSuccess(false);
                      setDiscountApplied(false);
                    }}
                    className={`w-full py-3.5 rounded-xl font-extrabold text-xs uppercase tracking-wider transition-all duration-300 shadow-lg ${
                      plan.popular
                        ? 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] hover:from-[#FF0000] hover:to-[#CC0000] text-white shadow-red-600/40 hover:scale-105'
                        : 'bg-[#111111] border border-white/15 hover:border-red-500/50 text-white hover:bg-white/5'
                    }`}
                  >
                    Select {plan.name}
                  </button>
                </div>

              </div>
            );
          })}
        </div>

      </div>

      {/* Checkout Modal */}
      {checkoutModalOpen && selectedPlan && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative w-full max-w-lg bg-[#111111] border border-white/10 rounded-2xl p-6 sm:p-8 shadow-2xl">
            <button
              onClick={() => setCheckoutModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {paymentSuccess ? (
              <div className="text-center py-6 space-y-4">
                <div className="w-16 h-16 rounded-full bg-green-500/20 text-[#00E676] flex items-center justify-center mx-auto border border-green-500/40">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-white font-mono">Welcome to VORTEX Club!</h3>
                <p className="text-xs text-[#B8B8B8]">
                  Your <span className="text-white font-bold">{selectedPlan.name}</span> membership pass is activated. Your biometric QR keycard has been generated in your Member Portal.
                </p>

                <div className="pt-4 flex flex-col gap-3">
                  <button
                    onClick={handleDownloadInvoice}
                    className="w-full py-3 rounded-xl bg-gradient-to-r from-[#FF3B30] to-[#FF0000] font-extrabold text-xs text-white uppercase tracking-wider flex items-center justify-center gap-2 shadow-lg"
                  >
                    <Download className="w-4 h-4" />
                    <span>Download Official Receipt (.TXT)</span>
                  </button>

                  <button
                    onClick={() => setCheckoutModalOpen(false)}
                    className="w-full py-3 rounded-xl bg-white/10 text-xs font-bold text-white uppercase"
                  >
                    Close Window
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handlePay} className="space-y-4">
                <div className="text-center mb-6">
                  <span className="text-xs font-bold text-[#FF3B30] uppercase tracking-widest font-mono">VORTEX VIP Checkout</span>
                  <h3 className="text-2xl font-extrabold text-white font-mono mt-1">{selectedPlan.name} Membership</h3>
                  <div className="text-xl font-bold text-[#FF3B30] font-mono mt-1">
                    ${discountApplied 
                      ? Math.round((billingCycle === 'yearly' ? selectedPlan.priceYearly : selectedPlan.priceMonthly) * 0.8) 
                      : (billingCycle === 'yearly' ? selectedPlan.priceYearly : selectedPlan.priceMonthly)} / month
                    {discountApplied && <span className="text-xs text-[#00E676] ml-2 font-normal">(20% Promo Active)</span>}
                  </div>
                </div>

                {/* Promo Code Input */}
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Promo Code (Try VORTEX20)"
                    value={promoCode}
                    onChange={(e) => setPromoCode(e.target.value)}
                    className="flex-1 px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs font-mono uppercase focus:outline-none focus:border-red-500"
                  />
                  <button
                    type="button"
                    onClick={handleApplyPromo}
                    className="px-4 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-bold text-white uppercase"
                  >
                    Apply
                  </button>
                </div>

                {/* Card Details */}
                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Full Name</label>
                  <input
                    type="text"
                    required
                    placeholder="Alex Mercer"
                    className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Card Number</label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      placeholder="4000 1234 5678 9010"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-red-500"
                    />
                    <CreditCard className="w-4 h-4 text-[#B8B8B8] absolute right-3 top-3" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Expiry Date</label>
                    <input
                      type="text"
                      required
                      placeholder="MM/YY"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-red-500"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">CVC / CVC2</label>
                    <input
                      type="text"
                      required
                      placeholder="123"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs font-mono focus:outline-none focus:border-red-500"
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#FF3B30] to-[#FF0000] font-extrabold text-xs text-white uppercase tracking-wider shadow-lg shadow-red-600/40 hover:scale-[1.02] transition-all"
                >
                  Confirm & Pay Securely
                </button>
              </form>
            )}

          </div>
        </div>
      )}

    </section>
  );
};
