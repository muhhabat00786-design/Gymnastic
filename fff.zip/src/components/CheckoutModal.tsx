import React, { useState } from 'react';
import { X, CreditCard, ShieldCheck, CheckCircle2, Lock, Tag } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const CheckoutModal: React.FC = () => {
  const { isCheckoutOpen, setIsCheckoutOpen, cart, addOrder, user } = useAuth();
  
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'apple' | 'paypal'>('card');
  const [couponCode, setCouponCode] = useState('');
  const [discountApplied, setDiscountApplied] = useState(0);
  const [couponError, setCouponError] = useState('');

  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 8812');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('981');
  const [nameOnCard, setNameOnCard] = useState(user?.name || 'David Sterling');

  const [isProcessing, setIsProcessing] = useState(false);
  const [completedOrder, setCompletedOrder] = useState<any>(null);

  if (!isCheckoutOpen) return null;

  const rawSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  const discountAmount = (rawSubtotal * discountApplied) / 100;
  const shipping = rawSubtotal > 100 || rawSubtotal === 0 ? 0 : 15.00;
  const finalTotal = Math.max(0, rawSubtotal - discountAmount + shipping);

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (couponCode.toUpperCase() === 'VORTEXVIP' || couponCode.toUpperCase() === 'SHRED20') {
      setDiscountApplied(20);
      setCouponError('');
    } else {
      setCouponError('Invalid coupon code. Try "VORTEXVIP" for 20% off.');
    }
  };

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    setIsProcessing(true);
    setTimeout(() => {
      const order = addOrder(paymentMethod === 'card' ? 'Visa •••• 8812' : paymentMethod === 'apple' ? 'Apple Pay' : 'PayPal Express');
      setIsProcessing(false);
      setCompletedOrder(order);
    }, 1500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-xl bg-[#0e0e0e] border border-white/10 rounded-2xl shadow-2xl p-6 relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={() => {
            setIsCheckoutOpen(false);
            setCompletedOrder(null);
          }}
          className="absolute top-4 right-4 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {completedOrder ? (
          <div className="py-10 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-extrabold text-white">Payment Successful!</h3>
            <p className="text-sm text-neutral-400">Order Ref: <span className="text-[#FF3B30] font-mono font-bold">{completedOrder.id}</span></p>
            <div className="p-4 rounded-xl bg-white/5 text-left text-xs space-y-1.5 text-neutral-300 max-w-md mx-auto">
              <p><span className="text-neutral-500">Tracking Code:</span> {completedOrder.trackingNumber}</p>
              <p><span className="text-neutral-500">Payment Method:</span> {completedOrder.paymentMethod}</p>
              <p><span className="text-neutral-500">Total Charged:</span> ${completedOrder.totalAmount.toFixed(2)}</p>
            </div>
            <p className="text-xs text-neutral-500">Receipt and invoice have been sent to {user?.email || 'your email'}.</p>
            <button
              onClick={() => {
                setIsCheckoutOpen(false);
                setCompletedOrder(null);
              }}
              className="px-6 py-2.5 rounded-xl bg-[#FF3B30] text-white font-bold text-xs"
            >
              Back to Store
            </button>
          </div>
        ) : (
          <form onSubmit={handlePay} className="space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-red-950/50 border border-red-500/30 text-[#FF3B30]">
                <CreditCard className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-extrabold text-white">Secure Checkout</h3>
                <p className="text-xs text-neutral-400">256-Bit Encrypted VORTEX Payment Gateway</p>
              </div>
            </div>

            {/* Order Summary Box */}
            <div className="p-4 rounded-xl bg-black border border-white/10 space-y-2">
              <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider mb-2">Order Items ({cart.length})</h4>
              {cart.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between text-xs text-neutral-300">
                  <span className="truncate max-w-[200px]">{item.quantity}x {item.product.name}</span>
                  <span className="font-mono">${(item.product.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
              
              <div className="pt-2 mt-2 border-t border-white/10 space-y-1 text-xs">
                <div className="flex justify-between text-neutral-400">
                  <span>Subtotal</span>
                  <span className="font-mono">${rawSubtotal.toFixed(2)}</span>
                </div>
                {discountApplied > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount ({discountApplied}%)</span>
                    <span className="font-mono">-${discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-neutral-400">
                  <span>Express Shipping</span>
                  <span className="font-mono">{shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-white pt-1">
                  <span>Total Amount</span>
                  <span className="font-mono text-[#FF3B30]">${finalTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>

            {/* Coupon Code Input */}
            <div className="flex gap-2">
              <div className="relative flex-1">
                <Tag className="w-4 h-4 text-neutral-500 absolute left-3 top-3" />
                <input
                  type="text"
                  placeholder="Coupon Code (e.g. VORTEXVIP)"
                  value={couponCode}
                  onChange={(e) => setCouponCode(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none uppercase"
                />
              </div>
              <button
                type="button"
                onClick={handleApplyCoupon}
                className="px-4 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition-colors"
              >
                Apply
              </button>
            </div>
            {couponError && <p className="text-[11px] text-red-400">{couponError}</p>}
            {discountApplied > 0 && <p className="text-[11px] text-emerald-400">✓ 20% VORTEX VIP Discount applied!</p>}

            {/* Payment Method Tabs */}
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-2">Select Payment Method</label>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-2.5 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                    paymentMethod === 'card' ? 'bg-[#FF3B30] border-[#FF3B30] text-white' : 'bg-black border-white/10 text-neutral-400'
                  }`}
                >
                  <CreditCard className="w-4 h-4" /> Card
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('apple')}
                  className={`p-2.5 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                    paymentMethod === 'apple' ? 'bg-[#FF3B30] border-[#FF3B30] text-white' : 'bg-black border-white/10 text-neutral-400'
                  }`}
                >
                   Apple Pay
                </button>
                <button
                  type="button"
                  onClick={() => setPaymentMethod('paypal')}
                  className={`p-2.5 rounded-xl text-xs font-semibold border flex items-center justify-center gap-1.5 transition-all ${
                    paymentMethod === 'paypal' ? 'bg-[#FF3B30] border-[#FF3B30] text-white' : 'bg-black border-white/10 text-neutral-400'
                  }`}
                >
                  PayPal
                </button>
              </div>
            </div>

            {/* Credit Card Inputs */}
            {paymentMethod === 'card' && (
              <div className="space-y-3">
                <div>
                  <label className="block text-xs font-medium text-neutral-400 mb-1">Cardholder Name</label>
                  <input
                    type="text"
                    value={nameOnCard}
                    onChange={(e) => setNameOnCard(e.target.value)}
                    required
                    className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-neutral-400 mb-1">Card Number</label>
                  <input
                    type="text"
                    value={cardNumber}
                    onChange={(e) => setCardNumber(e.target.value)}
                    required
                    className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 mb-1">Expiry Date</label>
                    <input
                      type="text"
                      value={cardExpiry}
                      onChange={(e) => setCardExpiry(e.target.value)}
                      required
                      className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-neutral-400 mb-1">CVV / CVC</label>
                    <input
                      type="password"
                      value={cardCvc}
                      onChange={(e) => setCardCvc(e.target.value)}
                      required
                      maxLength={4}
                      className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white text-xs font-mono focus:border-red-500 focus:outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={isProcessing || cart.length === 0}
              className="w-full py-3.5 rounded-xl bg-[#FF3B30] hover:bg-red-600 disabled:opacity-50 text-white font-extrabold text-sm transition-all shadow-lg shadow-red-900/40 flex items-center justify-center gap-2"
            >
              {isProcessing ? (
                <span className="animate-pulse">Processing Payment...</span>
              ) : (
                <>
                  <Lock className="w-4 h-4" /> Pay ${finalTotal.toFixed(2)} Now
                </>
              )}
            </button>

            <div className="flex items-center justify-center gap-2 text-[11px] text-neutral-500">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>PCI-DSS Level 1 Compliant • 30-Day Money Back Guarantee</span>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
