import React, { useState, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { 
  Dumbbell, 
  Sparkles, 
  ShoppingBag, 
  User, 
  Search, 
  Menu, 
  X, 
  ChevronDown,
  Globe,
  LayoutDashboard,
  LogOut,
  Calendar,
  Award,
  BookOpen,
  MapPin,
  HelpCircle,
  Briefcase
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const Navbar: React.FC = () => {
  const { user, role, logout, cart, setIsSearchOpen, setIsAiChatOpen, setIsBookingOpen } = useAuth();
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [moreDropdownOpen, setMoreDropdownOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 40) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Close mobile menu on route change
  useEffect(() => {
    setMobileMenuOpen(false);
    setMoreDropdownOpen(false);
    setUserDropdownOpen(false);
  }, [location.pathname]);

  const navLinks = [
    { label: 'Home', path: '/' },
    { label: 'About', path: '/about' },
    { label: 'Programs', path: '/programs' },
    { label: 'Membership', path: '/membership' },
    { label: 'Trainers', path: '/trainers' },
    { label: 'Schedule', path: '/schedule' },
    { label: 'Store', path: '/store' },
    { label: 'Blog', path: '/blog' },
  ];

  const secondaryLinks = [
    { label: 'Calculators', path: '/calculators/bmi', icon: Dumbbell },
    { label: 'Nutrition & Recipes', path: '/nutrition', icon: BookOpen },
    { label: 'Workout Plans', path: '/workout-plans', icon: Award },
    { label: 'Transformation Stories', path: '/transformations', icon: Award },
    { label: 'Gallery', path: '/gallery', icon: BookOpen },
    { label: 'Events & Galas', path: '/events', icon: Calendar },
    { label: 'Challenges', path: '/challenges', icon: Award },
    { label: 'Find a Branch', path: '/branches', icon: MapPin },
    { label: 'Careers', path: '/careers', icon: Briefcase },
    { label: 'Contact & FAQ', path: '/contact', icon: HelpCircle },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-30 transition-all duration-300 ${
      scrolled ? 'bg-black/90 backdrop-blur-xl border-b border-white/10 py-3 shadow-2xl' : 'bg-gradient-to-b from-black/90 via-black/40 to-transparent py-5'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between">
        
        {/* Brand Logo */}
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-red-600 to-red-500 p-0.5 flex items-center justify-center shadow-lg shadow-red-900/40 group-hover:scale-105 transition-transform">
            <div className="w-full h-full bg-black rounded-[10px] flex items-center justify-center">
              <Dumbbell className="w-5 h-5 text-[#FF3B30]" />
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-black tracking-widest text-white font-mono flex items-center">
              VORTEX <span className="text-[#FF3B30] ml-1 text-2xl font-black">•</span>
            </span>
            <span className="text-[9px] tracking-[0.25em] text-neutral-400 font-semibold uppercase">Ultra-Luxury Fitness</span>
          </div>
        </Link>

        {/* Desktop Primary Nav */}
        <div className="hidden xl:flex items-center gap-6 text-xs uppercase tracking-wider font-bold text-neutral-300">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`hover:text-[#FF3B30] transition-colors ${
                location.pathname === link.path ? 'text-[#FF3B30] font-extrabold border-b-2 border-[#FF3B30] pb-0.5' : ''
              }`}
            >
              {link.label}
            </Link>
          ))}

          {/* More Dropdown */}
          <div className="relative">
            <button
              onClick={() => setMoreDropdownOpen(!moreDropdownOpen)}
              className="flex items-center gap-1 hover:text-[#FF3B30] transition-colors py-1"
            >
              More <ChevronDown className="w-3.5 h-3.5" />
            </button>

            {moreDropdownOpen && (
              <div className="absolute top-full right-0 mt-2 w-64 bg-[#0e0e0e] border border-white/10 rounded-2xl shadow-2xl p-2 py-3 z-50 divide-y divide-white/5 animate-fadeIn">
                <div className="pb-2 space-y-1">
                  {secondaryLinks.slice(0, 5).map(item => (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setMoreDropdownOpen(false)}
                      className="block px-3 py-2 rounded-xl hover:bg-white/5 text-neutral-300 hover:text-white transition-colors text-xs normal-case font-medium flex items-center gap-2"
                    >
                      <item.icon className="w-3.5 h-3.5 text-[#FF3B30]" /> {item.label}
                    </Link>
                  ))}
                </div>
                <div className="pt-2 space-y-1">
                  {secondaryLinks.slice(5).map(item => (
                    <Link
                      key={item.path}
                      to={item.path}
                      onClick={() => setMoreDropdownOpen(false)}
                      className="block px-3 py-2 rounded-xl hover:bg-white/5 text-neutral-300 hover:text-white transition-colors text-xs normal-case font-medium flex items-center gap-2"
                    >
                      <item.icon className="w-3.5 h-3.5 text-neutral-400" /> {item.label}
                    </Link>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Action Controls */}
        <div className="hidden md:flex items-center gap-3">
          {/* Search Trigger */}
          <button
            onClick={() => setIsSearchOpen(true)}
            className="p-2 rounded-xl bg-[#111111] border border-white/10 hover:border-red-500/40 text-neutral-300 hover:text-white transition-all hover:scale-105"
            title="Search Platform (Ctrl+K)"
          >
            <Search className="w-4 h-4 text-neutral-300" />
          </button>

          {/* AI Coach Trigger */}
          <button
            onClick={() => setIsAiChatOpen(true)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gradient-to-r from-red-950/60 to-black border border-red-500/30 hover:border-red-500 text-xs font-semibold text-white transition-all shadow-md shadow-red-900/20 hover:scale-105"
            title="VORTEX AI Fitness Assistant"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#FF3B30] animate-pulse" />
            <span>AI Coach</span>
          </button>

          {/* Store Cart */}
          <Link
            to="/store"
            className="relative p-2 rounded-xl bg-[#111111] border border-white/10 hover:border-white/20 text-white transition-all hover:scale-105"
            title="Shopping Cart"
          >
            <ShoppingBag className="w-4 h-4 text-[#B8B8B8]" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-[#FF3B30] text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center animate-pulse">
                {cartCount}
              </span>
            )}
          </Link>

          {/* User Profile / Dashboard / Auth Login */}
          {user ? (
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 px-3 py-1.5 rounded-xl bg-[#111111] border border-white/10 hover:border-red-500/40 text-xs font-semibold text-white transition-all"
              >
                <img src={user.avatar} alt={user.name} className="w-6 h-6 rounded-full object-cover border border-red-500/50" />
                <span className="max-w-[100px] truncate">{user.name.split(' ')[0]}</span>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-red-950 text-red-400 uppercase font-mono font-bold">{user.role}</span>
              </button>

              {userDropdownOpen && (
                <div className="absolute top-full right-0 mt-2 w-56 bg-[#0e0e0e] border border-white/10 rounded-2xl shadow-2xl p-2 z-50 text-xs space-y-1">
                  <div className="px-3 py-2 border-b border-white/10 mb-1">
                    <p className="font-bold text-white truncate">{user.name}</p>
                    <p className="text-[11px] text-neutral-400 truncate">{user.email}</p>
                  </div>
                  <Link
                    to={user.role === 'admin' ? '/dashboard/admin' : user.role === 'trainer' ? '/dashboard/trainer' : '/dashboard/member'}
                    className="block px-3 py-2 rounded-xl hover:bg-white/5 text-white font-semibold flex items-center gap-2"
                  >
                    <LayoutDashboard className="w-4 h-4 text-[#FF3B30]" /> Dashboard
                  </Link>
                  <Link
                    to="/account-settings"
                    className="block px-3 py-2 rounded-xl hover:bg-white/5 text-neutral-300 hover:text-white flex items-center gap-2"
                  >
                    <User className="w-4 h-4 text-neutral-400" /> Account Settings
                  </Link>
                  <button
                    onClick={logout}
                    className="w-full text-left px-3 py-2 rounded-xl hover:bg-red-950/40 text-red-400 flex items-center gap-2"
                  >
                    <LogOut className="w-4 h-4" /> Sign Out
                  </button>
                </div>
              )}
            </div>
          ) : (
            <Link
              to="/sign-in"
              className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#111111] hover:bg-red-600 border border-white/10 hover:border-red-500 text-xs font-bold text-white transition-all shadow-md"
            >
              <User className="w-3.5 h-3.5 text-[#FF3B30]" /> Sign In
            </Link>
          )}

          {/* Book Trial / Consultation CTA */}
          <button
            onClick={() => setIsBookingOpen(true)}
            className="px-4 py-2 rounded-xl bg-gradient-to-r from-red-600 to-red-500 hover:from-red-500 hover:to-red-400 text-white text-xs font-bold uppercase tracking-wider transition-all shadow-lg shadow-red-900/30 hover:scale-105"
          >
            Book Pass
          </button>
        </div>

        {/* Mobile menu trigger */}
        <div className="flex md:hidden items-center gap-2">
          <button
            onClick={() => setIsSearchOpen(true)}
            className="p-2 rounded-xl bg-[#111111] border border-white/10 text-white"
          >
            <Search className="w-4 h-4 text-neutral-300" />
          </button>
          <button
            onClick={() => setIsAiChatOpen(true)}
            className="p-2 rounded-xl bg-red-950/40 border border-red-500/30 text-white"
          >
            <Sparkles className="w-4 h-4 text-[#FF3B30]" />
          </button>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl bg-[#111111] border border-white/10 text-white"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#0a0a0a] border-b border-white/10 px-4 py-6 space-y-4 animate-fadeIn max-h-[85vh] overflow-y-auto">
          <div className="flex flex-col space-y-3 font-semibold text-sm">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                onClick={() => setMobileMenuOpen(false)}
                className="text-neutral-300 hover:text-white py-1.5 border-b border-white/5"
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-2 text-xs font-bold text-[#FF3B30] uppercase tracking-wider">Explore Club Services</div>
            <div className="grid grid-cols-2 gap-2 text-xs text-neutral-400">
              {secondaryLinks.map(sec => (
                <Link
                  key={sec.path}
                  to={sec.path}
                  onClick={() => setMobileMenuOpen(false)}
                  className="py-1 hover:text-white"
                >
                  {sec.label}
                </Link>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-white/10 flex flex-col gap-2">
            {user ? (
              <Link
                to={user.role === 'admin' ? '/dashboard/admin' : user.role === 'trainer' ? '/dashboard/trainer' : '/dashboard/member'}
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-3 rounded-xl bg-red-950/60 border border-red-500/30 text-center font-bold text-sm text-white flex items-center justify-center gap-2"
              >
                <LayoutDashboard className="w-4 h-4 text-[#FF3B30]" /> Access {user.role.toUpperCase()} Dashboard
              </Link>
            ) : (
              <Link
                to="/sign-in"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full py-3 rounded-xl bg-[#111111] border border-white/10 text-center font-bold text-sm text-white flex items-center justify-center gap-2"
              >
                <User className="w-4 h-4 text-[#FF3B30]" /> Sign In / Register
              </Link>
            )}
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsBookingOpen(true);
              }}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-red-600 to-red-500 text-center font-extrabold text-sm text-white uppercase"
            >
              Book Day Pass / Consultation
            </button>
          </div>
        </div>
      )}
    </nav>
  );
};
