import React, { useState } from 'react';
import { X, Calendar, Clock, User, CheckCircle2, ShieldCheck } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const BookingModal: React.FC = () => {
  const { isBookingOpen, closeBookingModal, bookingTarget, addBooking, user } = useAuth();
  
  const [bookingType, setBookingType] = useState<'Class' | 'Personal Training' | 'Consultation' | 'Trial Pass'>('Class');
  const [title, setTitle] = useState('');
  const [date, setDate] = useState('2026-07-30');
  const [time, setTime] = useState('09:00 AM');
  const [trainerOrRoom, setTrainerOrRoom] = useState('Marcus Vance');
  const [notes, setNotes] = useState('');
  const [submitted, setSubmitted] = useState(false);

  React.useEffect(() => {
    if (bookingTarget) {
      if (bookingTarget.className) {
        setBookingType('Class');
        setTitle(bookingTarget.className);
        setTrainerOrRoom(bookingTarget.trainer || 'Studio A');
      } else if (bookingTarget.name) {
        setBookingType('Personal Training');
        setTitle(`1-on-1 Session with ${bookingTarget.name}`);
        setTrainerOrRoom(bookingTarget.name);
      } else if (bookingTarget.title) {
        setBookingType('Class');
        setTitle(bookingTarget.title);
      }
    } else {
      setTitle('VIP Club Consultation & Assessment');
      setTrainerOrRoom('Head Performance Advisor');
    }
  }, [bookingTarget]);

  if (!isBookingOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    addBooking({
      type: bookingType,
      title: title || 'VORTEX VIP Session',
      date,
      time,
      trainerOrRoom,
      price: bookingType === 'Personal Training' ? 120 : 0
    });
    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      closeBookingModal();
    }, 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="w-full max-w-lg bg-[#0e0e0e] border border-white/10 rounded-2xl shadow-2xl p-6 relative">
        <button
          onClick={closeBookingModal}
          className="absolute top-4 right-4 p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        {submitted ? (
          <div className="py-12 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto border border-emerald-500/30 animate-bounce">
              <CheckCircle2 className="w-8 h-8" />
            </div>
            <h3 className="text-2xl font-extrabold text-white">Booking Confirmed!</h3>
            <p className="text-sm text-neutral-400 max-w-sm mx-auto">
              Your <span className="text-white font-semibold">{title}</span> is scheduled for <span className="text-[#FF3B30] font-semibold">{date}</span> at <span className="text-[#FF3B30] font-semibold">{time}</span>.
            </p>
            <p className="text-xs text-neutral-500">Confirmation email & calendar invitation sent.</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-red-950/50 border border-red-500/30 text-[#FF3B30]">
                <Calendar className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-xl font-extrabold text-white">Reserve Session</h3>
                <p className="text-xs text-neutral-400">VORTEX VIP Priority Booking Engine</p>
              </div>
            </div>

            {/* Type selector */}
            <div className="grid grid-cols-2 gap-2">
              {(['Class', 'Personal Training', 'Consultation', 'Trial Pass'] as const).map(t => (
                <button
                  type="button"
                  key={t}
                  onClick={() => setBookingType(t)}
                  className={`p-2.5 rounded-xl text-xs font-semibold border text-center transition-all ${
                    bookingType === t
                      ? 'bg-[#FF3B30] border-[#FF3B30] text-white shadow-md shadow-red-900/30'
                      : 'bg-white/5 border-white/10 text-neutral-400 hover:text-white'
                  }`}
                >
                  {t}
                </button>
              ))}
            </div>

            {/* Title */}
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">Session Title</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="w-full px-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-sm focus:border-red-500 focus:outline-none"
              />
            </div>

            {/* Trainer / Location */}
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">Trainer / Location</label>
              <div className="relative">
                <User className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3" />
                <input
                  type="text"
                  value={trainerOrRoom}
                  onChange={(e) => setTrainerOrRoom(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-sm focus:border-red-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Date & Time */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-medium text-neutral-400 mb-1">Date</label>
                <input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  required
                  className="w-full px-3 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-neutral-400 mb-1">Preferred Time</label>
                <div className="relative">
                  <Clock className="w-4 h-4 text-neutral-500 absolute left-3 top-3" />
                  <select
                    value={time}
                    onChange={(e) => setTime(e.target.value)}
                    className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
                  >
                    <option>07:00 AM</option>
                    <option>08:30 AM</option>
                    <option>10:00 AM</option>
                    <option>01:00 PM</option>
                    <option>05:00 PM</option>
                    <option>06:30 PM</option>
                    <option>08:00 PM</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Additional notes */}
            <div>
              <label className="block text-xs font-medium text-neutral-400 mb-1">Special Requests or Goals</label>
              <textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="E.g., Focus on shoulder mobility or lower back injury rehab..."
                rows={2}
                className="w-full px-4 py-2 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none resize-none"
              />
            </div>

            {/* Submit */}
            <div className="pt-2">
              <button
                type="submit"
                className="w-full py-3.5 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-bold text-sm transition-all shadow-lg shadow-red-900/40 hover:scale-[1.02] flex items-center justify-center gap-2"
              >
                <ShieldCheck className="w-4 h-4" /> Confirm Reservation
              </button>
            </div>
            
            <p className="text-[11px] text-center text-neutral-500">
              Free cancellations up to 12 hours prior to scheduled start time.
            </p>
          </form>
        )}
      </div>
    </div>
  );
};
