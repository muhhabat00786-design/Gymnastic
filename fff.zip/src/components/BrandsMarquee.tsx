import React from 'react';
import { BRANDS } from '../data/gymData';

export const BrandsMarquee: React.FC = () => {
  return (
    <section className="py-10 bg-[#0A0A0A] border-y border-white/5 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-4 text-center">
        <span className="text-[11px] font-extrabold uppercase tracking-[0.3em] text-[#B8B8B8]">
          Official Performance Equipment & Apparel Partners
        </span>
      </div>

      <div className="relative w-full overflow-hidden flex items-center">
        {/* Gradient Fade Masks */}
        <div className="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-[#0A0A0A] to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-[#0A0A0A] to-transparent z-10 pointer-events-none" />

        <div className="animate-marquee flex items-center gap-12 sm:gap-20 py-2">
          {[...BRANDS, ...BRANDS, ...BRANDS].map((brand, idx) => (
            <div
              key={`${brand.name}-${idx}`}
              className="flex items-center gap-3 grayscale hover:grayscale-0 opacity-50 hover:opacity-100 transition-all duration-300 cursor-pointer group"
            >
              <div className="w-10 h-10 rounded-xl overflow-hidden border border-white/10 group-hover:border-red-500/50">
                <img
                  src={brand.logo}
                  alt={brand.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <span className="font-extrabold text-base tracking-widest text-white uppercase font-mono">
                {brand.name}
              </span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
