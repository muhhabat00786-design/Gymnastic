import React from 'react';
import { Link } from 'react-router-dom';
import { Dumbbell, ArrowUp, Instagram, Linkedin, Youtube, Twitter, MapPin, Phone, Mail, ShieldCheck } from 'lucide-react';

export const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050505] border-t border-white/10 text-neutral-400 relative overflow-hidden pt-16 pb-12">
      {/* Glow background accent */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-32 bg-red-600/10 blur-[120px] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">
          
          {/* Brand Col */}
          <div className="lg:col-span-2 space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-red-600 to-red-500 p-0.5 flex items-center justify-center shadow-lg shadow-red-900/40">
                <div className="w-full h-full bg-black rounded-[10px] flex items-center justify-center">
                  <Dumbbell className="w-5 h-5 text-[#FF3B30]" />
                </div>
              </div>
              <span className="text-2xl font-black tracking-widest text-white font-mono">
                VORTEX <span className="text-[#FF3B30]">•</span>
              </span>
            </Link>
            <p className="text-xs text-neutral-400 leading-relaxed max-w-sm">
              The premier international ultra-luxury fitness and performance club. State-of-the-art biomechanics, AI diagnostics, recovery spas, and elite championship coaching.
            </p>
            <div className="space-y-1 text-xs text-neutral-300 font-mono">
              <p className="flex items-center gap-2"><MapPin className="w-3.5 h-3.5 text-[#FF3B30]" /> Global Flagships: Dubai • London • New York • Tokyo</p>
              <p className="flex items-center gap-2"><Phone className="w-3.5 h-3.5 text-[#FF3B30]" /> Concierge: +1 (800) 555-VORTEX</p>
              <p className="flex items-center gap-2"><Mail className="w-3.5 h-3.5 text-[#FF3B30]" /> vip@vortexfitness.club</p>
            </div>
            {/* Socials */}
            <div className="flex items-center gap-3 pt-2">
              <a href="https://instagram.com" target="_blank" rel="noreferrer" className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors">
                <Instagram className="w-4 h-4" />
              </a>
              <a href="https://linkedin.com" target="_blank" rel="noreferrer" className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors">
                <Linkedin className="w-4 h-4" />
              </a>
              <a href="https://youtube.com" target="_blank" rel="noreferrer" className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors">
                <Youtube className="w-4 h-4" />
              </a>
              <a href="https://twitter.com" target="_blank" rel="noreferrer" className="p-2 rounded-xl bg-white/5 hover:bg-white/10 text-neutral-400 hover:text-white transition-colors">
                <Twitter className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Quick Navigation */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-[#FF3B30] pl-2">Navigation</h4>
            <ul className="space-y-2 text-xs font-medium">
              <li><Link to="/about" className="hover:text-white transition-colors">About VORTEX</Link></li>
              <li><Link to="/programs" className="hover:text-white transition-colors">Training Programs</Link></li>
              <li><Link to="/membership" className="hover:text-white transition-colors">Membership & Pricing</Link></li>
              <li><Link to="/trainers" className="hover:text-white transition-colors">Master Trainers</Link></li>
              <li><Link to="/schedule" className="hover:text-white transition-colors">Class Schedule</Link></li>
              <li><Link to="/store" className="hover:text-white transition-colors">Online Store</Link></li>
            </ul>
          </div>

          {/* Experience & Tools */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-[#FF3B30] pl-2">Features & Tools</h4>
            <ul className="space-y-2 text-xs font-medium">
              <li><Link to="/calculators/bmi" className="hover:text-white transition-colors">BMI & Calorie Calculators</Link></li>
              <li><Link to="/nutrition" className="hover:text-white transition-colors">Anabolic Recipes & Nutrition</Link></li>
              <li><Link to="/workout-plans" className="hover:text-white transition-colors">AI Workout Generator</Link></li>
              <li><Link to="/transformations" className="hover:text-white transition-colors">Transformation Stories</Link></li>
              <li><Link to="/events" className="hover:text-white transition-colors">Events & Galas</Link></li>
              <li><Link to="/challenges" className="hover:text-white transition-colors">30-Day Fitness Challenges</Link></li>
            </ul>
          </div>

          {/* Legal & Company */}
          <div>
            <h4 className="text-xs font-bold text-white uppercase tracking-wider mb-4 border-l-2 border-[#FF3B30] pl-2">Company & Legal</h4>
            <ul className="space-y-2 text-xs font-medium">
              <li><Link to="/branches" className="hover:text-white transition-colors">Find a Branch</Link></li>
              <li><Link to="/careers" className="hover:text-white transition-colors">Careers & Hiring</Link></li>
              <li><Link to="/contact" className="hover:text-white transition-colors">Contact Concierge</Link></li>
              <li><Link to="/privacy-policy" className="hover:text-white transition-colors">Privacy Policy</Link></li>
              <li><Link to="/terms-conditions" className="hover:text-white transition-colors">Terms & Conditions</Link></li>
              <li><Link to="/cookie-policy" className="hover:text-white transition-colors">Cookie Policy</Link></li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs">
          <p>© {new Date().getFullYear()} VORTEX Ultra-Luxury Fitness Club. All Rights Reserved.</p>
          
          <div className="flex items-center gap-4 text-neutral-500">
            <span className="flex items-center gap-1"><ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> ISO 9001 Certified Facilities</span>
            <button
              onClick={scrollToTop}
              className="p-2.5 rounded-xl bg-white/5 hover:bg-[#FF3B30] hover:text-white transition-all text-neutral-300 flex items-center gap-1 font-semibold"
            >
              Top <ArrowUp className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
};
