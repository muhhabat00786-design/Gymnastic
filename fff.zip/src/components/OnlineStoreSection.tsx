import React, { useState } from 'react';
import { PRODUCTS } from '../data/gymData';
import { Product } from '../types';
import { ShoppingBag, Star, Plus, Check, ShoppingCart, X } from 'lucide-react';

interface OnlineStoreSectionProps {
  onAddToCart: (product: Product) => void;
  cartCount: number;
}

export const OnlineStoreSection: React.FC<OnlineStoreSectionProps> = ({ onAddToCart }) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [addedId, setAddedId] = useState<string | null>(null);

  const categories = ['All', 'Supplements', 'Apparel', 'Gear'];

  const filteredProducts = selectedCategory === 'All'
    ? PRODUCTS
    : PRODUCTS.filter(p => p.category === selectedCategory);

  const handleAdd = (product: Product) => {
    onAddToCart(product);
    setAddedId(product.id);
    setTimeout(() => setAddedId(null), 1500);
  };

  return (
    <section id="store" className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <ShoppingBag className="w-3.5 h-3.5" />
            <span>Exclusive Gear & Supplements</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            VORTEX <span className="text-gradient-red">ONLINE STORE.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Cold-filtered hydrolyzed protein, heavy French terry apparel, and precision gym equipment.
          </p>
        </div>

        {/* Filter Buttons */}
        <div className="flex justify-center gap-2 overflow-x-auto pb-4 mb-10 no-scrollbar">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-5 py-2 rounded-xl text-xs font-mono font-extrabold uppercase tracking-wider transition-all ${
                selectedCategory === cat
                  ? 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg shadow-red-600/30'
                  : 'bg-[#111111] border border-white/10 text-[#B8B8B8] hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {filteredProducts.map((product) => {
            const isJustAdded = addedId === product.id;

            return (
              <div
                key={product.id}
                className="glass-card overflow-hidden border-white/10 glass-card-hover flex flex-col justify-between group"
              >
                <div>
                  <div className="relative h-64 overflow-hidden bg-black/50">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 filter contrast-105"
                    />
                    
                    {/* Category Tag */}
                    <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-black/80 backdrop-blur-md text-[10px] font-mono font-bold uppercase text-white border border-white/10">
                      {product.category}
                    </span>

                    {/* Rating Tag */}
                    <span className="absolute top-4 right-4 px-2.5 py-1 rounded-full bg-black/80 backdrop-blur-md text-[10px] font-mono font-bold text-amber-400 flex items-center gap-1 border border-white/10">
                      <Star className="w-3 h-3 fill-amber-400" />
                      {product.rating}
                    </span>
                  </div>

                  <div className="p-5">
                    <h3 className="text-base font-bold text-white font-mono mb-1">{product.name}</h3>
                    <p className="text-xs text-[#B8B8B8] leading-relaxed line-clamp-2 mb-4">
                      {product.description}
                    </p>
                  </div>
                </div>

                <div className="p-5 pt-0 flex items-center justify-between border-t border-white/10 pt-4">
                  <span className="text-xl font-extrabold text-white font-mono">${product.price.toFixed(2)}</span>

                  <button
                    onClick={() => handleAdd(product)}
                    className={`p-2.5 rounded-xl font-mono text-xs font-extrabold uppercase transition-all flex items-center gap-1.5 ${
                      isJustAdded
                        ? 'bg-green-500 text-black'
                        : 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg hover:scale-105'
                    }`}
                  >
                    {isJustAdded ? <Check className="w-4 h-4" /> : <Plus className="w-4 h-4" />}
                    <span>{isJustAdded ? 'Added' : 'Add to Cart'}</span>
                  </button>
                </div>

              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
};
