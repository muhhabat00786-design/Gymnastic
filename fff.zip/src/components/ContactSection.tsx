import React, { useState } from 'react';
import { Mail, Phone, MapPin, Clock, Send, Check, ShieldCheck, MessageSquare } from 'lucide-react';

export const ContactSection: React.FC = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: 'Membership Inquiry',
    message: ''
  });

  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [newsletterSuccess, setNewsletterSuccess] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [formSuccess, setFormSuccess] = useState(false);
  const [refId, setRefId] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...formData, type: 'Inquiry' })
      });
      const data = await res.json();
      setFormSuccess(true);
      setRefId(data.referenceId || 'VTX-998822');
    } catch (err) {
      console.error(err);
    } finally {
      setSubmitting(false);
    }
  };

  const handleNewsletterSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newsletterEmail) return;
    setNewsletterSuccess(true);
    setTimeout(() => {
      setNewsletterSuccess(false);
      setNewsletterEmail('');
    }, 3000);
  };

  return (
    <section id="contact" className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Mail className="w-3.5 h-3.5" />
            <span>24/7 VIP Concierge</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            CONNECT WITH <span className="text-gradient-red">VORTEX CONCIERGE.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Schedule a private sanctuary walkthrough or speak with an executive performance advisor.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Form */}
          <div className="lg:col-span-7 glass-card p-6 sm:p-8 border-white/10">
            {formSuccess ? (
              <div className="text-center py-12 space-y-4">
                <div className="w-16 h-16 rounded-full bg-green-500/20 text-[#00E676] flex items-center justify-center mx-auto border border-green-500/40">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-white font-mono">Inquiry Received</h3>
                <p className="text-xs text-[#B8B8B8] max-w-sm mx-auto">
                  Thank you <span className="text-white font-bold">{formData.name}</span>. Reference ID: <span className="text-[#FF3B30] font-mono font-bold">{refId}</span>. A VIP concierge will contact you within 2 hours.
                </p>

                <button
                  onClick={() => {
                    setFormSuccess(false);
                    setFormData({ name: '', email: '', phone: '', subject: 'Membership Inquiry', message: '' });
                  }}
                  className="mt-4 px-6 py-2.5 rounded-xl bg-white/10 text-xs font-bold text-white uppercase"
                >
                  Send Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Full Name</label>
                    <input
                      type="text"
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      placeholder="Lord Sterling"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Email Address</label>
                    <input
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      placeholder="sterling@vortex.club"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Phone Number</label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+1 (555) 777-9999"
                      className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Subject</label>
                    <select
                      value={formData.subject}
                      onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                      className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
                    >
                      <option value="Membership Inquiry">Membership Inquiry</option>
                      <option value="Private Coaching Tour">Private Coaching Tour</option>
                      <option value="Corporate Wellness">Corporate Wellness</option>
                      <option value="Press & Media">Press & Media</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-[#B8B8B8] mb-1">Message / Requirements</label>
                  <textarea
                    rows={4}
                    required
                    value={formData.message}
                    onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                    placeholder="Tell us about your fitness objectives and preferred tour times..."
                    className="w-full px-4 py-2.5 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
                  />
                </div>

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full py-3.5 rounded-xl bg-gradient-to-r from-[#FF3B30] to-[#FF0000] font-extrabold text-xs text-white uppercase tracking-wider shadow-lg shadow-red-600/40 hover:scale-[1.01] transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>{submitting ? 'Transmitting Message...' : 'Transmit VIP Message'}</span>
                </button>
              </form>
            )}
          </div>

          {/* Right Column: Contact Details & Simulated Map */}
          <div className="lg:col-span-5 space-y-6">
            
            <div className="glass-card p-6 border-white/10 space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-[#FF3B30] shrink-0 mt-1" />
                <div>
                  <span className="block font-bold text-xs text-white font-mono">Flagship Sanctuary</span>
                  <span className="text-xs text-[#B8B8B8]">100 Park Lane, Mayfair, London W1K 7TY</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-[#FF3B30] shrink-0 mt-1" />
                <div>
                  <span className="block font-bold text-xs text-white font-mono">Direct Concierge</span>
                  <span className="text-xs text-[#B8B8B8]">+44 (0) 20 7946 0912</span>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Clock className="w-5 h-5 text-[#FF3B30] shrink-0 mt-1" />
                <div>
                  <span className="block font-bold text-xs text-white font-mono">Operating Hours</span>
                  <span className="text-xs text-[#B8B8B8]">24 Hours / 7 Days a Week Access</span>
                </div>
              </div>
            </div>

            {/* Newsletter Subscription Card */}
            <div className="glass-card p-6 border-red-500/30 bg-gradient-to-r from-red-950/40 to-[#111111]">
              <h3 className="text-base font-bold text-white font-mono mb-1">VORTEX Performance Intelligence</h3>
              <p className="text-xs text-[#B8B8B8] mb-4">Subscribe for monthly biohacking research, event passes, and new gear drops.</p>

              {newsletterSuccess ? (
                <div className="p-3 rounded-xl bg-green-500/20 text-[#00E676] text-xs font-mono font-bold flex items-center gap-2">
                  <Check className="w-4 h-4" />
                  <span>Subscribed to VORTEX Intelligence</span>
                </div>
              ) : (
                <form onSubmit={handleNewsletterSubmit} className="flex gap-2">
                  <input
                    type="email"
                    required
                    placeholder="enter your email..."
                    value={newsletterEmail}
                    onChange={(e) => setNewsletterEmail(e.target.value)}
                    className="flex-1 px-4 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
                  />
                  <button
                    type="submit"
                    className="px-4 py-2 rounded-xl bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-xs font-bold text-white uppercase"
                  >
                    Join
                  </button>
                </form>
              )}
            </div>

          </div>

        </div>

      </div>
    </section>
  );
};
