import React, { useState } from 'react';
import { MEAL_PLANS } from '../data/gymData';
import { MealPlan } from '../types';
import { Utensils, Flame, Check, X, Clock, ChevronRight } from 'lucide-react';

export const NutritionSection: React.FC = () => {
  const [selectedPlan, setSelectedPlan] = useState<MealPlan>(MEAL_PLANS[0]);
  const [detailModalOpen, setDetailModalOpen] = useState(false);

  return (
    <section id="nutrition" className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Utensils className="w-3.5 h-3.5" />
            <span>Artisanal Macro Culinary</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            PRECISION <span className="text-gradient-red">NUTRITION & RECIPES.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Fueling cellular adaptation. Each dish is macro-calculated by sports dietitians and prepared with organic grass-fed proteins and nutrient-dense Superfoods.
          </p>
        </div>

        {/* Meal Plan Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {MEAL_PLANS.map((plan) => (
            <div
              key={plan.id}
              className={`glass-card overflow-hidden border-white/10 glass-card-hover flex flex-col justify-between cursor-pointer ${
                selectedPlan.id === plan.id ? 'border-red-500/50 shadow-2xl shadow-red-950/40' : ''
              }`}
              onClick={() => setSelectedPlan(plan)}
            >
              <div>
                <div className="relative h-60 overflow-hidden">
                  <img
                    src={plan.image}
                    alt={plan.title}
                    className="w-full h-full object-cover filter contrast-110 brightness-90 hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-[#111111] via-transparent to-transparent" />
                  
                  <span className="absolute top-4 left-4 px-3 py-1 rounded-full bg-red-950/80 border border-red-500/40 text-[10px] font-mono font-extrabold uppercase text-white">
                    {plan.goal}
                  </span>

                  <div className="absolute bottom-4 left-4 text-2xl font-extrabold font-mono text-white flex items-center gap-1">
                    <Flame className="w-5 h-5 text-[#FF3B30]" />
                    <span>{plan.calories}</span>
                    <span className="text-xs text-[#B8B8B8] font-normal">kcal/day</span>
                  </div>
                </div>

                <div className="p-6">
                  <h3 className="text-xl font-bold text-white mb-4 font-mono">{plan.title}</h3>

                  {/* Macro Badges */}
                  <div className="grid grid-cols-3 gap-2 text-center mb-6">
                    <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
                      <span className="block text-[10px] text-[#B8B8B8] font-semibold">Protein</span>
                      <span className="block text-sm font-bold text-[#FF3B30] font-mono">{plan.protein}g</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
                      <span className="block text-[10px] text-[#B8B8B8] font-semibold">Carbs</span>
                      <span className="block text-sm font-bold text-[#00E676] font-mono">{plan.carbs}g</span>
                    </div>

                    <div className="p-2.5 rounded-xl bg-white/5 border border-white/5">
                      <span className="block text-[10px] text-[#B8B8B8] font-semibold">Fats</span>
                      <span className="block text-sm font-bold text-[#FFC107] font-mono">{plan.fat}g</span>
                    </div>
                  </div>

                  {/* Meals Preview */}
                  <div className="space-y-2 border-t border-white/10 pt-4">
                    {plan.meals.slice(0, 2).map((m, idx) => (
                      <div key={idx} className="flex items-center justify-between text-xs font-mono text-[#B8B8B8]">
                        <span className="text-white font-semibold truncate">{m.name}</span>
                        <span className="text-red-400">{m.time}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-6 pt-0">
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setSelectedPlan(plan);
                    setDetailModalOpen(true);
                  }}
                  className="w-full py-3 rounded-xl bg-gradient-to-r from-red-950/60 to-[#111111] border border-red-500/40 hover:border-red-500 text-xs font-bold text-white uppercase tracking-wider flex items-center justify-center gap-2 transition-all"
                >
                  <span>View Full Daily Menu & Recipes</span>
                  <ChevronRight className="w-4 h-4 text-[#FF3B30]" />
                </button>
              </div>

            </div>
          ))}
        </div>

      </div>

      {/* Recipe Detail Modal */}
      {detailModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md">
          <div className="relative w-full max-w-2xl bg-[#111111] border border-white/10 rounded-2xl p-6 shadow-2xl max-h-[85vh] overflow-y-auto">
            <button
              onClick={() => setDetailModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="mb-6">
              <span className="text-xs font-bold text-[#FF3B30] uppercase tracking-widest font-mono">
                {selectedPlan.goal}
              </span>
              <h3 className="text-2xl font-extrabold text-white font-mono mt-1">
                {selectedPlan.title} ({selectedPlan.calories} kcal)
              </h3>
            </div>

            <div className="space-y-4">
              {selectedPlan.meals.map((m, idx) => (
                <div key={idx} className="p-4 rounded-xl bg-[#0A0A0A] border border-white/10">
                  <div className="flex items-center justify-between text-xs font-mono font-bold text-[#FF3B30] mb-1">
                    <span>{m.time}</span>
                    <span>Meal 0{idx + 1}</span>
                  </div>
                  <h4 className="text-sm font-bold text-white font-mono">{m.name}</h4>
                  <p className="text-xs text-[#B8B8B8] mt-1">{m.desc}</p>
                </div>
              ))}
            </div>

            <button
              onClick={() => setDetailModalOpen(false)}
              className="mt-6 w-full py-3 rounded-xl bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-xs font-extrabold text-white uppercase tracking-wider shadow-lg"
            >
              Close Menu View
            </button>
          </div>
        </div>
      )}

    </section>
  );
};
