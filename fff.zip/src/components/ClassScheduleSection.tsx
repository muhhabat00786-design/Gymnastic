import React, { useState } from 'react';
import { CLASS_SESSIONS } from '../data/gymData';
import { ClassSession } from '../types';
import { Clock, Search, MapPin, Check, User, Sparkles, Filter } from 'lucide-react';

export const ClassScheduleSection: React.FC = () => {
  const [selectedDay, setSelectedDay] = useState<string>('Monday');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [reservedClassId, setReservedClassId] = useState<string | null>(null);

  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const categories = ['All', 'HIIT', 'Strength', 'Yoga', 'Boxing', 'Recovery'];

  const filteredClasses = CLASS_SESSIONS.filter(cls => {
    const matchesDay = cls.day === selectedDay;
    const matchesCategory = selectedCategory === 'All' || cls.category === selectedCategory;
    const matchesSearch = cls.className.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          cls.trainer.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesDay && matchesCategory && matchesSearch;
  });

  const handleReserve = (id: string) => {
    setReservedClassId(id);
    setTimeout(() => {
      setReservedClassId(null);
    }, 3000);
  };

  return (
    <section id="schedule" className="py-24 bg-[#0A0A0A] relative overflow-hidden border-t border-white/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full glass-card border-red-500/30 text-xs font-bold uppercase tracking-widest text-[#FF3B30] mb-4">
            <Clock className="w-3.5 h-3.5" />
            <span>Real-Time Timetable</span>
          </div>
          <h2 className="text-3xl sm:text-5xl font-extrabold uppercase font-mono tracking-tight text-white mb-4">
            LIVE CLASS <span className="text-gradient-red">SCHEDULE.</span>
          </h2>
          <p className="text-base text-[#B8B8B8] leading-relaxed">
            Reserve your place in our Olympic studio suites. Real-time availability tracking for every session.
          </p>
        </div>

        {/* Filter Controls Bar */}
        <div className="glass-card p-6 border-white/10 mb-8 space-y-4">
          
          {/* Day Tabs */}
          <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
            {days.map((day) => (
              <button
                key={day}
                onClick={() => setSelectedDay(day)}
                className={`py-2.5 px-5 rounded-xl text-xs font-mono font-extrabold uppercase tracking-wider whitespace-nowrap transition-all ${
                  selectedDay === day
                    ? 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg shadow-red-600/30'
                    : 'bg-[#0A0A0A] border border-white/10 text-[#B8B8B8] hover:text-white'
                }`}
              >
                {day}
              </button>
            ))}
          </div>

          {/* Search & Category Filter */}
          <div className="flex flex-col sm:flex-row gap-4 items-center justify-between pt-2 border-t border-white/10">
            <div className="relative w-full sm:w-72">
              <input
                type="text"
                placeholder="Search class or trainer..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 rounded-xl bg-[#0A0A0A] border border-white/10 text-white text-xs focus:outline-none focus:border-red-500"
              />
              <Search className="w-4 h-4 text-[#B8B8B8] absolute left-3 top-2.5" />
            </div>

            <div className="flex items-center gap-2 overflow-x-auto w-full sm:w-auto">
              <Filter className="w-4 h-4 text-[#FF3B30] shrink-0" />
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`px-3 py-1.5 rounded-lg text-[11px] font-extrabold uppercase font-mono transition-all ${
                    selectedCategory === cat ? 'bg-red-950/80 border border-red-500 text-white' : 'text-[#B8B8B8] hover:text-white'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

        </div>

        {/* Timetable Class List */}
        <div className="space-y-4">
          {filteredClasses.length === 0 ? (
            <div className="text-center py-12 glass-card border-white/10">
              <span className="text-sm font-bold text-[#B8B8B8] font-mono">No sessions scheduled for this filter selection.</span>
            </div>
          ) : (
            filteredClasses.map((cls) => {
              const isReserved = reservedClassId === cls.id;

              return (
                <div
                  key={cls.id}
                  className="glass-card p-6 border-white/10 hover:border-red-500/30 flex flex-col sm:flex-row sm:items-center justify-between gap-4 transition-all"
                >
                  <div className="flex items-start sm:items-center gap-4">
                    <div className="p-3 rounded-2xl bg-gradient-to-tr from-red-950/80 to-[#111111] border border-red-500/30 text-white font-mono text-center shrink-0">
                      <span className="block text-xs font-extrabold text-[#FF3B30]">{cls.time}</span>
                      <span className="block text-[10px] text-[#B8B8B8]">{cls.duration}</span>
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-0.5 rounded-md bg-white/10 text-[10px] font-mono font-extrabold text-[#FF3B30] uppercase">
                          {cls.category}
                        </span>
                        <span className="text-xs text-[#B8B8B8] flex items-center gap-1 font-mono">
                          <MapPin className="w-3 h-3 text-[#FF3B30]" />
                          {cls.room}
                        </span>
                      </div>

                      <h3 className="text-lg font-bold text-white font-mono mt-1">{cls.className}</h3>
                      <span className="text-xs text-[#B8B8B8] flex items-center gap-1 mt-0.5">
                        <User className="w-3 h-3 text-[#FF3B30]" />
                        Master Trainer: {cls.trainer}
                      </span>
                    </div>
                  </div>

                  {/* Right Side: Spots & Reserve CTA */}
                  <div className="flex items-center justify-between sm:justify-end gap-6 border-t sm:border-none pt-4 sm:pt-0 border-white/10">
                    <div className="text-right">
                      <span className="block text-xs font-bold text-[#00E676] font-mono">
                        {cls.spotsLeft} Spots Available
                      </span>
                      <span className="block text-[10px] text-[#B8B8B8]">Capacity {cls.totalSpots} max</span>
                    </div>

                    <button
                      onClick={() => handleReserve(cls.id)}
                      disabled={isReserved}
                      className={`py-2.5 px-6 rounded-xl text-xs font-extrabold uppercase tracking-wider font-mono transition-all flex items-center gap-2 ${
                        isReserved
                          ? 'bg-green-500/20 text-[#00E676] border border-green-500/40'
                          : 'bg-gradient-to-r from-[#FF3B30] to-[#FF0000] text-white shadow-lg shadow-red-600/30 hover:scale-105'
                      }`}
                    >
                      {isReserved ? <Check className="w-4 h-4" /> : <Sparkles className="w-4 h-4" />}
                      <span>{isReserved ? 'Reserved!' : 'Reserve Spot'}</span>
                    </button>
                  </div>

                </div>
              );
            })
          )}
        </div>

      </div>
    </section>
  );
};
