import React, { useState } from 'react';
import { Play, ChevronDown, Flame, Shield, Award, Users, Clock, Sparkles, X } from 'lucide-react';
import { HERO_VIDEOS } from '../data/gymData';

interface HeroProps {
  onOpenAI?: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onOpenAI }) => {
  const [videoModalOpen, setVideoModalOpen] = useState(false);

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center pt-24 pb-16 overflow-hidden">
      
      {/* Background Video / Overlay */}
      <div className="absolute inset-0 z-0">
        <video
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover scale-105 filter contrast-125 brightness-75"
        >
          <source src={HERO_VIDEOS[0]} type="video/mp4" />
        </video>
        
        {/* Luxury Radial Dark Overlays */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0A]/70 to-black/80" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#0A0A0A_85%)]" />
        
        {/* Red Glow Orbs */}
        <div className="absolute top-1/4 -left-32 w-96 h-96 bg-red-600/20 rounded-full blur-[140px] pointer-events-none animate-pulse-glow" />
        <div className="absolute bottom-10 -right-32 w-96 h-96 bg-red-700/25 rounded-full blur-[160px] pointer-events-none" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center flex flex-col items-center">
        
        {/* Elite Badge */}
        <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full glass-card border border-red-500/30 bg-red-950/20 mb-6 animate-fade-in shadow-xl">
          <Flame className="w-4 h-4 text-[#FF3B30] animate-bounce" />
          <span className="text-xs font-bold uppercase tracking-widest text-white">
            World-Class Ultra Luxury Fitness Standard
          </span>
          <span className="w-1.5 h-1.5 rounded-full bg-[#FF0000] animate-ping" />
        </div>

        {/* Large Main Heading */}
        <h1 className="text-4xl sm:text-6xl md:text-7xl lg:text-8xl font-extrabold tracking-tight text-white leading-none max-w-5xl mb-6 uppercase font-mono">
          TRANSFORM YOUR <span className="text-gradient-red">BODY.</span>
          <br />
          TRANSFORM YOUR <span className="text-[#FF3B30] underline decoration-red-600/50 decoration-wavy decoration-2">LIFE.</span>
        </h1>

        {/* Subtitle */}
        <p className="text-base sm:text-lg md:text-xl text-[#B8B8B8] max-w-2xl mb-10 font-normal leading-relaxed">
          Step into an unmatched architectural sanctuary of performance. Custom biomechanics, infrared recovery suites, Olympic programming, and AI-optimized coaching.
        </p>

        {/* CTA Buttons */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto mb-16">
          <a
            href="#pricing"
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-gradient-to-r from-[#FF3B30] to-[#FF0000] hover:from-[#FF0000] hover:to-[#CC0000] text-sm font-extrabold text-white uppercase tracking-wider shadow-2xl shadow-red-600/40 hover:shadow-red-600/70 hover:scale-105 transition-all duration-300 text-center"
          >
            Join VORTEX Club
          </a>

          <a
            href="#contact"
            className="w-full sm:w-auto px-8 py-4 rounded-2xl bg-[#111111]/80 backdrop-blur-md border border-white/15 hover:border-red-500/50 text-sm font-bold text-white uppercase tracking-wider hover:bg-white/5 transition-all text-center"
          >
            Book Free VIP Trial
          </a>

          <button
            onClick={() => setVideoModalOpen(true)}
            className="flex items-center justify-center gap-2 px-6 py-4 rounded-2xl bg-black/50 border border-white/10 hover:border-red-500/40 text-xs font-semibold text-white transition-all group"
          >
            <div className="w-8 h-8 rounded-full bg-red-600/20 group-hover:bg-red-600 flex items-center justify-center text-[#FF3B30] group-hover:text-white transition-colors">
              <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
            </div>
            <span>Watch Tour</span>
          </button>
        </div>

        {/* Animated Statistics Banner */}
        <div className="w-full max-w-5xl grid grid-cols-2 md:grid-cols-4 gap-4 p-6 glass-card border-white/10 shadow-2xl">
          <div className="flex flex-col items-center p-3 border-r border-white/10 last:border-none">
            <div className="flex items-center gap-1.5 text-2xl sm:text-3xl font-extrabold text-white font-mono">
              <Users className="w-5 h-5 text-[#FF3B30]" />
              <span>10,000+</span>
            </div>
            <span className="text-[11px] uppercase tracking-widest text-[#B8B8B8] font-medium mt-1">Global Members</span>
          </div>

          <div className="flex flex-col items-center p-3 border-r border-white/10 last:border-none">
            <div className="flex items-center gap-1.5 text-2xl sm:text-3xl font-extrabold text-white font-mono">
              <Award className="w-5 h-5 text-[#FF3B30]" />
              <span>120+</span>
            </div>
            <span className="text-[11px] uppercase tracking-widest text-[#B8B8B8] font-medium mt-1">Elite Trainers</span>
          </div>

          <div className="flex flex-col items-center p-3 border-r border-white/10 last:border-none">
            <div className="flex items-center gap-1.5 text-2xl sm:text-3xl font-extrabold text-white font-mono">
              <Clock className="w-5 h-5 text-[#FF3B30]" />
              <span>24/7</span>
            </div>
            <span className="text-[11px] uppercase tracking-widest text-[#B8B8B8] font-medium mt-1">Access Anytime</span>
          </div>

          <div className="flex flex-col items-center p-3">
            <div className="flex items-center gap-1.5 text-2xl sm:text-3xl font-extrabold text-white font-mono">
              <Shield className="w-5 h-5 text-[#FF3B30]" />
              <span>25+ Yrs</span>
            </div>
            <span className="text-[11px] uppercase tracking-widest text-[#B8B8B8] font-medium mt-1">Excellence Legacy</span>
          </div>
        </div>

        {/* Scroll Indicator */}
        <a href="#about" className="mt-12 flex flex-col items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#B8B8B8] hover:text-white transition-colors group">
          <span>Explore Sanctuary</span>
          <ChevronDown className="w-4 h-4 text-[#FF3B30] animate-bounce" />
        </a>

      </div>

      {/* Video Tour Modal */}
      {videoModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/90 backdrop-blur-md">
          <div className="relative w-full max-w-4xl bg-[#111111] rounded-2xl border border-white/10 overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b border-white/10">
              <span className="font-bold text-sm text-white">VORTEX Flagship Sanctuary Tour</span>
              <button
                onClick={() => setVideoModalOpen(false)}
                className="p-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="aspect-video w-full">
              <iframe
                className="w-full h-full"
                src="https://www.youtube.com/embed/gCzTM6V1mQU?autoplay=1"
                title="VORTEX Club Tour"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>
        </div>
      )}

    </section>
  );
};
