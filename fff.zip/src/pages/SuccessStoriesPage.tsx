import React from 'react';
import { TransformationStories } from '../components/TransformationStories';

export const SuccessStoriesPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      <TransformationStories />
    </div>
  );
};
