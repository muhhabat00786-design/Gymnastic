import React from 'react';
import { Hero } from '../components/Hero';
import { BrandsMarquee } from '../components/BrandsMarquee';
import { AboutSection } from '../components/AboutSection';
import { FeaturesSection } from '../components/FeaturesSection';
import { ProgramsSection } from '../components/ProgramsSection';
import { WorkoutPlanner } from '../components/WorkoutPlanner';
import { CalculatorsSection } from '../components/CalculatorsSection';
import { ClassScheduleSection } from '../components/ClassScheduleSection';
import { TrainersSection } from '../components/TrainersSection';
import { PricingSection } from '../components/PricingSection';
import { TransformationStories } from '../components/TransformationStories';
import { GallerySection } from '../components/GallerySection';
import { NutritionSection } from '../components/NutritionSection';
import { OnlineStoreSection } from '../components/OnlineStoreSection';
import { BlogSection } from '../components/BlogSection';
import { TestimonialsSection } from '../components/TestimonialsSection';
import { FAQSection } from '../components/FAQSection';
import { AppDownloadSection } from '../components/AppDownloadSection';
import { ContactSection } from '../components/ContactSection';
import { useAuth } from '../context/AuthContext';

export const HomePage: React.FC = () => {
  const { setIsAiChatOpen, addToCart } = useAuth();

  return (
    <div className="space-y-0">
      <Hero onOpenAI={() => setIsAiChatOpen(true)} />
      <BrandsMarquee />
      <AboutSection />
      <FeaturesSection />
      <ProgramsSection />
      <WorkoutPlanner />
      <CalculatorsSection />
      <ClassScheduleSection />
      <TrainersSection />
      <PricingSection />
      <TransformationStories />
      <GallerySection />
      <NutritionSection />
      <OnlineStoreSection onAddToCart={(p) => addToCart(p, 1)} />
      <BlogSection />
      <TestimonialsSection />
      <FAQSection />
      <AppDownloadSection />
      <ContactSection />
    </div>
  );
};
