import React from 'react';
import { WorkoutPlanner } from '../components/WorkoutPlanner';
import { Dumbbell, Sparkles, Trophy } from 'lucide-react';

export const WorkoutPlansPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          Interactive Periodization Engine
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          Workout <span className="text-[#FF3B30]">Plans</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          Generate customized 4-day training splits powered by our VORTEX Gemini 3.6 engine or explore pre-designed protocols.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <WorkoutPlanner />
      </div>

    </div>
  );
};
