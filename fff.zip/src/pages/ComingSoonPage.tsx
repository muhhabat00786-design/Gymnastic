import React from 'react';
import { Clock, Sparkles } from 'lucide-react';

export const ComingSoonPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-[80vh] flex items-center justify-center p-4">
      <div className="text-center space-y-6 max-w-md">
        <div className="w-20 h-20 rounded-3xl bg-red-950/80 border border-red-500/40 text-[#FF3B30] flex items-center justify-center mx-auto shadow-2xl">
          <Clock className="w-10 h-10 animate-spin" style={{ animationDuration: '8s' }} />
        </div>
        <h1 className="text-3xl font-black font-mono text-white uppercase">Tokyo Flagship Expansion</h1>
        <p className="text-xs text-neutral-400">
          Unveiling Q4 2026. Featuring 30,000 sq ft of custom Technogym Biostrength and cryotherapy suites in Shibuya.
        </p>
      </div>
    </div>
  );
};
