import React from 'react';
import { ShieldCheck } from 'lucide-react';

export const CookiePolicyPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center space-y-2 border-b border-white/10 pb-8">
          <ShieldCheck className="w-10 h-10 text-[#FF3B30] mx-auto" />
          <h1 className="text-3xl font-black font-mono text-white uppercase">Cookie Policy</h1>
          <p className="text-xs text-neutral-400">Effective: July 28, 2026</p>
        </div>

        <div className="prose prose-invert text-xs sm:text-sm text-neutral-300 leading-relaxed space-y-4">
          <p>
            VORTEX uses essential security cookies and session tokens to preserve authentication states and online store cart data.
          </p>
        </div>
      </div>
    </div>
  );
};
