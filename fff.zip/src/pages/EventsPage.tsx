import React from 'react';
import { EVENTS } from '../data/extendedData';
import { Calendar, Clock, MapPin, Ticket } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const EventsPage: React.FC = () => {
  const { openBookingModal } = useAuth();

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          Galas & Masterclasses
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          VORTEX <span className="text-[#FF3B30]">Events</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          Exclusive summits, infrared sound bathgalas, and powerlifting expos hosted at our flagship club auditoriums.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {EVENTS.map(evt => (
            <div key={evt.id} className="bg-[#0e0e0e] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between">
              <div className="relative h-64 overflow-hidden">
                <img src={evt.image} alt={evt.title} className="w-full h-full object-cover" />
                <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-bold uppercase bg-red-950 text-red-400 border border-red-500/30">
                  {evt.category}
                </span>
                <span className="absolute top-3 right-3 px-3 py-1 rounded-full text-xs font-bold font-mono bg-black/80 text-emerald-400 border border-emerald-500/30">
                  {evt.spotsLeft} Passes Left
                </span>
              </div>

              <div className="p-8 flex-1 flex flex-col justify-between space-y-6">
                <div className="space-y-3">
                  <h3 className="text-2xl font-bold text-white font-mono">{evt.title}</h3>
                  <div className="space-y-1 text-xs text-neutral-400 font-mono">
                    <p className="flex items-center gap-2"><Calendar className="w-3.5 h-3.5 text-[#FF3B30]" /> {evt.date}</p>
                    <p className="flex items-center gap-2"><Clock className="w-3.5 h-3.5 text-amber-400" /> {evt.time}</p>
                    <p className="flex items-center gap-2"><MapPin className="w-3.5 h-3.5 text-neutral-400" /> {evt.location}</p>
                  </div>
                  <p className="text-xs text-neutral-300 leading-relaxed pt-2">{evt.description}</p>
                </div>

                <div className="flex items-center justify-between border-t border-white/5 pt-4">
                  <span className="text-lg font-black text-white font-mono">{evt.price}</span>
                  <button
                    onClick={() => openBookingModal(evt)}
                    className="px-6 py-3 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-red-900/30 flex items-center gap-2"
                  >
                    <Ticket className="w-4 h-4" /> Reserve Pass
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
