import React from 'react';
import { MembershipPage } from './MembershipPage';

export const PricingPage: React.FC = () => {
  return <MembershipPage />;
};
