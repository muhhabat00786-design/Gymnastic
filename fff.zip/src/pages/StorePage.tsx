import React from 'react';
import { OnlineStoreSection } from '../components/OnlineStoreSection';
import { useAuth } from '../context/AuthContext';

export const StorePage: React.FC = () => {
  const { addToCart } = useAuth();

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      <OnlineStoreSection onAddToCart={(prod) => addToCart(prod, 1)} />
    </div>
  );
};
