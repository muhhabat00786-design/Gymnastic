import React from 'react';
import { ShieldCheck } from 'lucide-react';

export const PrivacyPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center space-y-2 border-b border-white/10 pb-8">
          <ShieldCheck className="w-10 h-10 text-[#FF3B30] mx-auto" />
          <h1 className="text-3xl font-black font-mono text-white uppercase">Privacy Policy</h1>
          <p className="text-xs text-neutral-400">Last Updated: July 28, 2026 • VORTEX Global Data Compliance</p>
        </div>

        <div className="prose prose-invert text-xs sm:text-sm text-neutral-300 leading-relaxed space-y-4">
          <p>
            VORTEX Ultra-Luxury Fitness Club is committed to protecting member privacy and biometric diagnostic confidentiality.
          </p>
          <h2 className="text-base font-bold text-white font-mono uppercase">1. Biometric & Scan Data</h2>
          <p>
            All body composition DEXA scans, EMG surface muscle readings, and heart rate variability logs are encrypted using AES-256 standards and stored on isolated cloud infrastructure.
          </p>
          <h2 className="text-base font-bold text-white font-mono uppercase">2. Use of AI Engine</h2>
          <p>
            Biometric inputs provided to VORTEX AI (Gemini 3.6) are processed in real time solely to customize exercise cadence and macro ratios. Data is never sold or shared with external advertising networks.
          </p>
          <h2 className="text-base font-bold text-white font-mono uppercase">3. Biometric Keycard & QR Security</h2>
          <p>
            Biometric check-in tokens at club entrances expire every 60 seconds to prevent unauthorized keycard cloning.
          </p>
        </div>
      </div>
    </div>
  );
};
