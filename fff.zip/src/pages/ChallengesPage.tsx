import React from 'react';
import { CHALLENGES } from '../data/extendedData';
import { Award, Users, Trophy, Check, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const ChallengesPage: React.FC = () => {
  const { openBookingModal } = useAuth();

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          Compete & Transform
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          Fitness <span className="text-[#FF3B30]">Challenges</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          Test your willpower, track DEXA body recomp progress, and win cash prizes and annual executive passes.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {CHALLENGES.map(cha => (
            <div key={cha.id} className="bg-[#0e0e0e] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between">
              <div className="relative h-64 overflow-hidden">
                <img src={cha.image} alt={cha.title} className="w-full h-full object-cover" />
                <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-bold uppercase bg-amber-500 text-black font-mono">
                  Prize: {cha.prize}
                </span>
              </div>

              <div className="p-8 flex-1 flex flex-col justify-between space-y-6">
                <div className="space-y-3">
                  <div className="flex justify-between items-center text-xs font-mono text-neutral-400">
                    <span>Duration: <strong className="text-white">{cha.duration}</strong></span>
                    <span>Active Contenders: <strong className="text-[#FF3B30]">{cha.participantsCount}</strong></span>
                  </div>

                  <h3 className="text-2xl font-bold text-white font-mono">{cha.title}</h3>
                  <p className="text-xs text-neutral-300 leading-relaxed">{cha.description}</p>

                  <div className="space-y-1.5 pt-2">
                    <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Challenge Protocol Rules</h4>
                    <ul className="space-y-1 text-xs text-neutral-300">
                      {cha.rules.map((rule, idx) => (
                        <li key={idx} className="flex items-center gap-1.5">
                          <Check className="w-3.5 h-3.5 text-[#FF3B30]" /> {rule}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-4 border-t border-white/5">
                  <button
                    onClick={() => openBookingModal(cha)}
                    className="w-full py-3.5 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-extrabold text-xs uppercase tracking-wider transition-all shadow-lg shadow-red-900/30 flex items-center justify-center gap-2"
                  >
                    <Trophy className="w-4 h-4" /> Enter Challenge Now
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
