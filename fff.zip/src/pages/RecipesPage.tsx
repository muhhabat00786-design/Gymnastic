import React from 'react';
import { RECIPES } from '../data/extendedData';
import { Clock, Flame, ShieldCheck, Check } from 'lucide-react';

export const RecipesPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          Chef Curated High-Protein Library
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          Anabolic <span className="text-[#FF3B30]">Recipes</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          Nutrient-dense, chef-crafted recipes with exact macro breakdowns for peak muscular recovery.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {RECIPES.map(recipe => (
            <div key={recipe.id} className="bg-[#0e0e0e] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between">
              <div className="relative h-56 overflow-hidden">
                <img src={recipe.image} alt={recipe.title} className="w-full h-full object-cover" />
                <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-black/80 text-white border border-white/20">
                  {recipe.category}
                </span>
                <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase bg-red-950 text-red-400 border border-red-500/30 font-mono">
                  {recipe.prepTime}
                </span>
              </div>

              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-xl font-bold text-white font-mono mb-2">{recipe.title}</h3>
                  
                  {/* Macros badge row */}
                  <div className="grid grid-cols-4 gap-1 bg-black p-2.5 rounded-xl text-center text-[11px] font-mono border border-white/5 my-3">
                    <div><span className="text-neutral-500 block">Calories</span><strong className="text-white">{recipe.calories}</strong></div>
                    <div><span className="text-neutral-500 block">Protein</span><strong className="text-emerald-400">{recipe.protein}g</strong></div>
                    <div><span className="text-neutral-500 block">Carbs</span><strong className="text-white">{recipe.carbs}g</strong></div>
                    <div><span className="text-neutral-500 block">Fat</span><strong className="text-white">{recipe.fat}g</strong></div>
                  </div>

                  <div className="space-y-2 text-xs">
                    <h4 className="font-bold text-neutral-400 uppercase tracking-wider">Key Ingredients</h4>
                    <ul className="space-y-1 text-neutral-300">
                      {recipe.ingredients.map((ing, idx) => (
                        <li key={idx} className="flex items-center gap-1.5">
                          <Check className="w-3 h-3 text-[#FF3B30]" /> {ing}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="pt-4 border-t border-white/5 space-y-2">
                  <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Preparation Steps</h4>
                  <ol className="list-decimal list-inside space-y-1 text-[11px] text-neutral-400">
                    {recipe.instructions.map((step, idx) => (
                      <li key={idx}>{step}</li>
                    ))}
                  </ol>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
