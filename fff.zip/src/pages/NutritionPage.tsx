import React from 'react';
import { Link } from 'react-router-dom';
import { MEAL_PLANS } from '../data/gymData';
import { RECIPES } from '../data/extendedData';
import { BookOpen, Flame, ShieldCheck, Sparkles, Clock, ArrowRight } from 'lucide-react';

export const NutritionPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          Anabolic Fuel & Bio-Individual Macros
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          VORTEX <span className="text-[#FF3B30]">Nutrition</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          Precision macronutrient meal plans, high-protein gourmet recipes, and AI-powered metabolic rate calibration.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-16">
        
        {/* Featured Meal Plans */}
        <div className="space-y-6">
          <h2 className="text-2xl font-black uppercase font-mono border-l-4 border-[#FF3B30] pl-3">
            Custom Meal Protocols
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {MEAL_PLANS.map(plan => (
              <div key={plan.id} className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-6 shadow-2xl">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-xs font-bold text-[#FF3B30] uppercase font-mono">{plan.goal}</span>
                    <h3 className="text-2xl font-extrabold text-white font-mono">{plan.title}</h3>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-red-950 text-red-400 border border-red-500/30 font-mono text-xs font-bold">
                    {plan.calories} kcal
                  </span>
                </div>

                <div className="grid grid-cols-3 gap-2 bg-black/60 p-3 rounded-2xl text-center text-xs font-mono border border-white/5">
                  <div><span className="text-neutral-500 block">Protein</span><strong className="text-white text-sm">{plan.protein}g</strong></div>
                  <div><span className="text-neutral-500 block">Carbs</span><strong className="text-white text-sm">{plan.carbs}g</strong></div>
                  <div><span className="text-neutral-500 block">Fat</span><strong className="text-white text-sm">{plan.fat}g</strong></div>
                </div>

                <div className="space-y-3">
                  <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Sample Daily Menu</h4>
                  {plan.meals.map((m, idx) => (
                    <div key={idx} className="p-3 rounded-xl bg-white/5 text-xs space-y-1">
                      <div className="flex justify-between font-bold text-white">
                        <span>{m.name}</span>
                        <span className="text-[#FF3B30] font-mono">{m.time}</span>
                      </div>
                      <p className="text-neutral-400 text-[11px]">{m.desc}</p>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recipes Link Section */}
        <div className="p-10 rounded-3xl bg-gradient-to-r from-red-950 via-black to-black border border-red-500/30 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2">
            <h3 className="text-2xl font-extrabold uppercase font-mono text-white">Anabolic Gourmet Recipe Library</h3>
            <p className="text-xs text-neutral-400 max-w-xl">
              High-protein, chef-curated meals designed for muscle growth, rapid digestion, and culinary excellence.
            </p>
          </div>
          <Link
            to="/recipes"
            className="px-6 py-3.5 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-red-900/40 flex items-center gap-2 whitespace-nowrap"
          >
            View All Recipes <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

      </div>
    </div>
  );
};
