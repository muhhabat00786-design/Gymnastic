import React from 'react';
import { SchedulePage } from './SchedulePage';

export const BookClassPage: React.FC = () => {
  return <SchedulePage />;
};
