import React from 'react';
import { TestimonialsSection } from '../components/TestimonialsSection';
import { TransformationStories } from '../components/TransformationStories';

export const TestimonialsPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen space-y-16">
      <TestimonialsSection />
      <TransformationStories />
    </div>
  );
};
