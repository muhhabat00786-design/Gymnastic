import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { PROGRAMS } from '../data/gymData';
import { Dumbbell, Flame, Clock, User, ArrowRight, Check, Filter } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const ProgramsPage: React.FC = () => {
  const { openBookingModal, toggleSaveItem, savedItems } = useAuth();
  const [selectedCat, setSelectedCat] = useState<string>('All');
  const [selectedIntensity, setSelectedIntensity] = useState<string>('All');

  const categories = ['All', 'Bodybuilding', 'Weight Loss', 'CrossFit', 'Powerlifting', 'Yoga & Pilates', 'Combat Arts'];
  const intensities = ['All', 'Beginner', 'Intermediate', 'Advanced', 'Elite'];

  const filteredPrograms = PROGRAMS.filter(p => {
    const matchCat = selectedCat === 'All' || p.category === selectedCat;
    const matchInt = selectedIntensity === 'All' || p.intensity === selectedIntensity;
    return matchCat && matchInt;
  });

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          Precision Training Protocols
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          VORTEX <span className="text-[#FF3B30]">Programs</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          Scientifically periodized training protocols engineered for muscular hypertrophy, raw power output, and metabolic shredding.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        
        {/* Filters */}
        <div className="p-4 rounded-2xl bg-[#0d0d0d] border border-white/10 space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-neutral-400 uppercase tracking-wider">
            <Filter className="w-4 h-4 text-[#FF3B30]" /> Filter Programs
          </div>
          
          <div className="flex flex-wrap gap-2">
            <span className="text-xs text-neutral-500 self-center mr-2">Category:</span>
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCat(cat)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  selectedCat === cat
                    ? 'bg-[#FF3B30] text-white shadow-md shadow-red-900/30 font-bold'
                    : 'bg-white/5 text-neutral-400 hover:text-white hover:bg-white/10'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap gap-2 pt-2 border-t border-white/5">
            <span className="text-xs text-neutral-500 self-center mr-2">Intensity Level:</span>
            {intensities.map(int => (
              <button
                key={int}
                onClick={() => setSelectedIntensity(int)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  selectedIntensity === int
                    ? 'bg-red-950 border border-red-500/50 text-red-400 font-bold'
                    : 'bg-white/5 text-neutral-400 hover:text-white'
                }`}
              >
                {int}
              </button>
            ))}
          </div>
        </div>

        {/* Program Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredPrograms.map(program => (
            <div
              key={program.id}
              className="bg-[#0e0e0e] border border-white/10 rounded-2xl overflow-hidden group hover:border-red-500/40 transition-all duration-300 flex flex-col shadow-xl"
            >
              {/* Image Header */}
              <div className="relative h-52 overflow-hidden">
                <img
                  src={program.image}
                  alt={program.title}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0e0e0e] via-black/30 to-transparent" />
                <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-black/80 text-white border border-white/20">
                  {program.category}
                </span>
                <span className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-red-950/90 text-red-400 border border-red-500/30">
                  {program.intensity}
                </span>
              </div>

              {/* Body */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-xl font-bold text-white font-mono mb-2 group-hover:text-[#FF3B30] transition-colors">
                    {program.title}
                  </h3>
                  <p className="text-xs text-neutral-400 line-clamp-2 leading-relaxed">
                    {program.description}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs border-y border-white/5 py-3 text-neutral-300">
                  <div className="flex items-center gap-1.5">
                    <Clock className="w-3.5 h-3.5 text-[#FF3B30]" /> {program.duration}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Flame className="w-3.5 h-3.5 text-amber-500" /> {program.caloriesBurned}
                  </div>
                  <div className="flex items-center gap-1.5 col-span-2">
                    <User className="w-3.5 h-3.5 text-neutral-400" /> Lead: {program.trainer}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <span className="text-sm font-black text-white font-mono">{program.price}</span>
                  <div className="flex items-center gap-2">
                    <Link
                      to={`/programs/${program.id}`}
                      className="px-3 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-semibold transition-colors"
                    >
                      Details
                    </Link>
                    <button
                      onClick={() => openBookingModal(program)}
                      className="px-4 py-2 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white text-xs font-bold transition-all shadow-md shadow-red-900/30"
                    >
                      Book Program
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
