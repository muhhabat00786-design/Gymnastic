import React from 'react';
import { FAQSection } from '../components/FAQSection';

export const FaqPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      <FAQSection />
    </div>
  );
};
