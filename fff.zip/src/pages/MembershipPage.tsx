import React, { useState } from 'react';
import { PRICING_PLANS } from '../data/gymData';
import { Check, Shield, Star, Zap, Crown, ArrowRight } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const MembershipPage: React.FC = () => {
  const { openBookingModal, setIsCheckoutOpen } = useAuth();
  const [annualBilling, setAnnualBilling] = useState(true);

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          Executive Tier Access
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          VORTEX <span className="text-[#FF3B30]">Membership</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          Unlimited global club privileges, biometric locker service, infrared recovery spa, and championship coaching.
        </p>

        {/* Annual / Monthly Toggle */}
        <div className="pt-6 flex items-center justify-center gap-3">
          <span className={`text-xs font-bold ${!annualBilling ? 'text-white' : 'text-neutral-500'}`}>Monthly Billing</span>
          <button
            onClick={() => setAnnualBilling(!annualBilling)}
            className="w-14 h-8 rounded-full bg-red-950 border border-red-500/50 p-1 transition-colors relative"
          >
            <div className={`w-6 h-6 rounded-full bg-[#FF3B30] transition-transform ${annualBilling ? 'translate-x-6' : 'translate-x-0'}`} />
          </button>
          <span className={`text-xs font-bold ${annualBilling ? 'text-white' : 'text-neutral-500'} flex items-center gap-1`}>
            Annual Billing <span className="text-[10px] bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2 py-0.5 rounded-full font-mono">SAVE 20%</span>
          </span>
        </div>
      </div>

      {/* Pricing Cards Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {PRICING_PLANS.map(plan => {
            const price = annualBilling ? plan.priceYearly : plan.priceMonthly;
            return (
              <div
                key={plan.id}
                className={`rounded-3xl p-6 bg-[#0e0e0e] border flex flex-col justify-between relative transition-all duration-300 hover:scale-[1.02] shadow-2xl ${
                  plan.popular
                    ? 'border-[#FF3B30] shadow-red-900/30 bg-gradient-to-b from-red-950/20 to-[#0e0e0e]'
                    : plan.vip
                    ? 'border-amber-500/50 shadow-amber-900/20 bg-gradient-to-b from-amber-950/20 to-[#0e0e0e]'
                    : 'border-white/10'
                }`}
              >
                {plan.popular && (
                  <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-[#FF3B30] text-white shadow-lg">
                    MOST POPULAR
                  </span>
                )}
                {plan.vip && (
                  <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-[10px] font-black uppercase tracking-wider bg-amber-500 text-black shadow-lg flex items-center gap-1">
                    <Crown className="w-3 h-3" /> VIP STATUS
                  </span>
                )}

                <div className="space-y-4">
                  <h3 className="text-xl font-black text-white font-mono">{plan.name}</h3>
                  <p className="text-xs text-neutral-400 leading-relaxed min-h-[36px]">{plan.description}</p>

                  <div className="py-2 border-y border-white/10">
                    <div className="flex items-baseline gap-1">
                      <span className="text-3xl font-black text-white font-mono">${price}</span>
                      <span className="text-xs text-neutral-500 font-mono">/ month</span>
                    </div>
                    {annualBilling && <p className="text-[10px] text-emerald-400 mt-1">Billed annually (${price * 12}/yr)</p>}
                  </div>

                  <ul className="space-y-2.5 text-xs text-neutral-300 pt-2">
                    {plan.features.map((feat, idx) => (
                      <li key={idx} className="flex items-start gap-2">
                        <Check className="w-4 h-4 text-[#FF3B30] flex-shrink-0 mt-0.5" />
                        <span>{feat}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="pt-8">
                  <button
                    onClick={() => setIsCheckoutOpen(true)}
                    className={`w-full py-3.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all shadow-lg flex items-center justify-center gap-2 ${
                      plan.popular || plan.vip
                        ? 'bg-[#FF3B30] hover:bg-red-600 text-white shadow-red-900/40'
                        : 'bg-white/10 hover:bg-white/20 text-white'
                    }`}
                  >
                    Select Plan <ArrowRight className="w-4 h-4" />
                  </button>
                  <p className="text-[10px] text-center text-neutral-500 mt-2">Zero initiation fee. Cancel anytime.</p>
                </div>
              </div>
            );
          })}
        </div>
      </div>

    </div>
  );
};
