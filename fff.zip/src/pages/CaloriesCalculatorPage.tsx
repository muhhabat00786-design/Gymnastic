import React from 'react';
import { CalculatorsSection } from '../components/CalculatorsSection';

export const CaloriesCalculatorPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      <CalculatorsSection />
    </div>
  );
};
