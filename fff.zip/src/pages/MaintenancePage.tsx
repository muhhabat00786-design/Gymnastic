import React from 'react';
import { Wrench, Shield } from 'lucide-react';

export const MaintenancePage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-[80vh] flex items-center justify-center p-4">
      <div className="text-center space-y-6 max-w-md">
        <div className="w-20 h-20 rounded-3xl bg-amber-950/80 border border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto shadow-2xl">
          <Wrench className="w-10 h-10 animate-pulse" />
        </div>
        <h1 className="text-3xl font-black font-mono text-white uppercase">System Upgrades Active</h1>
        <p className="text-xs text-neutral-400">
          Our biomechanical neural sensors are undergoing scheduled calibration. Platform access will resume shortly.
        </p>
      </div>
    </div>
  );
};
