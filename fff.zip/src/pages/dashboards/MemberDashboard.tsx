import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { QrCode, Calendar, Clock, Trophy, Flame, Dumbbell, ShieldCheck, ShoppingBag, Plus, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

export const MemberDashboard: React.FC = () => {
  const { user, bookings, cart, cancelBooking, openBookingModal } = useAuth();
  const [activeTab, setActiveTab] = useState<'overview' | 'bookings' | 'biometrics' | 'orders'>('overview');

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Welcome Header & QR Keycard */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 p-8 rounded-3xl bg-gradient-to-r from-red-950/80 via-[#0e0e0e] to-[#0e0e0e] border border-red-500/30 flex flex-col justify-between shadow-2xl space-y-6">
            <div className="space-y-2">
              <span className="px-3 py-1 rounded-full bg-red-950 text-red-400 border border-red-500/30 text-xs font-mono font-bold uppercase">
                {user?.role} Tier • Executive Keycard
              </span>
              <h1 className="text-3xl sm:text-4xl font-black font-mono text-white">
                Welcome back, {user?.name || 'VIP Member'}
              </h1>
              <p className="text-xs text-neutral-400">
                Your Next Scheduled Session: <strong className="text-white font-mono">Hypertrophy Legs & Glutes @ 18:00 Today</strong>
              </p>
            </div>

            <div className="grid grid-cols-3 gap-3 border-t border-white/10 pt-4 text-xs font-mono">
              <div>
                <span className="text-neutral-500 block">Workouts Logged</span>
                <strong className="text-xl text-white font-black">28</strong>
              </div>
              <div>
                <span className="text-neutral-500 block">Streak</span>
                <strong className="text-xl text-[#FF3B30] font-black">12 Days 🔥</strong>
              </div>
              <div>
                <span className="text-neutral-500 block">Muscle Mass Index</span>
                <strong className="text-xl text-emerald-400 font-black">+3.4 lbs</strong>
              </div>
            </div>
          </div>

          {/* Biometric Keycard QR */}
          <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 text-center space-y-3 flex flex-col items-center justify-center shadow-2xl">
            <p className="text-xs font-mono font-bold text-neutral-400 uppercase flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-[#FF3B30]" /> Biometric Entry QR
            </p>
            <div className="p-3 bg-white rounded-2xl shadow-inner">
              <QrCode className="w-28 h-28 text-black" />
            </div>
            <p className="text-[10px] text-neutral-500 font-mono">
              Dynamic Token • Refreshes in 42s
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-white/10 text-xs font-mono">
          {[
            { id: 'overview', label: 'Dashboard Overview' },
            { id: 'bookings', label: `Active Bookings (${bookings.length})` },
            { id: 'biometrics', label: 'DEXA Biometrics' },
            { id: 'orders', label: 'Supplements & Store Orders' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-3 font-bold border-b-2 transition-all ${
                activeTab === tab.id
                  ? 'border-[#FF3B30] text-white'
                  : 'border-transparent text-neutral-500 hover:text-neutral-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Contents */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {/* Recent Bookings */}
            <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-base font-bold text-white font-mono uppercase flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-[#FF3B30]" /> Recent Reservations
                </h3>
                <Link to="/schedule" className="text-xs text-[#FF3B30] hover:underline font-mono">
                  + Book Class
                </Link>
              </div>

              {bookings.length === 0 ? (
                <p className="text-xs text-neutral-500 py-6 text-center">No active class bookings. Explore schedule to reserve.</p>
              ) : (
                <div className="space-y-3">
                  {bookings.map(b => (
                    <div key={b.id} className="p-3.5 rounded-xl bg-black border border-white/5 flex items-center justify-between text-xs">
                      <div>
                        <p className="font-bold text-white font-mono">{b.title}</p>
                        <p className="text-neutral-400 text-[11px] font-mono">{b.date} • {b.time}</p>
                      </div>
                      <button
                        onClick={() => cancelBooking(b.id)}
                        className="px-2.5 py-1 rounded bg-red-950/60 text-red-400 hover:bg-red-900 border border-red-500/30 font-mono text-[10px]"
                      >
                        Cancel
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Quick Actions & AI Assistant */}
            <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-4 flex flex-col justify-between">
              <div>
                <h3 className="text-base font-bold text-white font-mono uppercase flex items-center gap-2">
                  <Sparkles className="w-4 h-4 text-amber-400" /> AI Coach Sync
                </h3>
                <p className="text-xs text-neutral-400 mt-2">
                  Your current macro target: <strong className="text-white font-mono">2,850 kcal (210g P / 280g C / 70g F)</strong>. Hydration goal: 4.5L daily.
                </p>
              </div>

              <div className="pt-4 border-t border-white/5 space-y-2">
                <Link
                  to="/workout-plans"
                  className="w-full py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white font-bold text-xs uppercase flex items-center justify-center gap-2 font-mono"
                >
                  <Dumbbell className="w-4 h-4 text-[#FF3B30]" /> Generate Today's Workout
                </Link>
                <Link
                  to="/recipes"
                  className="w-full py-3 rounded-xl bg-white/5 hover:bg-white/10 text-white font-bold text-xs uppercase flex items-center justify-center gap-2 font-mono"
                >
                  <Flame className="w-4 h-4 text-amber-400" /> View Anabolic Recipes
                </Link>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'bookings' && (
          <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white font-mono uppercase">All Reserved Sessions</h3>
            {bookings.length === 0 ? (
              <p className="text-xs text-neutral-500 py-8 text-center">No current reservations.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {bookings.map(b => (
                  <div key={b.id} className="p-4 rounded-2xl bg-black border border-white/10 space-y-2 text-xs font-mono">
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-white text-sm">{b.title}</span>
                      <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] font-bold">CONFIRMED</span>
                    </div>
                    <p className="text-neutral-400">Date: {b.date} @ {b.time}</p>
                    <button onClick={() => cancelBooking(b.id)} className="text-red-400 hover:underline text-[11px] pt-1">
                      Cancel Reservation
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {activeTab === 'biometrics' && (
          <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-6">
            <h3 className="text-base font-bold text-white font-mono uppercase">DEXA Scan Biometric Breakdown</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs font-mono">
              <div className="p-4 rounded-2xl bg-black border border-white/5"><span className="text-neutral-500 block">Body Fat %</span><strong className="text-xl text-white">10.8%</strong></div>
              <div className="p-4 rounded-2xl bg-black border border-white/5"><span className="text-neutral-500 block">Lean Mass</span><strong className="text-xl text-emerald-400">174.2 lbs</strong></div>
              <div className="p-4 rounded-2xl bg-black border border-white/5"><span className="text-neutral-500 block">Bone Density T-Score</span><strong className="text-xl text-white">+2.1</strong></div>
              <div className="p-4 rounded-2xl bg-black border border-white/5"><span className="text-neutral-500 block">Resting Metabolic Rate</span><strong className="text-xl text-amber-400">2,140 kcal</strong></div>
            </div>
          </div>
        )}

        {activeTab === 'orders' && (
          <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white font-mono uppercase">Recent Supplement & Apparel Orders</h3>
            <p className="text-xs text-neutral-400">Order #VORTEX-98211 • Shipped via Express Courier • 1x VORTEX Isolate Whey + 1x Lifting Belt</p>
          </div>
        )}

      </div>
    </div>
  );
};
