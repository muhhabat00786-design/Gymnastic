import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Users, Calendar, Clock, CheckCircle2, FileText, Activity } from 'lucide-react';

export const TrainerDashboard: React.FC = () => {
  const { user } = useAuth();
  const [sessionNotes, setSessionNotes] = useState('');
  const [savedNote, setSavedNote] = useState(false);

  const clients = [
    { name: 'Alex Vance', goal: 'Powerlifting / 500lb Deadlift', progress: '92%', status: 'Active' },
    { name: 'Sarah Jenkins', goal: 'Hypertrophy Glutes & Quads', progress: '88%', status: 'Active' },
    { name: 'David Miller', goal: 'Body Recomp & Fat Loss', progress: '95%', status: 'Active' }
  ];

  const handleSaveNote = (e: React.FormEvent) => {
    e.preventDefault();
    setSavedNote(true);
    setTimeout(() => {
      setSavedNote(false);
      setSessionNotes('');
    }, 2000);
  };

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Header */}
        <div className="p-8 rounded-3xl bg-gradient-to-r from-red-950/80 via-[#0e0e0e] to-[#0e0e0e] border border-red-500/30 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <span className="px-3 py-1 rounded-full bg-red-950 text-red-400 border border-red-500/30 text-xs font-mono font-bold uppercase">
              Master Trainer Portal
            </span>
            <h1 className="text-3xl font-black font-mono text-white mt-1">
              Coach {user?.name || 'Marcus Vance'}
            </h1>
            <p className="text-xs text-neutral-400">Assigned Clients: 14 Active VIP Roster</p>
          </div>

          <div className="flex gap-3 text-xs font-mono">
            <div className="px-4 py-2 rounded-xl bg-black border border-white/10 text-center">
              <span className="text-neutral-500 block">Today's Sessions</span>
              <strong className="text-white text-base">6 Scheduled</strong>
            </div>
          </div>
        </div>

        {/* Assigned Clients */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white font-mono uppercase flex items-center gap-2">
              <Users className="w-4 h-4 text-[#FF3B30]" /> Active VIP Client Roster
            </h3>
            
            <div className="space-y-3">
              {clients.map((c, idx) => (
                <div key={idx} className="p-4 rounded-2xl bg-black border border-white/5 flex items-center justify-between text-xs font-mono">
                  <div>
                    <p className="font-bold text-white text-sm">{c.name}</p>
                    <p className="text-neutral-400 text-[11px]">{c.goal}</p>
                  </div>
                  <div className="text-right">
                    <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-400 text-[10px] font-bold block mb-1">
                      {c.progress} Compliance
                    </span>
                    <button className="text-[#FF3B30] hover:underline text-[11px]">View Biometrics</button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Session Notes Logger */}
          <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white font-mono uppercase flex items-center gap-2">
              <FileText className="w-4 h-4 text-amber-400" /> Log Biomechanical Session Notes
            </h3>

            <form onSubmit={handleSaveNote} className="space-y-3">
              <textarea
                required
                rows={4}
                placeholder="Record barbell velocity, joint discomfort feedback, or macro adjustments..."
                value={sessionNotes}
                onChange={(e) => setSessionNotes(e.target.value)}
                className="w-full p-3 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
              />
              <button
                type="submit"
                className="w-full py-3 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-bold text-xs uppercase"
              >
                {savedNote ? 'Notes Synced to Client Dossier!' : 'Save Session Notes'}
              </button>
            </form>
          </div>
        </div>

      </div>
    </div>
  );
};
