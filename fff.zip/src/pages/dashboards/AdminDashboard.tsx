import React, { useState } from 'react';
import { MOCK_AUDIT_LOGS, MOCK_TICKETS } from '../../data/extendedData';
import { ShieldCheck, Users, DollarSign, Activity, FileText, CheckCircle2, AlertCircle } from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'overview' | 'tickets' | 'audit'>('overview');

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        {/* Admin Header */}
        <div className="p-8 rounded-3xl bg-gradient-to-r from-red-950/90 via-[#0e0e0e] to-[#0e0e0e] border border-red-500/40 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <span className="px-3 py-1 rounded-full bg-red-950 text-red-400 border border-red-500/30 text-xs font-mono font-bold uppercase">
              Global Headquarters HQ • Full System Access
            </span>
            <h1 className="text-3xl font-black font-mono text-white mt-1">
              Executive Admin Control Panel
            </h1>
            <p className="text-xs text-neutral-400">Monitoring Dubai, London, New York & Tokyo Flagships</p>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs font-mono">
            <div className="px-4 py-2 rounded-xl bg-black border border-white/10 text-center">
              <span className="text-neutral-500 block">MRR Revenue</span>
              <strong className="text-emerald-400 text-sm">$482,500/mo</strong>
            </div>
            <div className="px-4 py-2 rounded-xl bg-black border border-white/10 text-center">
              <span className="text-neutral-500 block">Total Active VIPs</span>
              <strong className="text-white text-sm">1,420 Members</strong>
            </div>
          </div>
        </div>

        {/* Tab Controls */}
        <div className="flex border-b border-white/10 text-xs font-mono">
          {[
            { id: 'overview', label: 'Platform Financials & Growth' },
            { id: 'tickets', label: `Concierge Support Tickets (${MOCK_TICKETS.length})` },
            { id: 'audit', label: `System Security Audit Logs (${MOCK_AUDIT_LOGS.length})` }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`px-4 py-3 font-bold border-b-2 transition-all ${
                activeTab === tab.id
                  ? 'border-[#FF3B30] text-white'
                  : 'border-transparent text-neutral-500 hover:text-neutral-300'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Tab Contents */}
        {activeTab === 'overview' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-2">
              <span className="text-xs font-mono text-neutral-500 uppercase">Monthly Recurring Subscriptions</span>
              <p className="text-3xl font-black text-white font-mono">$482,500</p>
              <span className="text-[10px] text-emerald-400 font-mono">+14.2% YoY Growth</span>
            </div>

            <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-2">
              <span className="text-xs font-mono text-neutral-500 uppercase">Class Capacity Utilization</span>
              <p className="text-3xl font-black text-white font-mono">94.8%</p>
              <span className="text-[10px] text-amber-400 font-mono">Peak hours 17:00 - 20:00 full</span>
            </div>

            <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-2">
              <span className="text-xs font-mono text-neutral-500 uppercase">Store & Supplement Sales</span>
              <p className="text-3xl font-black text-white font-mono">$68,900</p>
              <span className="text-[10px] text-emerald-400 font-mono">Top product: Isolate Whey</span>
            </div>
          </div>
        )}

        {activeTab === 'tickets' && (
          <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white font-mono uppercase">Concierge Inquiry Desk</h3>
            <div className="space-y-3">
              {MOCK_TICKETS.map(t => (
                <div key={t.id} className="p-4 rounded-2xl bg-black border border-white/5 flex items-center justify-between text-xs font-mono">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white text-sm">{t.userName}</span>
                      <span className="px-2 py-0.5 rounded bg-red-950 text-red-400 text-[10px] uppercase font-bold">{t.priority} Priority</span>
                    </div>
                    <p className="text-neutral-400 text-[11px] mt-1">{t.subject}</p>
                  </div>
                  <span className="text-amber-400 font-bold">{t.status}</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {activeTab === 'audit' && (
          <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-4">
            <h3 className="text-base font-bold text-white font-mono uppercase">System Audit Log</h3>
            <div className="space-y-2 text-xs font-mono">
              {MOCK_AUDIT_LOGS.map(log => (
                <div key={log.id} className="p-3 rounded-xl bg-black border border-white/5 flex items-center justify-between text-neutral-300">
                  <span><strong className="text-white">{log.action}</strong> by {log.user} ({log.ip})</span>
                  <span className="text-neutral-500">{log.timestamp}</span>
                </div>
              ))}
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
