import React from 'react';
import { ContactSection } from '../components/ContactSection';
import { FAQSection } from '../components/FAQSection';

export const ContactPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen space-y-16">
      <ContactSection />
      <FAQSection />
    </div>
  );
};
