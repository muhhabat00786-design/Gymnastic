import React from 'react';
import { Link } from 'react-router-dom';
import { Dumbbell, ArrowLeft, AlertTriangle } from 'lucide-react';

export const NotFoundPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-[80vh] flex items-center justify-center p-4">
      <div className="text-center space-y-6 max-w-md">
        <div className="w-20 h-20 rounded-3xl bg-red-950/80 border border-red-500/40 text-[#FF3B30] flex items-center justify-center mx-auto shadow-2xl shadow-red-900/40">
          <AlertTriangle className="w-10 h-10" />
        </div>
        <h1 className="text-6xl font-black font-mono text-white">404</h1>
        <h2 className="text-2xl font-bold uppercase font-mono text-[#FF3B30]">Protocol Not Found</h2>
        <p className="text-xs text-neutral-400">
          The page or workout routine you requested has been relocated or archived in the VORTEX database.
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-[#FF3B30] text-white font-bold text-xs uppercase tracking-wider hover:bg-red-600 transition-all shadow-lg shadow-red-900/30"
        >
          <ArrowLeft className="w-4 h-4" /> Return to Main Platform
        </Link>
      </div>
    </div>
  );
};
