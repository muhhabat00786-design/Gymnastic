import React, { useState } from 'react';
import { CLASS_SESSIONS } from '../data/gymData';
import { Calendar, Clock, MapPin, User, CheckCircle2, Shield, Filter } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const SchedulePage: React.FC = () => {
  const { openBookingModal } = useAuth();
  const [selectedDay, setSelectedDay] = useState<string>('All');
  const [selectedCat, setSelectedCat] = useState<string>('All');

  const days = ['All', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const categories = ['All', 'HIIT', 'Strength', 'Yoga', 'Boxing', 'Recovery'];

  const filteredSessions = CLASS_SESSIONS.filter(c => {
    const matchDay = selectedDay === 'All' || c.day === selectedDay;
    const matchCat = selectedCat === 'All' || c.category === selectedCat;
    return matchDay && matchCat;
  });

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          Live Studio Schedule
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          Class <span className="text-[#FF3B30]">Timetable</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          Reserve your spot in VORTEX high-intensity turf HIIT, infrared reformer flow, or heavy powerlifting suites.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        
        {/* Day & Category Filters */}
        <div className="p-4 rounded-2xl bg-[#0d0d0d] border border-white/10 space-y-4">
          <div className="flex items-center gap-2 text-xs font-bold text-neutral-400 uppercase tracking-wider">
            <Filter className="w-4 h-4 text-[#FF3B30]" /> Filter Schedule
          </div>
          
          <div className="flex flex-wrap gap-2">
            <span className="text-xs text-neutral-500 self-center mr-2">Day of Week:</span>
            {days.map(d => (
              <button
                key={d}
                onClick={() => setSelectedDay(d)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  selectedDay === d
                    ? 'bg-[#FF3B30] text-white shadow-md shadow-red-900/30 font-bold'
                    : 'bg-white/5 text-neutral-400 hover:text-white'
                }`}
              >
                {d}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap gap-2 pt-2 border-t border-white/5">
            <span className="text-xs text-neutral-500 self-center mr-2">Category:</span>
            {categories.map(c => (
              <button
                key={c}
                onClick={() => setSelectedCat(c)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  selectedCat === c
                    ? 'bg-red-950 border border-red-500/50 text-red-400 font-bold'
                    : 'bg-white/5 text-neutral-400 hover:text-white'
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {/* Schedule Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSessions.map(session => (
            <div
              key={session.id}
              className="bg-[#0e0e0e] border border-white/10 rounded-2xl p-6 hover:border-red-500/40 transition-all flex flex-col justify-between shadow-xl space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider bg-red-950 text-red-400 border border-red-500/30">
                    {session.category}
                  </span>
                  <span className="text-xs font-mono font-bold text-emerald-400">
                    {session.spotsLeft} Spots Left
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white font-mono">{session.className}</h3>
                
                <div className="space-y-1.5 text-xs text-neutral-300 font-mono pt-2">
                  <p className="flex items-center gap-2"><Calendar className="w-3.5 h-3.5 text-[#FF3B30]" /> {session.day} @ {session.time}</p>
                  <p className="flex items-center gap-2"><Clock className="w-3.5 h-3.5 text-amber-400" /> Duration: {session.duration}</p>
                  <p className="flex items-center gap-2"><User className="w-3.5 h-3.5 text-neutral-400" /> Trainer: {session.trainer}</p>
                  <p className="flex items-center gap-2"><MapPin className="w-3.5 h-3.5 text-neutral-400" /> Room: {session.room}</p>
                </div>
              </div>

              <button
                onClick={() => openBookingModal(session)}
                className="w-full py-3 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-red-900/30"
              >
                Reserve Spot Now
              </button>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
};
