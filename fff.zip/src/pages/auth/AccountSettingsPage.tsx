import React, { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { User, Mail, Shield, Bell, Key, Save, CheckCircle2 } from 'lucide-react';

export const AccountSettingsPage: React.FC = () => {
  const { user } = useAuth();
  const [name, setName] = useState(user?.name || 'Executive Member');
  const [email, setEmail] = useState(user?.email || 'member@vortex.club');
  const [saved, setSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <div className="border-b border-white/10 pb-6 flex items-center justify-between">
          <div>
            <span className="text-xs font-mono text-[#FF3B30] uppercase font-bold">Portal Controls</span>
            <h1 className="text-3xl font-black font-mono text-white uppercase">Account Settings</h1>
          </div>
          {saved && (
            <span className="flex items-center gap-1.5 text-xs font-mono text-emerald-400 bg-emerald-950/60 border border-emerald-500/30 px-3 py-1.5 rounded-xl">
              <CheckCircle2 className="w-4 h-4" /> Preferences Saved
            </span>
          )}
        </div>

        <form onSubmit={handleSave} className="space-y-6">
          <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-4">
            <h3 className="text-base font-bold font-mono text-white uppercase flex items-center gap-2">
              <User className="w-4 h-4 text-[#FF3B30]" /> Personal Dossier
            </h3>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs text-neutral-400 mb-1">Full Name</label>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-xs text-neutral-400 mb-1">Email Address</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
                />
              </div>
            </div>
          </div>

          <div className="p-6 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-4">
            <h3 className="text-base font-bold font-mono text-white uppercase flex items-center gap-2">
              <Shield className="w-4 h-4 text-emerald-400" /> Biometric Keycard & Security
            </h3>
            <div className="flex items-center justify-between text-xs py-2 border-b border-white/5">
              <div>
                <p className="font-bold text-white">Two-Factor Authentication (2FA)</p>
                <p className="text-neutral-500">Require authenticator token upon sign in</p>
              </div>
              <span className="px-3 py-1 rounded-full bg-emerald-950 text-emerald-400 font-mono font-bold text-[10px]">
                ENABLED
              </span>
            </div>
            <div className="flex items-center justify-between text-xs py-2">
              <div>
                <p className="font-bold text-white">Biometric QR Token</p>
                <p className="text-neutral-500">Dynamic 60s rotation for speed-gate entry</p>
              </div>
              <span className="px-3 py-1 rounded-full bg-red-950 text-red-400 font-mono font-bold text-[10px]">
                ACTIVE
              </span>
            </div>
          </div>

          <button
            type="submit"
            className="px-8 py-3.5 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-extrabold text-xs uppercase tracking-wider transition-all shadow-lg shadow-red-900/40 flex items-center gap-2"
          >
            <Save className="w-4 h-4" /> Save Account Changes
          </button>
        </form>

      </div>
    </div>
  );
};
