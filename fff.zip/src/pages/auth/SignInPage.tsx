import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Dumbbell, Lock, Mail, ArrowRight, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const SignInPage: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'member' | 'trainer' | 'admin'>('member');
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      login(email || `${role}@vortexfitness.club`, role);
      setLoading(false);
      navigate('/dashboard');
    }, 600);
  };

  return (
    <div className="pt-28 pb-20 bg-black text-white min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#0e0e0e] border border-white/10 rounded-3xl p-8 shadow-2xl space-y-6 relative overflow-hidden">
        
        {/* Glow accent */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-20 bg-red-600/10 blur-xl pointer-events-none" />

        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-red-600 to-red-500 p-0.5 mx-auto shadow-lg shadow-red-900/40">
            <div className="w-full h-full bg-black rounded-[14px] flex items-center justify-center">
              <Dumbbell className="w-6 h-6 text-[#FF3B30]" />
            </div>
          </div>
          <h1 className="text-2xl font-black font-mono text-white uppercase">VORTEX Portal</h1>
          <p className="text-xs text-neutral-400">Sign in to access your biometric portal & dashboard</p>
        </div>

        {/* Role Selector Tabs */}
        <div className="grid grid-cols-3 gap-1 bg-black p-1 rounded-xl border border-white/10 text-xs font-mono">
          {(['member', 'trainer', 'admin'] as const).map(r => (
            <button
              key={r}
              type="button"
              onClick={() => setRole(r)}
              className={`py-2 rounded-lg capitalize font-bold transition-all ${
                role === r ? 'bg-[#FF3B30] text-white shadow-md' : 'text-neutral-400 hover:text-white'
              }`}
            >
              {r}
            </button>
          ))}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-neutral-400 mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                placeholder={role === 'admin' ? 'admin@vortexfitness.club' : `${role}@vortexfitness.club`}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="block text-xs font-bold text-neutral-400">Password</label>
              <Link to="/auth/forgot-password" className="text-[11px] text-[#FF3B30] hover:underline">
                Forgot password?
              </Link>
            </div>
            <div className="relative">
              <Lock className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3" />
              <input
                type="password"
                required
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-extrabold text-xs uppercase tracking-wider transition-all shadow-lg shadow-red-900/40 flex items-center justify-center gap-2"
          >
            {loading ? 'Authenticating...' : `Sign In as ${role}`} <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="text-center text-xs text-neutral-400 pt-2 border-t border-white/5">
          Don't have an executive membership?{' '}
          <Link to="/auth/signup" className="text-[#FF3B30] font-bold hover:underline">
            Apply Now
          </Link>
        </div>

      </div>
    </div>
  );
};
