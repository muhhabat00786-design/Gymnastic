import React from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle2, ShieldCheck } from 'lucide-react';

export const VerifyEmailPage: React.FC = () => {
  return (
    <div className="pt-28 pb-20 bg-black text-white min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#0e0e0e] border border-white/10 rounded-3xl p-8 shadow-2xl text-center space-y-4">
        <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
        <h1 className="text-2xl font-black font-mono text-white uppercase">Email Verified</h1>
        <p className="text-xs text-neutral-400">Your executive VIP email address has been authenticated in our biometric index.</p>
        <Link to="/dashboard" className="inline-block px-6 py-3 rounded-xl bg-[#FF3B30] text-white font-bold text-xs uppercase">
          Go to Portal Dashboard
        </Link>
      </div>
    </div>
  );
};
