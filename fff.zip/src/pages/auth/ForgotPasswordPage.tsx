import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Mail, CheckCircle2, ArrowLeft } from 'lucide-react';

export const ForgotPasswordPage: React.FC = () => {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <div className="pt-28 pb-20 bg-black text-white min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#0e0e0e] border border-white/10 rounded-3xl p-8 shadow-2xl space-y-6">
        
        {submitted ? (
          <div className="text-center space-y-4">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h2 className="text-2xl font-bold font-mono text-white">Reset Link Dispatched</h2>
            <p className="text-xs text-neutral-400">
              We have dispatched a secure password reset token to <strong className="text-white">{email}</strong>. Please check your inbox.
            </p>
            <Link to="/auth/signin" className="inline-block px-6 py-2.5 rounded-xl bg-white/10 text-white font-bold text-xs uppercase">
              Return to Sign In
            </Link>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="text-center space-y-1">
              <h1 className="text-2xl font-black font-mono text-white uppercase">Reset Password</h1>
              <p className="text-xs text-neutral-400">Enter your executive email to receive password recovery steps</p>
            </div>

            <div>
              <label className="block text-xs font-bold text-neutral-400 mb-1">Email Address</label>
              <div className="relative">
                <Mail className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3" />
                <input
                  type="email"
                  required
                  placeholder="member@vortex.club"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
                />
              </div>
            </div>

            <button type="submit" className="w-full py-3.5 rounded-xl bg-[#FF3B30] text-white font-bold text-xs uppercase">
              Send Reset Token
            </button>

            <div className="text-center pt-2">
              <Link to="/auth/signin" className="text-xs text-neutral-400 hover:text-white inline-flex items-center gap-1">
                <ArrowLeft className="w-3.5 h-3.5" /> Back to Sign In
              </Link>
            </div>
          </form>
        )}

      </div>
    </div>
  );
};
