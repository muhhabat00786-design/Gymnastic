import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Lock, CheckCircle2 } from 'lucide-react';

export const ResetPasswordPage: React.FC = () => {
  const navigate = useNavigate();
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [done, setDone] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === confirmPassword) {
      setDone(true);
      setTimeout(() => navigate('/auth/signin'), 1500);
    }
  };

  return (
    <div className="pt-28 pb-20 bg-black text-white min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#0e0e0e] border border-white/10 rounded-3xl p-8 shadow-2xl space-y-6">
        {done ? (
          <div className="text-center space-y-3 py-6">
            <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
            <h2 className="text-xl font-bold font-mono text-white">Password Updated!</h2>
            <p className="text-xs text-neutral-400">Redirecting to Sign In...</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <h1 className="text-2xl font-black font-mono text-white uppercase text-center">New Password</h1>
            <div>
              <label className="block text-xs font-bold text-neutral-400 mb-1">New Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-neutral-400 mb-1">Confirm New Password</label>
              <input
                type="password"
                required
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                className="w-full px-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
              />
            </div>
            <button type="submit" className="w-full py-3.5 rounded-xl bg-[#FF3B30] text-white font-bold text-xs uppercase">
              Update Password
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
