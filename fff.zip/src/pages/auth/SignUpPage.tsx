import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Dumbbell, Lock, Mail, User, ArrowRight, CheckCircle2 } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export const SignUpPage: React.FC = () => {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(email || 'newmember@vortexfitness.club', 'member');
    navigate('/dashboard');
  };

  return (
    <div className="pt-28 pb-20 bg-black text-white min-h-screen flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-[#0e0e0e] border border-white/10 rounded-3xl p-8 shadow-2xl space-y-6">
        
        <div className="text-center space-y-2">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-red-600 to-red-500 p-0.5 mx-auto shadow-lg shadow-red-900/40">
            <div className="w-full h-full bg-black rounded-[14px] flex items-center justify-center">
              <Dumbbell className="w-6 h-6 text-[#FF3B30]" />
            </div>
          </div>
          <h1 className="text-2xl font-black font-mono text-white uppercase">Apply for VIP Membership</h1>
          <p className="text-xs text-neutral-400">Join the world's premier ultra-luxury fitness ecosystem</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-neutral-400 mb-1">Full Legal Name</label>
            <div className="relative">
              <User className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3" />
              <input
                type="text"
                required
                placeholder="Marcus Aurelius"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-400 mb-1">Email Address</label>
            <div className="relative">
              <Mail className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3" />
              <input
                type="email"
                required
                placeholder="marcus@vortex.club"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-neutral-400 mb-1">Set Password</label>
            <div className="relative">
              <Lock className="w-4 h-4 text-neutral-500 absolute left-3.5 top-3" />
              <input
                type="password"
                required
                placeholder="••••••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-black border border-white/10 text-white text-xs focus:border-red-500 focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-3.5 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-extrabold text-xs uppercase tracking-wider transition-all shadow-lg shadow-red-900/40 flex items-center justify-center gap-2"
          >
            Create Executive Account <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="text-center text-xs text-neutral-400 pt-2 border-t border-white/5">
          Already a member?{' '}
          <Link to="/auth/signin" className="text-[#FF3B30] font-bold hover:underline">
            Sign In
          </Link>
        </div>

      </div>
    </div>
  );
};
