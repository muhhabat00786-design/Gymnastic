import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { BLOG_POSTS } from '../data/gymData';
import { ArrowLeft, Calendar, Clock, User, Share2, Bookmark } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const BlogDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { toggleSaveItem, savedItems } = useAuth();

  const post = BLOG_POSTS.find(b => b.id === id) || BLOG_POSTS[0];
  const isSaved = savedItems.includes(post.id);

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <Link to="/blog" className="inline-flex items-center gap-2 text-xs text-neutral-400 hover:text-white transition-colors">
          <ArrowLeft className="w-4 h-4 text-[#FF3B30]" /> Back to VORTEX Journal
        </Link>

        {/* Title Header */}
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-red-950 text-red-400 border border-red-500/30">
              {post.category}
            </span>
            <span className="text-xs text-neutral-400 font-mono flex items-center gap-1">
              <Clock className="w-3.5 h-3.5" /> {post.readTime}
            </span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black font-mono text-white leading-tight">
            {post.title}
          </h1>

          <div className="flex items-center justify-between border-y border-white/10 py-4 text-xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-red-950 text-[#FF3B30] flex items-center justify-center font-bold">
                <User className="w-5 h-5" />
              </div>
              <div>
                <p className="font-bold text-white">{post.author}</p>
                <p className="text-neutral-500 font-mono">{post.date}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => toggleSaveItem(post.id)}
                className={`p-2.5 rounded-xl border transition-colors ${
                  isSaved ? 'bg-red-950 border-red-500/50 text-[#FF3B30]' : 'bg-white/5 border-white/10 text-neutral-400 hover:text-white'
                }`}
              >
                <Bookmark className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>

        {/* Banner Image */}
        <div className="h-80 sm:h-96 rounded-3xl overflow-hidden border border-white/10 shadow-2xl">
          <img src={post.image} alt={post.title} className="w-full h-full object-cover" />
        </div>

        {/* Content Body */}
        <div className="prose prose-invert max-w-none space-y-6 text-neutral-300 leading-relaxed text-sm sm:text-base">
          <p className="text-lg font-medium text-white border-l-2 border-[#FF3B30] pl-4 italic">
            "{post.summary}"
          </p>
          <p>
            {post.content}
          </p>
          <p>
            Muscle hypertrophy and mechanical tension are regulated by intracellular signaling cascades. When muscle fibers experience near-maximal force under controlled cadence, mechanosensors trigger mTORC1 pathway activation.
          </p>
          <p>
            Integrating post-exercise contrast therapy—combining 15 minutes of 80°C infrared heat with a 3-minute cold water immersion at 10°C—accelerates metabolic waste clearance and elevates growth hormone release by up to 250%.
          </p>
        </div>

      </div>
    </div>
  );
};
