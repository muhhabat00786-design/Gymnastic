import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { PROGRAMS } from '../data/gymData';
import { Dumbbell, Clock, Flame, User, Check, ShieldCheck, ArrowLeft, Calendar } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const ProgramDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { openBookingModal } = useAuth();

  const program = PROGRAMS.find(p => p.id === id) || PROGRAMS[0];

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <Link to="/programs" className="inline-flex items-center gap-2 text-xs text-neutral-400 hover:text-white transition-colors">
          <ArrowLeft className="w-4 h-4 text-[#FF3B30]" /> Back to All Programs
        </Link>

        {/* Hero Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center bg-[#0e0e0e] border border-white/10 rounded-3xl p-6 sm:p-10 shadow-2xl overflow-hidden relative">
          <div className="space-y-6 z-10">
            <div className="flex items-center gap-3">
              <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-red-950 text-red-400 border border-red-500/30">
                {program.category}
              </span>
              <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-white/10 text-white">
                {program.intensity} Level
              </span>
            </div>

            <h1 className="text-3xl sm:text-5xl font-black uppercase font-mono text-white">
              {program.title}
            </h1>

            <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">
              {program.description}
            </p>

            <div className="grid grid-cols-3 gap-4 border-y border-white/10 py-4 text-xs font-mono">
              <div>
                <p className="text-neutral-500 uppercase">Duration</p>
                <p className="text-base font-bold text-white flex items-center gap-1 mt-1"><Clock className="w-4 h-4 text-[#FF3B30]" /> {program.duration}</p>
              </div>
              <div>
                <p className="text-neutral-500 uppercase">Est. Burn</p>
                <p className="text-base font-bold text-white flex items-center gap-1 mt-1"><Flame className="w-4 h-4 text-amber-500" /> {program.caloriesBurned}</p>
              </div>
              <div>
                <p className="text-neutral-500 uppercase">Master Trainer</p>
                <p className="text-base font-bold text-white flex items-center gap-1 mt-1"><User className="w-4 h-4 text-neutral-400" /> {program.trainer}</p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <div>
                <p className="text-xs text-neutral-400">Monthly Tuition</p>
                <p className="text-2xl font-black text-[#FF3B30] font-mono">{program.price}</p>
              </div>
              <button
                onClick={() => openBookingModal(program)}
                className="px-8 py-3.5 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-extrabold text-xs uppercase tracking-wider transition-all shadow-lg shadow-red-900/40"
              >
                Enroll in Program
              </button>
            </div>
          </div>

          <div className="relative h-[350px] sm:h-[450px] rounded-2xl overflow-hidden border border-white/10">
            <img src={program.image} alt={program.title} className="w-full h-full object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent" />
          </div>
        </div>

        {/* Syllabus / Features */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-8">
          <div className="p-8 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h3 className="text-xl font-bold text-white font-mono uppercase flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-[#FF3B30]" /> Protocol Highlights
            </h3>
            <ul className="space-y-3 text-xs text-neutral-300">
              <li className="flex items-start gap-2"><Check className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" /> Biweekly DEXA body composition and muscle symmetry assessments</li>
              <li className="flex items-start gap-2"><Check className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" /> Customized progressive overload velocity tracking via Technogym sensors</li>
              <li className="flex items-start gap-2"><Check className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" /> Direct WhatsApp access to lead trainer for form video checks</li>
              <li className="flex items-start gap-2"><Check className="w-4 h-4 text-emerald-400 flex-shrink-0 mt-0.5" /> Post-workout cryotherapy & sauna recovery pass included</li>
            </ul>
          </div>

          <div className="p-8 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
            <h3 className="text-xl font-bold text-white font-mono uppercase flex items-center gap-2">
              <Calendar className="w-5 h-5 text-amber-400" /> Weekly Schedule Overview
            </h3>
            <div className="space-y-2 text-xs font-mono">
              <div className="p-3 rounded-xl bg-white/5 flex justify-between"><span>Mon / Wed / Fri</span><span className="text-white font-bold">Heavy Compound Lifting</span></div>
              <div className="p-3 rounded-xl bg-white/5 flex justify-between"><span>Tue / Thu</span><span className="text-amber-400 font-bold">Metabolic & Core Mobility</span></div>
              <div className="p-3 rounded-xl bg-white/5 flex justify-between"><span>Sat</span><span className="text-emerald-400 font-bold">Infrared Sauna Recovery Bath</span></div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
