import React from 'react';
import { Link } from 'react-router-dom';
import { TRAINERS } from '../data/gymData';
import { Star, Award, Calendar, ArrowRight, Instagram, Linkedin, MessageSquare } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const TrainersPage: React.FC = () => {
  const { openBookingModal } = useAuth();

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          Championship Roster
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          Master <span className="text-[#FF3B30]">Trainers</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          Former IFBB Pros, Olympic performance coaches, and world-class movement specialists dedicated to your transformation.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {TRAINERS.map(trainer => (
            <div
              key={trainer.id}
              className="bg-[#0e0e0e] border border-white/10 rounded-3xl overflow-hidden flex flex-col justify-between group hover:border-red-500/40 transition-all duration-300 shadow-xl"
            >
              <div className="relative h-72 overflow-hidden">
                <img
                  src={trainer.photo}
                  alt={trainer.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0e0e0e] via-transparent to-transparent" />
                <div className="absolute top-3 right-3 px-2.5 py-1 rounded-full bg-black/80 border border-amber-500/40 text-amber-400 text-xs font-bold flex items-center gap-1 font-mono">
                  <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> {trainer.rating} ({trainer.reviewsCount})
                </div>
              </div>

              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <h3 className="text-xl font-bold text-white font-mono group-hover:text-[#FF3B30] transition-colors">{trainer.name}</h3>
                  <p className="text-xs text-[#FF3B30] font-semibold">{trainer.role}</p>
                  <p className="text-xs text-neutral-400 mt-2 line-clamp-3 leading-relaxed">{trainer.bio}</p>
                </div>

                <div className="space-y-3 border-t border-white/5 pt-3">
                  <div className="flex flex-wrap gap-1">
                    {trainer.specialization.map((s, idx) => (
                      <span key={idx} className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-neutral-300 font-mono">
                        {s}
                      </span>
                    ))}
                  </div>

                  <div className="flex items-center justify-between text-xs text-neutral-400">
                    <span>Experience: <strong className="text-white">{trainer.experience}</strong></span>
                    <span>Days: <strong className="text-white">{trainer.availableDays.join(', ')}</strong></span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2">
                  <Link
                    to={`/trainers/${trainer.id}`}
                    className="px-3 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-white text-xs font-semibold"
                  >
                    Profile
                  </Link>
                  <button
                    onClick={() => openBookingModal(trainer)}
                    className="px-4 py-2 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white text-xs font-bold transition-all shadow-md shadow-red-900/30"
                  >
                    Book 1-on-1
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
