import React, { useState } from 'react';
import { CAREERS } from '../data/extendedData';
import { Briefcase, MapPin, Clock, ArrowRight, CheckCircle2, X } from 'lucide-react';

export const CareersPage: React.FC = () => {
  const [selectedJob, setSelectedJob] = useState<any>(null);
  const [applied, setApplied] = useState(false);

  const handleApply = (e: React.FormEvent) => {
    e.preventDefault();
    setApplied(true);
    setTimeout(() => {
      setApplied(false);
      setSelectedJob(null);
    }, 2000);
  };

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          Join International Leadership
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          VORTEX <span className="text-[#FF3B30]">Careers</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          We are seeking master performance coaches, clinical dietitians, and luxury hospitality professionals.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {CAREERS.map(job => (
            <div key={job.id} className="p-8 rounded-3xl bg-[#0e0e0e] border border-white/10 space-y-4 shadow-2xl flex flex-col justify-between">
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="px-3 py-1 rounded-full bg-red-950 text-red-400 border border-red-500/30 text-xs font-mono font-bold">
                    {job.department}
                  </span>
                  <span className="text-xs text-neutral-400 flex items-center gap-1 font-mono">
                    <Clock className="w-3.5 h-3.5" /> {job.type}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-white font-mono">{job.title}</h3>
                <p className="text-xs text-neutral-400 flex items-center gap-1.5 font-mono">
                  <MapPin className="w-3.5 h-3.5 text-[#FF3B30]" /> {job.location} • {job.experience}
                </p>
                <p className="text-xs text-neutral-300 leading-relaxed pt-2">{job.description}</p>

                <div className="space-y-1.5 pt-2">
                  <h4 className="text-xs font-bold text-neutral-400 uppercase tracking-wider">Key Requirements</h4>
                  <ul className="space-y-1 text-xs text-neutral-300 list-disc list-inside">
                    {job.requirements.map((req, idx) => (
                      <li key={idx}>{req}</li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="pt-6 border-t border-white/5">
                <button
                  onClick={() => setSelectedJob(job)}
                  className="w-full py-3 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-red-900/30 flex items-center justify-center gap-2"
                >
                  Apply for Position <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Application Modal */}
      {selectedJob && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fadeIn">
          <div className="w-full max-w-lg bg-[#0e0e0e] border border-white/10 rounded-2xl p-6 relative">
            <button
              onClick={() => setSelectedJob(null)}
              className="absolute top-4 right-4 p-2 rounded-xl bg-white/5 text-neutral-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            {applied ? (
              <div className="py-10 text-center space-y-3">
                <CheckCircle2 className="w-12 h-12 text-emerald-400 mx-auto" />
                <h3 className="text-xl font-bold text-white">Application Received!</h3>
                <p className="text-xs text-neutral-400">Our HR director will review your dossier within 48 hours.</p>
              </div>
            ) : (
              <form onSubmit={handleApply} className="space-y-4">
                <h3 className="text-lg font-bold text-white font-mono">Apply: {selectedJob.title}</h3>
                <div>
                  <label className="block text-xs text-neutral-400 mb-1">Full Name</label>
                  <input type="text" required className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white text-xs" />
                </div>
                <div>
                  <label className="block text-xs text-neutral-400 mb-1">Email Address</label>
                  <input type="email" required className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white text-xs" />
                </div>
                <div>
                  <label className="block text-xs text-neutral-400 mb-1">LinkedIn / Portfolio URL</label>
                  <input type="url" required className="w-full px-3 py-2 rounded-xl bg-black border border-white/10 text-white text-xs" />
                </div>
                <button type="submit" className="w-full py-3 rounded-xl bg-[#FF3B30] text-white font-bold text-xs uppercase">
                  Submit Application
                </button>
              </form>
            )}
          </div>
        </div>
      )}

    </div>
  );
};
