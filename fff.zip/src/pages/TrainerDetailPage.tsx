import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { TRAINERS } from '../data/gymData';
import { Star, Award, Calendar, ArrowLeft, Instagram, Linkedin, ShieldCheck, Check } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const TrainerDetailPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const { openBookingModal } = useAuth();

  const trainer = TRAINERS.find(t => t.id === id) || TRAINERS[0];

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        
        <Link to="/trainers" className="inline-flex items-center gap-2 text-xs text-neutral-400 hover:text-white transition-colors">
          <ArrowLeft className="w-4 h-4 text-[#FF3B30]" /> Back to All Master Trainers
        </Link>

        {/* Hero Card */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 items-center bg-[#0e0e0e] border border-white/10 rounded-3xl p-8 shadow-2xl">
          <div className="relative h-96 rounded-2xl overflow-hidden border border-white/10">
            <img src={trainer.photo} alt={trainer.name} className="w-full h-full object-cover" />
            <div className="absolute top-3 right-3 px-3 py-1 rounded-full bg-black/80 border border-amber-500/40 text-amber-400 text-xs font-bold font-mono flex items-center gap-1">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" /> {trainer.rating} ({trainer.reviewsCount} reviews)
            </div>
          </div>

          <div className="lg:col-span-2 space-y-6">
            <div>
              <span className="text-xs font-bold text-[#FF3B30] uppercase tracking-wider">{trainer.role}</span>
              <h1 className="text-3xl sm:text-5xl font-black uppercase font-mono text-white mt-1">{trainer.name}</h1>
            </div>

            <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">{trainer.bio}</p>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 border-y border-white/10 py-4 text-xs font-mono">
              <div>
                <p className="text-neutral-500 uppercase">Experience</p>
                <p className="text-base font-bold text-white mt-1">{trainer.experience}</p>
              </div>
              <div>
                <p className="text-neutral-500 uppercase">Available Days</p>
                <p className="text-base font-bold text-white mt-1">{trainer.availableDays.join(', ')}</p>
              </div>
              <div className="col-span-2 sm:col-span-1">
                <p className="text-neutral-500 uppercase">Specialization</p>
                <p className="text-xs font-bold text-red-400 mt-1">{trainer.specialization.join(' • ')}</p>
              </div>
            </div>

            <div className="flex items-center gap-4 pt-2">
              <button
                onClick={() => openBookingModal(trainer)}
                className="px-8 py-3.5 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-extrabold text-xs uppercase tracking-wider transition-all shadow-lg shadow-red-900/40"
              >
                Book 1-on-1 Consultation
              </button>
              <a
                href={`https://instagram.com/${trainer.instagram.replace('@', '')}`}
                target="_blank"
                rel="noreferrer"
                className="p-3.5 rounded-xl bg-white/5 hover:bg-white/10 text-white font-semibold text-xs flex items-center gap-2"
              >
                <Instagram className="w-4 h-4 text-[#FF3B30]" /> {trainer.instagram}
              </a>
            </div>
          </div>
        </div>

        {/* Client Success Stories */}
        <div className="p-8 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-4">
          <h3 className="text-xl font-bold text-white font-mono uppercase flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#FF3B30]" /> Certified Coaching Methodology
          </h3>
          <p className="text-xs text-neutral-300 leading-relaxed">
            {trainer.name} integrates computer-vision movement tracking, EMG surface muscle activation monitors, and heart rate variability (HRV) analytics into every 1-on-1 session to eliminate plateaus.
          </p>
        </div>

      </div>
    </div>
  );
};
