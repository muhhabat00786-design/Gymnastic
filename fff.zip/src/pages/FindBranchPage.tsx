import React from 'react';
import { BRANCHES } from '../data/extendedData';
import { MapPin, Phone, Mail, Clock, Check, Globe } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const FindBranchPage: React.FC = () => {
  const { openBookingModal } = useAuth();

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          International Network
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          VORTEX <span className="text-[#FF3B30]">Locations</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          Reciprocal VIP keycard access across four international flagships with valet parking and helicopter access.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {BRANCHES.map(branch => (
            <div key={branch.id} className="bg-[#0e0e0e] border border-white/10 rounded-3xl overflow-hidden shadow-2xl flex flex-col justify-between">
              <div className="relative h-60 overflow-hidden">
                <img src={branch.image} alt={branch.name} className="w-full h-full object-cover" />
                <span className="absolute top-3 left-3 px-3 py-1 rounded-full text-xs font-bold uppercase bg-red-950 text-red-400 border border-red-500/30">
                  {branch.city}, {branch.country}
                </span>
              </div>

              <div className="p-6 flex-1 flex flex-col justify-between space-y-6">
                <div className="space-y-3">
                  <h3 className="text-xl font-bold text-white font-mono">{branch.name}</h3>
                  <div className="space-y-1.5 text-xs text-neutral-400 font-mono">
                    <p className="flex items-start gap-2"><MapPin className="w-3.5 h-3.5 text-[#FF3B30] flex-shrink-0 mt-0.5" /> {branch.address}</p>
                    <p className="flex items-center gap-2"><Phone className="w-3.5 h-3.5 text-neutral-400" /> {branch.phone}</p>
                    <p className="flex items-center gap-2"><Mail className="w-3.5 h-3.5 text-neutral-400" /> {branch.email}</p>
                    <p className="flex items-center gap-2"><Clock className="w-3.5 h-3.5 text-amber-400" /> {branch.hours}</p>
                  </div>

                  <div className="pt-2">
                    <h4 className="text-[11px] font-bold text-neutral-400 uppercase tracking-wider mb-2">Club Amenities</h4>
                    <div className="flex flex-wrap gap-1">
                      {branch.amenities.map((am, idx) => (
                        <span key={idx} className="px-2 py-0.5 rounded bg-white/5 text-[10px] text-neutral-300 font-mono">
                          ✓ {am}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-white/5">
                  <button
                    onClick={() => openBookingModal(branch)}
                    className="w-full py-3 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-md shadow-red-900/30"
                  >
                    Schedule Club Tour
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
