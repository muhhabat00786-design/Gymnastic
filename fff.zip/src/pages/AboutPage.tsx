import React from 'react';
import { ShieldCheck, Award, Users, Trophy, Sparkles, MapPin, Globe } from 'lucide-react';
import { Link } from 'react-router-dom';

export const AboutPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Hero Banner */}
      <div className="relative py-20 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 overflow-hidden">
        <div className="max-w-7xl mx-auto text-center space-y-4 relative z-10">
          <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
            Heritage & Innovation
          </span>
          <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
            About <span className="text-[#FF3B30]">VORTEX</span>
          </h1>
          <p className="text-base sm:text-lg text-neutral-400 max-w-2xl mx-auto leading-relaxed">
            Founded to redefine human physical potential through precision biomechanics, artificial intelligence, and unmatched luxury hospitality.
          </p>
        </div>
      </div>

      {/* Core Philosophy Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-16">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h2 className="text-3xl font-extrabold uppercase font-mono border-l-4 border-[#FF3B30] pl-4">
              Where Science Meets Uncompromising Luxury
            </h2>
            <p className="text-sm text-neutral-400 leading-relaxed">
              VORTEX was engineered from the ground up to eliminate every friction point in physical development. We blend clinical grade equipment from Technogym and Rogue with infrared cryo recovery suites and real-time AI biometrics.
            </p>
            <p className="text-sm text-neutral-400 leading-relaxed">
              Every facility across Dubai, London, New York, and Tokyo is limited to exclusive membership tiers, guaranteeing spacious training environments and direct concierge access.
            </p>
            
            <div className="grid grid-cols-2 gap-4 pt-4">
              <div className="p-4 rounded-xl bg-[#0e0e0e] border border-white/10">
                <p className="text-2xl font-black text-[#FF3B30] font-mono">4 Flagships</p>
                <p className="text-xs text-neutral-400">Global Executive Locations</p>
              </div>
              <div className="p-4 rounded-xl bg-[#0e0e0e] border border-white/10">
                <p className="text-2xl font-black text-white font-mono">99.8%</p>
                <p className="text-xs text-neutral-400">Member Goal Completion Rate</p>
              </div>
            </div>
          </div>

          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1000&q=80"
              alt="VORTEX Facility"
              className="rounded-2xl border border-white/10 shadow-2xl object-cover h-[450px] w-full"
            />
            <div className="absolute -bottom-6 -left-6 bg-red-950/90 border border-red-500/40 backdrop-blur-md p-6 rounded-2xl hidden sm:block max-w-xs shadow-2xl">
              <p className="text-xs font-bold text-white flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#FF3B30]" /> Biomechanical Lab Certification
              </p>
              <p className="text-[11px] text-neutral-300 mt-1">Calibrated for exact hypertrophy force angles and joint strain minimization.</p>
            </div>
          </div>
        </div>

        {/* Pillars */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-8 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-3 hover:border-red-500/40 transition-colors">
            <Award className="w-8 h-8 text-[#FF3B30]" />
            <h3 className="text-lg font-bold text-white uppercase font-mono">Championship Coaching</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Every VORTEX trainer is an active or former IFBB Pro, Olympic conditioning strategist, or master reformer practitioner.
            </p>
          </div>

          <div className="p-8 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-3 hover:border-red-500/40 transition-colors">
            <Sparkles className="w-8 h-8 text-amber-400" />
            <h3 className="text-lg font-bold text-white uppercase font-mono">AI Biometric Integration</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Our custom Gemini 3.6 engine processes your blood panels, DEXA scans, and daily sleep metrics to continuously adapt your macro split.
            </p>
          </div>

          <div className="p-8 rounded-2xl bg-[#0a0a0a] border border-white/10 space-y-3 hover:border-red-500/40 transition-colors">
            <Globe className="w-8 h-8 text-emerald-400" />
            <h3 className="text-lg font-bold text-white uppercase font-mono">Global Reciprocal Access</h3>
            <p className="text-xs text-neutral-400 leading-relaxed">
              One VIP membership unlocks full keycard privileges at all current and upcoming VORTEX locations worldwide with biometric check-in.
            </p>
          </div>
        </div>

        {/* CTA Banner */}
        <div className="p-10 rounded-2xl bg-gradient-to-r from-red-950 via-black to-black border border-red-500/30 text-center space-y-4">
          <h3 className="text-2xl sm:text-3xl font-extrabold uppercase font-mono text-white">Experience the VORTEX Standard</h3>
          <p className="text-xs sm:text-sm text-neutral-400 max-w-xl mx-auto">
            Book a complimentary VIP club tour and full body composition analysis with one of our master performance advisors.
          </p>
          <div className="pt-2">
            <Link
              to="/membership"
              className="inline-block px-8 py-3.5 rounded-xl bg-[#FF3B30] hover:bg-red-600 text-white font-bold text-xs uppercase tracking-wider transition-all shadow-lg shadow-red-900/40"
            >
              Explore Membership Tiers
            </Link>
          </div>
        </div>
      </div>

    </div>
  );
};
