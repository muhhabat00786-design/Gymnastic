import React from 'react';
import { ShieldCheck } from 'lucide-react';

export const TermsPage: React.FC = () => {
  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
        <div className="text-center space-y-2 border-b border-white/10 pb-8">
          <ShieldCheck className="w-10 h-10 text-[#FF3B30] mx-auto" />
          <h1 className="text-3xl font-black font-mono text-white uppercase">Terms & Conditions</h1>
          <p className="text-xs text-neutral-400">Effective: July 28, 2026 • VORTEX Executive Code</p>
        </div>

        <div className="prose prose-invert text-xs sm:text-sm text-neutral-300 leading-relaxed space-y-4">
          <p>
            By enrolling in a VORTEX membership or reserving 1-on-1 sessions, members agree to adhere to club etiquette, safety standards, and membership payment protocols.
          </p>
          <h2 className="text-base font-bold text-white font-mono uppercase">1. Reciprocal Access Code</h2>
          <p>
            Executive members are granted reciprocal access to Dubai, London, New York, and Tokyo flagships. Guest passes are restricted to 2 guests per calendar month per primary account holder.
          </p>
          <h2 className="text-base font-bold text-white font-mono uppercase">2. Cancellation & Freeze Policy</h2>
          <p>
            Memberships may be frozen for up to 90 consecutive days per year with 14 days written notice to concierge@vortexfitness.club.
          </p>
        </div>
      </div>
    </div>
  );
};
