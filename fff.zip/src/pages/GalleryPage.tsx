import React, { useState } from 'react';
import { X, ZoomIn, Play, Image as ImageIcon } from 'lucide-react';

export const GalleryPage: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const galleryItems = [
    { id: 'g1', title: 'Main Iron Suite & Custom Dumbbells', category: 'Equipment', image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=1000&q=80' },
    { id: 'g2', title: 'Infrared Reformer Sanctuary', category: 'Recovery', image: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&w=1000&q=80' },
    { id: 'g3', title: 'Championship Ring & Heavy Bags', category: 'Combat', image: 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&w=1000&q=80' },
    { id: 'g4', title: 'Cryotherapy & Contrast Cold Plunge', category: 'Recovery', image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1000&q=80' },
    { id: 'g5', title: 'Rogue Sprint Turf & Sled Track', category: 'CrossFit', image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=1000&q=80' },
    { id: 'g6', title: 'Executive Biometric Locker Suite', category: 'Amenities', image: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=1000&q=80' }
  ];

  const categories = ['All', 'Equipment', 'Recovery', 'Combat', 'CrossFit', 'Amenities'];

  const filteredItems = activeCategory === 'All' ? galleryItems : galleryItems.filter(i => i.category === activeCategory);

  return (
    <div className="pt-24 pb-20 bg-black text-white min-h-screen">
      
      {/* Header */}
      <div className="py-16 bg-gradient-to-b from-red-950/40 via-black to-black border-b border-white/10 px-4 sm:px-6 lg:px-8 text-center space-y-4">
        <span className="text-xs uppercase tracking-[0.3em] font-extrabold text-[#FF3B30] px-3 py-1 rounded-full bg-red-950/80 border border-red-500/30">
          Visual Atmosphere
        </span>
        <h1 className="text-4xl sm:text-6xl font-black uppercase tracking-tight text-white font-mono">
          VORTEX <span className="text-[#FF3B30]">Gallery</span>
        </h1>
        <p className="text-sm sm:text-base text-neutral-400 max-w-xl mx-auto">
          Explore the architecture, customized biomechanical suites, and infrared recovery sanctuaries of our international flagships.
        </p>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
        
        {/* Category Tabs */}
        <div className="flex justify-center gap-2 overflow-x-auto no-scrollbar py-2">
          {categories.map(cat => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-4 py-2 rounded-xl text-xs font-semibold transition-all ${
                activeCategory === cat
                  ? 'bg-[#FF3B30] text-white shadow-lg shadow-red-900/40 font-bold'
                  : 'bg-white/5 text-neutral-400 hover:text-white'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Masonry Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map(item => (
            <div
              key={item.id}
              onClick={() => setSelectedImage(item.image)}
              className="group relative h-80 rounded-2xl overflow-hidden cursor-pointer border border-white/10 hover:border-red-500/50 transition-all shadow-xl"
            >
              <img src={item.image} alt={item.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black via-black/20 to-transparent opacity-80 group-hover:opacity-90 transition-opacity" />
              
              <div className="absolute bottom-4 left-4 right-4 flex items-center justify-between">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider text-[#FF3B30]">{item.category}</span>
                  <h3 className="text-base font-bold text-white font-mono">{item.title}</h3>
                </div>
                <div className="p-2 rounded-xl bg-black/60 border border-white/20 text-white group-hover:scale-110 transition-transform">
                  <ZoomIn className="w-4 h-4" />
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>

      {/* Lightbox Modal */}
      {selectedImage && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/95 backdrop-blur-xl animate-fadeIn">
          <button
            onClick={() => setSelectedImage(null)}
            className="absolute top-6 right-6 p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
          <img src={selectedImage} alt="Enlarged gallery view" className="max-w-full max-h-[85vh] rounded-2xl border border-white/10 shadow-2xl" />
        </div>
      )}

    </div>
  );
};
