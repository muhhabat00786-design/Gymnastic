import React, { useEffect } from 'react';
import { Routes, Route, useLocation } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { RoleSwitcherBar } from './components/RoleSwitcherBar';
import { Navbar } from './components/Navbar';
import { Breadcrumbs } from './components/Breadcrumbs';
import { Footer } from './components/Footer';
import { SearchModal } from './components/SearchModal';
import { BookingModal } from './components/BookingModal';
import { CheckoutModal } from './components/CheckoutModal';
import { AIModal } from './components/AIModal';

// Pages
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { ProgramsPage } from './pages/ProgramsPage';
import { ProgramDetailPage } from './pages/ProgramDetailPage';
import { MembershipPage } from './pages/MembershipPage';
import { PricingPage } from './pages/PricingPage';
import { TrainersPage } from './pages/TrainersPage';
import { TrainerDetailPage } from './pages/TrainerDetailPage';
import { SchedulePage } from './pages/SchedulePage';
import { BookClassPage } from './pages/BookClassPage';
import { GalleryPage } from './pages/GalleryPage';
import { NutritionPage } from './pages/NutritionPage';
import { RecipesPage } from './pages/RecipesPage';
import { WorkoutPlansPage } from './pages/WorkoutPlansPage';
import { BlogPage } from './pages/BlogPage';
import { BlogDetailPage } from './pages/BlogDetailPage';
import { TestimonialsPage } from './pages/TestimonialsPage';
import { SuccessStoriesPage } from './pages/SuccessStoriesPage';
import { TransformationGalleryPage } from './pages/TransformationGalleryPage';
import { BmiCalculatorPage } from './pages/BmiCalculatorPage';
import { CaloriesCalculatorPage } from './pages/CaloriesCalculatorPage';
import { ContactPage } from './pages/ContactPage';
import { FaqPage } from './pages/FaqPage';
import { CareersPage } from './pages/CareersPage';
import { EventsPage } from './pages/EventsPage';
import { ChallengesPage } from './pages/ChallengesPage';
import { FindBranchPage } from './pages/FindBranchPage';
import { StorePage } from './pages/StorePage';
import { PrivacyPage } from './pages/PrivacyPage';
import { TermsPage } from './pages/TermsPage';
import { CookiePolicyPage } from './pages/CookiePolicyPage';
import { NotFoundPage } from './pages/NotFoundPage';
import { MaintenancePage } from './pages/MaintenancePage';
import { ComingSoonPage } from './pages/ComingSoonPage';

// Auth Pages
import { SignInPage } from './pages/auth/SignInPage';
import { SignUpPage } from './pages/auth/SignUpPage';
import { ForgotPasswordPage } from './pages/auth/ForgotPasswordPage';
import { ResetPasswordPage } from './pages/auth/ResetPasswordPage';
import { VerifyEmailPage } from './pages/auth/VerifyEmailPage';
import { TwoFactorPage } from './pages/auth/TwoFactorPage';
import { AccountSettingsPage } from './pages/auth/AccountSettingsPage';

// Dashboards
import { MemberDashboard } from './pages/dashboards/MemberDashboard';
import { TrainerDashboard } from './pages/dashboards/TrainerDashboard';
import { AdminDashboard } from './pages/dashboards/AdminDashboard';

const ScrollToTop = () => {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
};

const DashboardRouter: React.FC = () => {
  const { user } = useAuth();
  if (user?.role === 'admin') return <AdminDashboard />;
  if (user?.role === 'trainer') return <TrainerDashboard />;
  return <MemberDashboard />;
};

export function AppContent() {
  return (
    <div className="min-h-screen bg-black text-white selection:bg-[#FF3B30] selection:text-white flex flex-col justify-between font-sans">
      <ScrollToTop />
      <div>
        <RoleSwitcherBar />
        <Navbar />
        <Breadcrumbs />
        
        <main>
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/about" element={<AboutPage />} />
            <Route path="/programs" element={<ProgramsPage />} />
            <Route path="/programs/:id" element={<ProgramDetailPage />} />
            <Route path="/membership" element={<MembershipPage />} />
            <Route path="/pricing" element={<PricingPage />} />
            <Route path="/trainers" element={<TrainersPage />} />
            <Route path="/trainers/:id" element={<TrainerDetailPage />} />
            <Route path="/schedule" element={<SchedulePage />} />
            <Route path="/book-class" element={<BookClassPage />} />
            <Route path="/gallery" element={<GalleryPage />} />
            <Route path="/nutrition" element={<NutritionPage />} />
            <Route path="/recipes" element={<RecipesPage />} />
            <Route path="/workout-plans" element={<WorkoutPlansPage />} />
            <Route path="/blog" element={<BlogPage />} />
            <Route path="/blog/:id" element={<BlogDetailPage />} />
            <Route path="/testimonials" element={<TestimonialsPage />} />
            <Route path="/success-stories" element={<SuccessStoriesPage />} />
            <Route path="/transformations" element={<TransformationGalleryPage />} />
            <Route path="/calculators/bmi" element={<BmiCalculatorPage />} />
            <Route path="/calculators/calories" element={<CaloriesCalculatorPage />} />
            <Route path="/contact" element={<ContactPage />} />
            <Route path="/faq" element={<FaqPage />} />
            <Route path="/careers" element={<CareersPage />} />
            <Route path="/events" element={<EventsPage />} />
            <Route path="/challenges" element={<ChallengesPage />} />
            <Route path="/branches" element={<FindBranchPage />} />
            <Route path="/store" element={<StorePage />} />
            <Route path="/privacy-policy" element={<PrivacyPage />} />
            <Route path="/terms-conditions" element={<TermsPage />} />
            <Route path="/cookie-policy" element={<CookiePolicyPage />} />

            {/* Auth Routes */}
            <Route path="/auth/signin" element={<SignInPage />} />
            <Route path="/auth/signup" element={<SignUpPage />} />
            <Route path="/auth/forgot-password" element={<ForgotPasswordPage />} />
            <Route path="/auth/reset-password" element={<ResetPasswordPage />} />
            <Route path="/auth/verify-email" element={<VerifyEmailPage />} />
            <Route path="/auth/two-factor" element={<TwoFactorPage />} />
            <Route path="/account-settings" element={<AccountSettingsPage />} />

            {/* Role Dashboards */}
            <Route path="/dashboard" element={<DashboardRouter />} />

            {/* Special System Pages */}
            <Route path="/maintenance" element={<MaintenancePage />} />
            <Route path="/coming-soon" element={<ComingSoonPage />} />
            <Route path="*" element={<NotFoundPage />} />
          </Routes>
        </main>
      </div>

      <Footer />

      {/* Global Modals */}
      <SearchModal />
      <BookingModal />
      <CheckoutModal />
      <AIModal />
    </div>
  );
}

export function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
