import { Program, Trainer, PricingPlan, ClassSession, TransformationStory, BlogPost, Product, MealPlan } from '../types';

export const HERO_VIDEOS = [
  "https://assets.mixkit.co/videos/preview/mixkit-man-runs-on-a-treadmill-in-a-gym-42838-large.mp4",
  "https://assets.mixkit.co/videos/preview/mixkit-man-doing-exercises-with-dumbbells-42835-large.mp4"
];

export const BRANDS = [
  { name: 'Nike', logo: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=300&q=80' },
  { name: 'Adidas', logo: 'https://images.unsplash.com/photo-1518002171953-a080ee817e1f?auto=format&fit=crop&w=300&q=80' },
  { name: 'Under Armour', logo: 'https://images.unsplash.com/photo-1556906781-9a412961c28c?auto=format&fit=crop&w=300&q=80' },
  { name: 'Gymshark', logo: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=300&q=80' },
  { name: 'Technogym', logo: 'https://images.unsplash.com/photo-1534438327276-14e5300c3a48?auto=format&fit=crop&w=300&q=80' },
  { name: 'Rogue Fitness', logo: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=300&q=80' },
  { name: 'MyProtein', logo: 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?auto=format&fit=crop&w=300&q=80' }
];

export const PROGRAMS: Program[] = [
  {
    id: 'prog-1',
    title: 'Hypertrophy Pro',
    category: 'Bodybuilding',
    image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=800&q=80',
    description: 'Scientific progressive overload program designed for maximum muscle hypertrophy and aesthetic symmetry.',
    duration: '12 Weeks',
    trainer: 'Marcus Vance',
    intensity: 'Advanced',
    caloriesBurned: '650 kcal/hr',
    price: '$149 / mo'
  },
  {
    id: 'prog-2',
    title: 'Metabolic Shred HIIT',
    category: 'Weight Loss',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80',
    description: 'High-octane anaerobic circuit training to ignite EPOC excess post-exercise oxygen consumption and incinerate body fat.',
    duration: '8 Weeks',
    trainer: 'Elena Rostova',
    intensity: 'Intermediate',
    caloriesBurned: '850 kcal/hr',
    price: '$129 / mo'
  },
  {
    id: 'prog-3',
    title: 'VORTEX Rogue CrossFit',
    category: 'CrossFit',
    image: 'https://images.unsplash.com/photo-1534367610401-9f5ed68180aa?auto=format&fit=crop&w=800&q=80',
    description: 'Functional movement at high intensity. Olympic weightlifting, gymnastics, and raw engine stamina.',
    duration: 'Ongoing',
    trainer: 'Jaxson Reed',
    intensity: 'Elite',
    caloriesBurned: '900 kcal/hr',
    price: '$169 / mo'
  },
  {
    id: 'prog-4',
    title: 'Titan Powerlifting Protocol',
    category: 'Powerlifting',
    image: 'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?auto=format&fit=crop&w=800&q=80',
    description: 'Master the Big Three: Squat, Bench Press, and Deadlift. Neuromuscular strength specialization.',
    duration: '16 Weeks',
    trainer: 'Viktor Thorne',
    intensity: 'Elite',
    caloriesBurned: '550 kcal/hr',
    price: '$159 / mo'
  },
  {
    id: 'prog-5',
    title: 'Infrared Reformer Yoga',
    category: 'Yoga & Pilates',
    image: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&w=800&q=80',
    description: 'Core stabilization, joint longevity, and flexibility inside our 38°C infrared heated glass studio.',
    duration: 'Ongoing',
    trainer: 'Aria Chen',
    intensity: 'Beginner',
    caloriesBurned: '400 kcal/hr',
    price: '$119 / mo'
  },
  {
    id: 'prog-6',
    title: 'Championship Boxing & MMA',
    category: 'Combat Arts',
    image: 'https://images.unsplash.com/photo-1549719386-74dfcbf7dbed?auto=format&fit=crop&w=800&q=80',
    description: 'Pro-grade footwork, striking mechanics, heavy bag drills, and conditioning led by former world champions.',
    duration: '12 Weeks',
    trainer: 'Dante "The Reaper" Silva',
    intensity: 'Advanced',
    caloriesBurned: '800 kcal/hr',
    price: '$179 / mo'
  }
];

export const TRAINERS: Trainer[] = [
  {
    id: 'tr-1',
    name: 'Marcus Vance',
    role: 'Head of Aesthetic Conditioning',
    photo: 'https://images.unsplash.com/photo-1567013127542-490d757e51fc?auto=format&fit=crop&w=800&q=80',
    specialization: ['Bodybuilding', 'Hypertrophy', 'Biomechanics'],
    experience: '12+ Years',
    rating: 4.98,
    reviewsCount: 142,
    bio: 'Former IFBB Pro and biomechanics specialist who has coached over 300 athletes to elite physical transformations.',
    instagram: '@marcus.vance',
    linkedin: 'marcus-vance-fitness',
    availableDays: ['Mon', 'Wed', 'Fri', 'Sat']
  },
  {
    id: 'tr-2',
    name: 'Elena Rostova',
    role: 'Director of Metabolic Performance',
    photo: 'https://images.unsplash.com/photo-1594381898411-846e7d193883?auto=format&fit=crop&w=800&q=80',
    specialization: ['Fat Loss', 'HIIT', 'Endurance'],
    experience: '9+ Years',
    rating: 4.95,
    reviewsCount: 188,
    bio: 'Olympic conditioning coach specializing in rapid fat loss protocols and VO2 Max enhancement.',
    instagram: '@elena.fit',
    linkedin: 'elena-rostova',
    availableDays: ['Tue', 'Thu', 'Sat', 'Sun']
  },
  {
    id: 'tr-3',
    name: 'Jaxson Reed',
    role: 'Master Rogue CrossFit Specialist',
    photo: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=800&q=80',
    specialization: ['CrossFit Games Competitor', 'Gymnastics', 'Weightlifting'],
    experience: '11+ Years',
    rating: 5.0,
    reviewsCount: 210,
    bio: '3x CrossFit Games regional athlete passionate about forging bulletproof functional movement.',
    instagram: '@jaxson.reed',
    linkedin: 'jaxson-reed-fitness',
    availableDays: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri']
  },
  {
    id: 'tr-4',
    name: 'Aria Chen',
    role: 'Holistic Yoga & Pilates Lead',
    photo: 'https://images.unsplash.com/photo-1518611012118-696072aa579a?auto=format&fit=crop&w=800&q=80',
    specialization: ['Reformer Pilates', 'Infrared Flow', 'Mobility'],
    experience: '8+ Years',
    rating: 4.97,
    reviewsCount: 165,
    bio: 'Certified master instructor trained in Bali and Tokyo specializing in posture correction and deep core power.',
    instagram: '@aria.mindbody',
    linkedin: 'aria-chen',
    availableDays: ['Mon', 'Wed', 'Fri', 'Sun']
  }
];

export const PRICING_PLANS: PricingPlan[] = [
  {
    id: 'plan-starter',
    name: 'STARTER',
    priceMonthly: 99,
    priceYearly: 79,
    description: 'Essential access to VORTEX floor, cardio theater, and modern locker rooms.',
    features: [
      'Access to Main Gym Floor & Cardio Suite',
      'Smart Biometric Locker & Towel Service',
      'Free VORTEX Mobile App & QR Access',
      '1 Complimentary Body Composition Scan',
      'Standard Operating Hours (6AM - 10PM)'
    ]
  },
  {
    id: 'plan-pro',
    name: 'PRO ATHLETE',
    priceMonthly: 189,
    priceYearly: 149,
    popular: true,
    description: 'Our most popular tier. Unlimited group classes, recovery spa, and 24/7 access.',
    features: [
      '24/7 Unlimited Global Club Access',
      'All Group Fitness & CrossFit Classes',
      'Eucalyptus Steam Room & Salt Sauna Spa',
      'Hydration & Cold Plunge Lounge Access',
      '2 Personal Training Sessions / Month',
      'Customized AI Nutrition & Macro Plan'
    ]
  },
  {
    id: 'plan-elite',
    name: 'ELITE VIP',
    priceMonthly: 349,
    priceYearly: 279,
    vip: true,
    description: 'Complete luxury status. Dedicated private locker, unlimited cryotherapy, and valet.',
    features: [
      'All Pro Plan Privileges Included',
      'Unlimited Cryotherapy & Infrared Recovery',
      'Private VIP Executive Locker & Laundry Service',
      '4 Personal Training Sessions / Month',
      'Complimentary Post-Workout Protein Shakes',
      'Guest Passes (4 Per Month)',
      'Valet Parking & Priority Class Reservations'
    ]
  },
  {
    id: 'plan-corporate',
    name: 'CORPORATE LEGACY',
    priceMonthly: 499,
    priceYearly: 399,
    description: 'Exclusive executive wellness perks for leadership teams and corporate visionaries.',
    features: [
      'Multi-User Executive Pass (Up to 5 Keycards)',
      'Dedicated Private Conference & Recovery Lounge',
      'Monthly Team Fitness Assessment & Diagnostics',
      'Private Group Training Hours',
      'Direct WhatsApp Concierge Access'
    ]
  }
];

export const CLASS_SESSIONS: ClassSession[] = [
  {
    id: 'cls-1',
    className: 'VORTEX Heavy Shred',
    category: 'HIIT',
    day: 'Monday',
    time: '07:00 AM',
    trainer: 'Elena Rostova',
    duration: '45 mins',
    room: 'Studio A (Main Turf)',
    spotsLeft: 3,
    totalSpots: 20
  },
  {
    id: 'cls-2',
    className: 'Barbell Hypertrophy',
    category: 'Strength',
    day: 'Monday',
    time: '09:00 AM',
    trainer: 'Marcus Vance',
    duration: '60 mins',
    room: 'Iron Suite',
    spotsLeft: 5,
    totalSpots: 15
  },
  {
    id: 'cls-3',
    className: 'Infrared Vinyasa Flow',
    category: 'Yoga',
    day: 'Tuesday',
    time: '08:00 AM',
    trainer: 'Aria Chen',
    duration: '60 mins',
    room: 'Zen Sanctuary',
    spotsLeft: 2,
    totalSpots: 12
  },
  {
    id: 'cls-4',
    className: 'Rogue WOD Blast',
    category: 'HIIT',
    day: 'Wednesday',
    time: '06:00 PM',
    trainer: 'Jaxson Reed',
    duration: '50 mins',
    room: 'CrossFit Box',
    spotsLeft: 4,
    totalSpots: 18
  },
  {
    id: 'cls-5',
    className: 'Pro Boxing Conditioning',
    category: 'Boxing',
    day: 'Thursday',
    time: '07:30 PM',
    trainer: 'Dante Silva',
    duration: '55 mins',
    room: 'Ring Room',
    spotsLeft: 1,
    totalSpots: 16
  },
  {
    id: 'cls-6',
    className: 'Cryo Recovery & Stretch',
    category: 'Recovery',
    day: 'Friday',
    time: '05:00 PM',
    trainer: 'Aria Chen',
    duration: '45 mins',
    room: 'Recovery Spa',
    spotsLeft: 8,
    totalSpots: 15
  },
  {
    id: 'cls-7',
    className: 'Weekend Warrior Beast',
    category: 'Strength',
    day: 'Saturday',
    time: '10:00 AM',
    trainer: 'Marcus Vance',
    duration: '75 mins',
    room: 'Iron Suite',
    spotsLeft: 6,
    totalSpots: 20
  }
];

export const TRANSFORMATION_STORIES: TransformationStory[] = [
  {
    id: 'trans-1',
    name: 'David Sterling',
    age: 34,
    timeframe: '16 Weeks',
    weightLost: '-18 kg',
    muscleGained: '+5.5 kg',
    program: 'Hypertrophy Pro & AI Macro Plan',
    quote: 'VORTEX completely restructured my biology and daily discipline. The facility quality is unmatched globally.',
    beforeImage: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
    afterImage: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=600&q=80',
    story: 'Working in high-stress finance left me sluggish. In 4 months at VORTEX under Marcus Vance, my body fat dropped from 26% to 11% while gaining raw muscle.'
  },
  {
    id: 'trans-2',
    name: 'Samantha Hayes',
    age: 29,
    timeframe: '12 Weeks',
    weightLost: '-12 kg',
    muscleGained: '+3.2 kg',
    program: 'Metabolic Shred & Infrared Pilates',
    quote: 'The recovery amenities and personal attention made exercising feel like a luxury ritual rather than a chore.',
    beforeImage: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
    afterImage: 'https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?auto=format&fit=crop&w=600&q=80',
    story: 'Elena and Aria kept me accountable with daily macro checks. I have twice the energy levels for my daily life now.'
  }
];

export const PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'VORTEX ISO-Whey Hydrolyzed (1kg)',
    category: 'Supplements',
    price: 69.99,
    rating: 4.9,
    image: 'https://images.unsplash.com/photo-1579722821273-0f6c7d44362f?auto=format&fit=crop&w=600&q=80',
    description: '100% Cold-filtered whey isolate delivering 28g pure protein per scoop with zero added sugars or filler.',
    inStock: true
  },
  {
    id: 'prod-2',
    name: 'VORTEX Pre-Workout Igniter (30 Servings)',
    category: 'Supplements',
    price: 49.99,
    rating: 4.8,
    image: 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?auto=format&fit=crop&w=600&q=80',
    description: '6g L-Citrulline Malate, 3.2g Beta-Alanine, and 300mg Natural Caffeine for relentless laser focus and pumps.',
    inStock: true
  },
  {
    id: 'prod-3',
    name: 'Matte Black Heavyweight Hoodie',
    category: 'Apparel',
    price: 119.00,
    rating: 5.0,
    image: 'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=600&q=80',
    description: '480GSM French Terry cotton with red reflective VORTEX insignia embroidery and athletic drop shoulder fit.',
    inStock: true
  },
  {
    id: 'prod-4',
    name: 'Stainless Steel Temperature Shaker (750ml)',
    category: 'Gear',
    price: 34.99,
    rating: 4.7,
    image: 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=600&q=80',
    description: 'Double-wall vacuum insulated shaker keeping your protein shakes ice-cold for up to 24 hours.',
    inStock: true
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-1',
    title: 'The Science of Progressive Overload & Myofibrillar Hypertrophy',
    category: 'Training Science',
    readTime: '6 min read',
    date: 'July 24, 2026',
    author: 'Marcus Vance',
    image: 'https://images.unsplash.com/photo-1581009146145-b5ef050c2e1e?auto=format&fit=crop&w=800&q=80',
    summary: 'Why lifting heavier is only 20% of the equation. Understanding mechanical tension, muscle damage, and metabolic stress.',
    content: 'Hypertrophy is driven primarily by mechanical tension sensed by cell mechanosensors...'
  },
  {
    id: 'blog-2',
    title: 'Infrared Sauna & Cold Plunge: The Ultimate Recovery Protocol',
    category: 'Recovery & Biohacking',
    readTime: '5 min read',
    date: 'July 20, 2026',
    author: 'Aria Chen',
    image: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=800&q=80',
    summary: 'How contrast therapy activates heat shock proteins, reduces systemic inflammation, and elevates growth hormone.',
    content: 'Alternating between 15 minutes of 80°C heat and 3 minutes of 10°C cold water immersion optimizes vascular dilation...'
  },
  {
    id: 'blog-3',
    title: 'Optimal Protein Timing and Leucine Thresholds for Muscle Protein Synthesis',
    category: 'Nutrition',
    readTime: '8 min read',
    date: 'July 15, 2026',
    author: 'Elena Rostova',
    image: 'https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&w=800&q=80',
    summary: 'Distributing your protein intake into 40g boluses with at least 3g of Leucine optimizes MPS every 3-4 hours.',
    content: 'To maximize anabolic signaling, the body requires a sufficient concentration of essential amino acids...'
  }
];

export const MEAL_PLANS: MealPlan[] = [
  {
    id: 'meal-1',
    title: 'Hypertrophy Anabolic Fuel',
    goal: 'Muscle Mass Gain',
    calories: 3200,
    protein: 220,
    carbs: 350,
    fat: 80,
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
    meals: [
      { time: '08:00 AM', name: 'Egg White & Oat Power Bowl', desc: '6 Egg whites, 2 whole eggs, 100g oats, blueberries, almond butter' },
      { time: '12:30 PM', name: 'Grilled Salmon & Jasmine Rice', desc: '250g Wild Atlantic Salmon, 200g cooked rice, steamed asparagus' },
      { time: '04:00 PM (Pre-Workout)', name: 'Rice Cakes & Anabolic Shake', desc: '4 Rice cakes with honey, 1 scoop VORTEX ISO-Whey' },
      { time: '08:00 PM', name: 'Grass-Fed Sirloin & Sweet Potato', desc: '250g Prime Sirloin, 250g baked sweet potato, roasted broccoli' }
    ]
  },
  {
    id: 'meal-2',
    title: 'Metabolic Shred & Keto Peak',
    goal: 'Fat Loss & High Energy',
    calories: 2100,
    protein: 195,
    carbs: 60,
    fat: 110,
    image: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?auto=format&fit=crop&w=800&q=80',
    meals: [
      { time: '08:30 AM', name: 'Avocado & Smoked Salmon Omelet', desc: '4 Eggs, 1/2 avocado, smoked salmon, fresh spinach, olive oil drizzle' },
      { time: '01:00 PM', name: 'Grilled Chicken Caesar Salad', desc: '250g Chicken breast, romaine lettuce, parmesan cheese, extra virgin olive oil' },
      { time: '05:00 PM', name: 'Almond Butter & Berry Protein Shake', desc: '1 Scoop Whey, unsweetened almond milk, 15g almond butter, chia seeds' },
      { time: '08:00 PM', name: 'Seared Ribeye & Garlic Zucchini', desc: '220g Ribeye steak with garlic herb butter and grilled zucchini' }
    ]
  }
];
