import { Recipe, EventItem, ChallengeItem, BranchLocation, CareerJob, SupportTicket, AuditLog } from '../types';

export const RECIPES: Recipe[] = [
  {
    id: 'rec-1',
    title: 'Seared Prime Beef Filet & Sweet Potato Puree',
    category: 'High Protein',
    prepTime: '25 Mins',
    calories: 680,
    protein: 58,
    carbs: 45,
    fat: 22,
    image: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
    ingredients: [
      '220g Grass-fed beef filet mignon',
      '200g Sweet potato, peeled & cubed',
      '1 tbsp Grass-fed butter',
      '1 tsp Rosemary & thyme leaves',
      '1/2 cup Steamed organic broccolini',
      'Sea salt & cracked black pepper'
    ],
    instructions: [
      'Preheat cast-iron skillet to high heat with grass-fed butter.',
      'Season beef filet liberally with sea salt, black pepper, and herbs.',
      'Sear for 3.5 minutes per side for medium-rare finish.',
      'Boil sweet potatoes until soft, mash with a touch of butter and sea salt.',
      'Plate sweet potato puree, top with rested beef filet and broccolini.'
    ]
  },
  {
    id: 'rec-2',
    title: 'Wild Salmon Bowl with Quinoa & Avocado',
    category: 'Low Carb',
    prepTime: '20 Mins',
    calories: 590,
    protein: 46,
    carbs: 38,
    fat: 26,
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
    ingredients: [
      '200g Wild Alaskan salmon fillet',
      '1/2 cup Cooked organic quinoa',
      '1/2 Fresh Haas avocado, sliced',
      '1 cup Baby spinach & arugula',
      '1 tbsp Extra virgin olive oil',
      'Lemon juice & sesame seeds'
    ],
    instructions: [
      'Pan-sear salmon skin-side down for 4 mins, flip and cook 3 mins more.',
      'Assemble bed of spinach, arugula, and warm cooked quinoa.',
      'Top with cooked salmon and avocado slices.',
      'Drizzle with olive oil, fresh lemon juice, and toast sesame seeds.'
    ]
  },
  {
    id: 'rec-3',
    title: 'Anabolic ISO-Whey Berry Pancake Stack',
    category: 'Post-Workout',
    prepTime: '15 Mins',
    calories: 450,
    protein: 48,
    carbs: 42,
    fat: 8,
    image: 'https://images.unsplash.com/photo-1528207776546-365bb710ee93?auto=format&fit=crop&w=800&q=80',
    ingredients: [
      '1 Scoop VORTEX Vanilla ISO-Whey',
      '1/2 cup Rolled oats, blended into flour',
      '1 Whole egg + 2 egg whites',
      '1/4 cup Unsweetened almond milk',
      '1/2 cup Fresh blueberries & raspberries',
      'Zero-calorie maple syrup'
    ],
    instructions: [
      'Blend oat flour, whey protein, egg whites, whole egg, and almond milk into smooth batter.',
      'Heat non-stick skillet over medium-low heat with light oil spray.',
      'Pour batter to form 3 large pancakes. Cook until bubbles form, then flip.',
      'Serve warm topped with fresh berries and maple syrup.'
    ]
  }
];

export const EVENTS: EventItem[] = [
  {
    id: 'evt-1',
    title: 'VORTEX International Hypertrophy Summit 2026',
    category: 'Masterclass',
    date: 'August 15, 2026',
    time: '10:00 AM - 04:00 PM',
    location: 'VORTEX Grand Auditorium & Turf',
    image: 'https://images.unsplash.com/photo-1517838277536-f5f99be501cd?auto=format&fit=crop&w=800&q=80',
    description: 'Exclusive 1-day symposium featuring IFBB Pros, sports scientists, and elite biomechanics specialists live in action.',
    spotsLeft: 14,
    price: '$250 / Pass'
  },
  {
    id: 'evt-2',
    title: 'Nightfall Infrared Sound Bath & Cryo Recovery',
    category: 'Wellness Gala',
    date: 'August 22, 2026',
    time: '08:00 PM - 10:30 PM',
    location: 'Zen Sanctuary & Salt Lounge',
    image: 'https://images.unsplash.com/photo-1545205597-3d9d02c29597?auto=format&fit=crop&w=800&q=80',
    description: 'Immersive sound healing vibration session combined with guided breathwork and cold plunge rejuvenation.',
    spotsLeft: 8,
    price: '$95 / Pass'
  }
];

export const CHALLENGES: ChallengeItem[] = [
  {
    id: 'cha-1',
    title: 'The 30-Day VORTEX Body Recomp Shred',
    prize: '$10,000 Cash + VIP Annual Membership',
    duration: '30 Days',
    participantsCount: 342,
    category: 'Fat Loss & Muscle Retention',
    description: 'Transform your body fat percentage and muscle mass with bi-weekly DEXA body scans and dedicated AI macro tracking.',
    image: 'https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?auto=format&fit=crop&w=800&q=80',
    rules: [
      'Complete at least 4 documented workouts per week.',
      'Log daily nutrition macros in VORTEX Mobile App.',
      'Attend mandatory baseline and 30-day final DEXA scan.'
    ]
  },
  {
    id: 'cha-2',
    title: 'Titan Powerlifting 500kg Club Challenge',
    prize: 'Custom Engraved Rogue Barbell + Sponsor Stack',
    duration: '6 Weeks',
    participantsCount: 188,
    category: 'Strength & Power',
    description: 'Hit a total combined 3-lift weight (Squat, Bench, Deadlift) of 500kg or more under certified referee supervision.',
    image: 'https://images.unsplash.com/photo-1526506118085-60ce8714f8c5?auto=format&fit=crop&w=800&q=80',
    rules: [
      'Lifts must adhere to IPF competition depth & command rules.',
      'Official attempt weigh-ins held every Saturday morning.',
      'Belt, knee sleeves, and wrist wraps permitted.'
    ]
  }
];

export const BRANCHES: BranchLocation[] = [
  {
    id: 'branch-1',
    city: 'Dubai',
    country: 'United Arab Emirates',
    name: 'VORTEX Downtown Tower Flagship',
    address: 'Level 42, Executive Heights, Downtown Dubai',
    phone: '+971 4 800 8678',
    email: 'dubai@vortexfitness.club',
    hours: '24 Hours / 7 Days',
    image: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?auto=format&fit=crop&w=800&q=80',
    amenities: ['Infrared Spa', 'Rooftop Olympic Pool', 'Helipad Access', 'Cryotherapy', 'AI Biometrics'],
    isFlagship: true
  },
  {
    id: 'branch-2',
    city: 'London',
    country: 'United Kingdom',
    name: 'VORTEX Mayfair Executive Club',
    address: '14 Berkeley Square, Mayfair, London W1J 6ER',
    phone: '+44 20 7946 0912',
    email: 'london@vortexfitness.club',
    hours: '24 Hours / 7 Days',
    image: 'https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?auto=format&fit=crop&w=800&q=80',
    amenities: ['Eucalyptus Steam', 'Technogym Biostrenth', 'Private Valet', 'Organic Bar'],
    isFlagship: true
  },
  {
    id: 'branch-3',
    city: 'New York',
    country: 'United States',
    name: 'VORTEX Manhattan Tribeca',
    address: '180 Greenwich St, Tribeca, New York, NY 10007',
    phone: '+1 212 555 0198',
    email: 'nyc@vortexfitness.club',
    hours: '24 Hours / 7 Days',
    image: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?auto=format&fit=crop&w=800&q=80',
    amenities: ['Rogue Turf Arena', 'Cold Plunge Suite', 'Private Executive Lockers'],
    isFlagship: true
  }
];

export const CAREERS: CareerJob[] = [
  {
    id: 'job-1',
    title: 'Senior Master Performance Coach (Hypertrophy)',
    department: 'Personal Training',
    location: 'Dubai / London / NYC',
    type: 'Full-time',
    experience: '5+ Years Required',
    description: 'Lead 1-on-1 performance coaching for high-net-worth members, executive athletes, and professional competitors.',
    requirements: [
      'NSCA-CSCS or NASM-CPT certification.',
      'Proven track record in physique transformation & progressive overload program design.',
      'Flawless communication and elite hospitality standards.'
    ]
  },
  {
    id: 'job-2',
    title: 'Sports Nutritionist & Clinical Dietitian',
    department: 'Wellness & AI Nutrition',
    location: 'Remote / On-site',
    type: 'Full-time',
    experience: '3+ Years Required',
    description: 'Design bespoke macro, blood panel, and bio-individual meal strategies integrated with our VORTEX AI Engine.',
    requirements: [
      'Registered Dietitian (RD) or Master in Sports Nutrition.',
      'Deep understanding of metabolic rate, blood glucose monitoring, and contest prep.'
    ]
  }
];

export const MOCK_TICKETS: SupportTicket[] = [
  {
    id: 'TCK-9041',
    userName: 'Alexander Wright',
    email: 'a.wright@firm.com',
    subject: 'Request for Private Locker Upgrade',
    status: 'In Progress',
    priority: 'High',
    date: '2026-07-27',
    message: 'Hello, I would like to upgrade my current Pro Plan locker to a VIP Executive suit locker starting next month.'
  },
  {
    id: 'TCK-9042',
    userName: 'Elena Vance',
    email: 'elena.vance@gmail.com',
    subject: 'Personal Trainer Session Reschedule',
    status: 'Open',
    priority: 'Medium',
    date: '2026-07-28',
    message: 'Could Marcus please shift our Thursday 9AM session to Friday 10AM due to flight schedule?'
  }
];

export const MOCK_AUDIT_LOGS: AuditLog[] = [
  {
    id: 'LOG-1001',
    action: 'USER_LOGIN_SUCCESS',
    user: 'admin@vortexfitness.club',
    role: 'admin',
    ip: '192.168.1.45',
    timestamp: '2026-07-28 05:40:12'
  },
  {
    id: 'LOG-1002',
    action: 'PROGRAM_CREATED',
    user: 'admin@vortexfitness.club',
    role: 'admin',
    ip: '192.168.1.45',
    timestamp: '2026-07-28 05:12:00'
  },
  {
    id: 'LOG-1003',
    action: 'MEMBERSHIP_RENEWED',
    user: 'david.sterling@vortex.com',
    role: 'member',
    ip: '86.142.12.90',
    timestamp: '2026-07-28 04:30:22'
  }
];
